# The Ultimate Sports Quest — Stadium Adventure

An interactive 2D cartoon sports adventure game for **Malaysian Year 4 ESL pupils**, built as a multimedia educational product for **EDUP6023**.

- **Subject:** English Language · **Year:** 4
- **Textbook context:** Get Smart Plus 4, Unit 9 — *Get Active!*
- **Topic:** Sports and Health
- **Language focus:** Sports vocabulary and superlative adjectives
- **Duration:** about 30 minutes (provisional)
- **Learning standards:** *Pending verification against the official DSKP. No standards are stated in the game.*

It is a **standalone** multimedia lesson: everything pupils need (Sports Fact Files, Decoder Wheel, Sentence Cards, lesson video, Reporter Card) is inside the website, with no physical materials. Pupils pick a team and explore a stadium map with six checkpoints (Sports Detective, Equipment Match, Grammar Decoder, Virtual Referee, Sports Reporter, Champion Zone), earning points and stars. At the end they get a printable Champion Certificate.

## Technology

- HTML5, CSS3 and vanilla JavaScript only. No frameworks, CDN, external fonts or browser-side API keys.
- One Netlify Function (`netlify/functions/tts.mts`, no npm packages) that calls ElevenLabs Text-to-Speech server-side. It is optional: the game works fully offline from local MP3s.
- Web Audio API for original synthesised sound effects (and a fallback music loop).
- HTML5 `<audio>` for your local MP3 files; Checkpoint 4 embeds the teacher's YouTube video in a responsive iframe.
- `localStorage` for saving progress (team, points, stars, completed checkpoints, current screen, answers).
- MediaRecorder API (optional; only with the pupil's permission) for speaking practice playback.

## Project structure

```
index.html            Game shell (all screens render inside it)
style.css             All visual design, animations, responsive + print styles
script.js             Game engine, content, scoring, audio/video, saving
netlify.toml          Static hosting config (publish the root, no build)
netlify/functions/tts.mts   Server-side ElevenLabs voice endpoint (/api/tts)
netlify/narration-lines.mjs The 25 coach lines the function may speak
scripts/generate-narration.mjs  Offline audio export (same Voice ID)
assets/images/        Your images (see ADD_IMAGES_HERE.txt for exact filenames)
assets/audio/         Your MP3 narration (see NARRATION_SCRIPTS.txt)
assets/video/         Not used (CP4 video is a YouTube embed; see ADD_VIDEO_HERE.txt)
README.md             This file
TEACHER_MANUAL.md     Step-by-step classroom instructions
STORYBOARD.md         Screen-by-screen learning design + narration scripts
COMPLIANCE_AUDIT.md   EDUP6023 checklist, asset register, known gaps
ultimate-sports-quest-netlify.zip   Packaged copy of the site for upload
```

## Media status (important)

**Supplied and in use:** the teacher's original cartoon hijab coach artwork. Ten expressions were cropped (not redrawn) from the two sheets kept in `assets/images/coach-source/`.

**Built into the game (drawn in code):** the six equipment illustrations, used in the Fact Files, Equipment Match, Notes and Champion Zone. Optional photos with the names in `assets/images/ADD_IMAGES_HERE.txt` replace them.

**NOT yet supplied — the product is not complete until these are added:**
- **Local narration MP3s for offline use** (25 lines). With the ElevenLabs voice set up (see *Coach voice*), the online game speaks every line automatically and the Teacher Panel can export them all. Filenames, exact words and a voice brief: `assets/audio/NARRATION_SCRIPTS.txt`; the same list as a spreadsheet for batch generation: `assets/audio/narration-manifest.csv`. Until then each one shows its subtitle and **"AUDIO NOT YET AVAILABLE"**. The builder did not generate any audio and has no access to your ElevenLabs account; nothing plays until you add your key and Voice ID.
- The teacher's preferred voice sample is stored at `assets/audio/reference/coach-voice-reference.mp3` as a **style reference only**. It can be played in the Teacher Panel but is never played to pupils and is not used as narration.
**Checkpoint 4 video: provided via YouTube embed.** It is YouTube video “Sports I – Vocabulary for Kids” (Smile and Learn – English), https://youtu.be/11e9IzV2cCQ, embedded in the game. It needs an internet connection; offline, or if YouTube blocks embedding, the game shows a clear message with a **Watch it on YouTube** link. To change the video, edit `YT_ID` in `script.js`.
- **Images:** `sports-quest-board.png` (the map uses a labelled illustrated board until it is added). Checkpoint cover images are not required.

Copy files into `assets/` with the exact filenames; no code changes are needed. The **Teacher Panel** (👩‍🏫) lists every file as found, missing or optional.

### Narration manifest and audio controller

Every narrated moment is one entry in the `NARRATION` manifest in `script.js`: the screen, the MP3 path and the transcript. One HTML5 audio controller (`Voice`) plays them all, with Play, Pause, Replay, Mute and Volume. The coach's speech bubble shows the words as subtitles. Her talking animation and sound-wave run only while audio is actually playing. Previous audio stops before new narration starts and on every screen change, and nothing plays before the pupil's first tap. Browser speech synthesis is not used at all.

For each line the game plays: **1)** the local MP3 in `assets/audio/` if it exists (offline), otherwise **2)** the ElevenLabs coach voice through the site's server function (online), otherwise **3)** a clear message ("AUDIO NOT YET AVAILABLE", or the reason generation failed).

If your Sports Quest Board needs different checkpoint positions, edit `pos: [x%, y%]` in `CHECKPOINTS` near the top of `script.js`.

## Run locally

The game is a static site. Any of these will work:

1. **Double-click `index.html`.** Most features work straight from the file system. Some browsers limit media or `localStorage` on `file://`, so option 2 is more reliable.
2. **Use a simple local server** from the project folder, for example:
   - `python3 -m http.server 8000` and open <http://localhost:8000>
   - or `npx serve .`

It works offline once all the local media files are in the folder.

## Deploy to Netlify

**Option A: drag and drop**
1. Unzip `ultimate-sports-quest-netlify.zip` (or use the project folder itself, which has `index.html` at the root).
2. Add your media files to the `assets/` folders.
3. Go to <https://app.netlify.com/drop> and drag the folder onto the page.

**Option B: Git**
Push this folder to a Git repository and connect it in Netlify. `netlify.toml` already tells Netlify to publish the root folder with no build command.

> If you add media files, re-create the ZIP so it includes them: `zip -r ultimate-sports-quest-netlify.zip index.html style.css script.js netlify.toml netlify scripts assets README.md TEACHER_MANUAL.md STORYBOARD.md COMPLIANCE_AUDIT.md`.

## Scoring rules

- Correct on the first attempt: **10 points**
- Correct after a retry (or after the timer runs out in Checkpoint 4): **5 points**
- Each completed checkpoint: **1 star**
- Points are awarded only once per item, even if a checkpoint is replayed.
- Completing all six checkpoints unlocks **Champion status** and the certificate.

## Coach voice (ElevenLabs) — setup

The coach speaks every line with **one ElevenLabs Voice ID**. The browser never sees your API key. The game asks the site's own server function (`netlify/functions/tts.mts`, URL `/api/tts`) for a fixed line, and that function calls ElevenLabs. It only speaks the game's own 25 lines (listed in `netlify/narration-lines.mjs`), so nobody can use your account to say anything else. Each generated line is stored in Netlify's CDN cache and the browser cache, so it is created **once per deploy**, not on every visit.

**1. Get your Voice ID.** In ElevenLabs open *Voices → My Voices*, pick the coach voice (for example "Zara"), and copy its **Voice ID** (a code like `21m00Tcm4TlvDq8ikWAM`). Copy your **API key** from *Profile → API Keys*. Give the key the **Text to Speech** permission only.

**2. Add them in Netlify.** In the Netlify dashboard, open this project, then go to **Project configuration → Environment variables → Add a variable**. Add:

| Key | Value | Notes |
|---|---|---|
| `ELEVENLABS_API_KEY` | your API key | Tick **Contains secret values**. Scope: Functions. |
| `ELEVENLABS_VOICE_ID` | your Voice ID | The one voice used for every line. |
| `ELEVENLABS_MODEL_ID` | *(optional)* e.g. `eleven_multilingual_v2` | Default is `eleven_multilingual_v2`. |

**3. Redeploy** (Deploys → Trigger deploy) so the function picks them up. Then open the 👩‍🏫 Teacher Panel: the Coach voice box should say **Connected**.

Never put the key in `script.js`, `index.html` or any file in the project folder. Changing the Voice ID and redeploying regenerates every line in the new voice.

### Offline audio (no internet needed)

The offline game never calls the API; it plays local MP3s. Make them once, in the same voice, in either of these ways:

- **Easiest: in the Teacher Panel** on the live site, press **⬇ Download offline narration pack (ZIP)**. Unzip it into the game folder; it fills `assets/audio/` with all 25 MP3s.
- **Or with Node.js 18+** from the project folder, with the same key and Voice ID:
  `ELEVENLABS_API_KEY=xxxx ELEVENLABS_VOICE_ID=yyyy node scripts/generate-narration.mjs`
  (PowerShell: `$env:ELEVENLABS_API_KEY="xxxx"; $env:ELEVENLABS_VOICE_ID="yyyy"; node scripts/generate-narration.mjs`). Files that already exist are skipped unless their text changed; add `--force` to remake them all.

Then re-create the ZIP (see Deploy). Once the MP3s are in `assets/audio/`, the game uses them first, both online and offline.

**Note:** Netlify Drop (drag and drop) does not deploy server functions. Use the Git-connected deploy for the online ElevenLabs voice, or ship the offline audio pack for a drag-and-drop or offline copy.

## The six EDUP6023 components

Press **📚 Learn** in the top bar to see them. 1 Introduction & objectives · 2 Interactive notes (📒 Notes, Grammar Note) · 3 Reading (CP1 Sports Fact Files, no audio) · 4 Video (CP4, YouTube embed) · 5 Interactive animated activities (CP2 drag-and-drop, CP3 Decoder Wheel, CP5 Reporter Card) · 6 Formative quiz (CP6, plus instant feedback everywhere). These are separate from the six game checkpoints.

## Virtual Sports Coach

A floating coach sits in the bottom-left corner on every screen, and she also appears on the welcome screen, in the Notes, Learning Path and Grammar Note pop-ups, beside the video and in the Champion Hall. Her real expressions change for explaining, giving instructions, listening, encouraging and celebrating, with CSS float, bounce, head-shake, sparkle and celebration animations. There is no lip-sync. A tap anywhere tucks away a silent speech bubble so it never sits over questions.

## Testing status

An automated play-through ran in headless Chromium at 1366×768, 1280×800, 1180×820, 1024×768 and 768×1024, both with no media and with temporary test media (an MP3, a short test video and a captions file; not shipped). All runs completed all six checkpoints with 0 failures. See `COMPLIANCE_AUDIT.md` section 5. **Real-device testing (iPad/Safari, Chromebook) and testing with the real recordings and video have not been done yet.**

## Roadmap / what is left

1. Add `ELEVENLABS_API_KEY` and `ELEVENLABS_VOICE_ID` in Netlify, redeploy, listen to every line, then export the offline narration pack.
2. Watch the CP4 YouTube video and check the six CP4 questions match it (edit `CP4_Q` in `script.js` if needed).
3. Add the Sports Quest Board.
4. Check the provisional objectives against the DSKP and record the verified standards.
5. Test on the classroom devices and record the results in `COMPLIANCE_AUDIT.md`.

---
## GitHub Pages notes (repair update)
- Upload the whole folder to the repository root (index.html must be at the top level) and enable
  Pages (Settings → Pages → Deploy from branch → main / root). All paths are relative; `.nojekyll` is included.
- The Netlify voice function (`/api/tts`) does not exist on GitHub Pages, so `ONLINE_VOICE` at the top of
  `script.js` is `false`. Narration plays only from MP3 files in `assets/audio/`. See `MISSING_FILES.txt`
  for the recordings that still need to be added.
- Lines without a recording show their words as subtitles ("recording not added yet"); the Listen
  buttons say "AUDIO NOT YET AVAILABLE". No substitute audio is ever played.
- File names are case-sensitive on GitHub Pages: keep them exactly as listed.
