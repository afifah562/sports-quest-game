# Storyboard — The Ultimate Sports Quest

Screen-by-screen learning design for a **standalone** multimedia lesson: everything pupils need is inside the website, with no physical or printed materials. Every screen shares the same animated cartoon stadium (sweeping spotlights, floodlights, drifting clouds, bouncing crowd, striped pitch and twinkling stars) and the same top bar (team, points, stars, checkpoints, Map, Learn, Notes, Music, Sound, Teacher, Reset) and the floating Virtual Sports Coach with voice controls (Voice ON/OFF, Replay, Play/Pause, Mute, Volume). Every narrated line and its MP3 filename is in the NARRATION manifest in `script.js` and in `assets/audio/NARRATION_SCRIPTS.txt`.

---

## S0 · Welcome screen
- **Visuals:** animated bouncing title "THE ULTIMATE SPORTS QUEST", a "STADIUM ADVENTURE" ribbon, a floating glowing trophy, the Virtual Sports Coach (welcome pose) and bouncing sports balls.
- **Text:** "WELCOME TO THE ULTIMATE SPORTS QUEST!" · "Explore. Learn. Play. Become a Champion!"
- **Interaction:** Start Adventure · Continue (if saved) · How to Play · Music ON/OFF · Sound ON/OFF · Listen (welcome narration) · Teacher.
- **Audio file:** `coach/coach-welcome.mp3`
- **Script:** *"Hello, young champions! Welcome to The Ultimate Sports Quest! I'm your Virtual Sports Coach, and I'll guide you through six exciting challenges. Are you ready to begin? Let's go!"*

## S1 · Team selection
- Four big team cards: ⚡ Blue Lightning, 🐉 Green Dragons, 🚀 Orange Rockets and 🐆 Purple Panthers, each with its own colour and mascot.
- Selecting a team gives a star burst and a sound. The team colour then themes the top bar and the map token.

## S2 · Learning objectives
- The coach (instructions pose) says: "Here is your mission!"
- "By the end of this adventure, you can:" followed by three tap-to-tick goal cards.
- **Audio file:** `learning-objectives.mp3`
- **Script:** see `NARRATION_SCRIPTS.txt` (objectives).
- A **📚 Learning Path** button lists the six EDUP6023 components and links to each one.

## S3 · Stadium map
- The Sports Quest Board (your image, or an illustrated CSS pitch placeholder) has six percentage-positioned markers on an animated dashed path.
- Marker states: 🔒 locked (grey), glowing pulsing ring (unlocked) and ✔ badge (completed). The team token hops to the current checkpoint.
- An animated progress bar shows "x / 6 checkpoints". The side panel shows the coach, the checkpoint name and icon, its focus, its status and an Enter button. Enter opens the checkpoint's activity directly (there are no cover screens).
- Tapping a locked marker makes it shake and the coach explains why.

## S4 · Checkpoint 1 — Sports Detective (listening + reading + vocabulary)
- **Step 1 — Sports Fact Files.** A shelf of six digital folders. Each opens with a flip-open animation and shows a drawn sports illustration on a court-style background, the exact Fact File text, the equipment, a **Listen** button (`fact-<sport>.mp3`) and a quick-check question with instant feedback. Dots along the bottom move between files.
- **Step 2 — Mystery Cards.** Six purple "?" cards. Tapping one flips it to show the clue; the panel shows the written clue, **📁 Check the Sports Fact Files** (reopens them at any time) and four sport choices.
- Completion: all 6 quick checks + all 6 Mystery Cards (12 tasks).

## S5 · Checkpoint 2 — Equipment Match
- Six sport drop zones with court-style backgrounds (court, pitch, pool lanes, track, basketball court, ice rink) and an "Equipment Bag" tray.
- Interaction: drag with mouse or touch, OR tap the equipment, then tap the sport.
- A correct match snaps into the zone and pops; a wrong one makes the zone and card shake. When all six are matched, the game checks every zone, the zones pop in turn and the unlock celebration plays.

## S6 · Checkpoint 3 — Grammar Decoder (superlatives)
- **Digital Decoder Wheel:** a seven-colour wheel (TALL, FAST, EASY, GOOD, BAD, DIFFICULT, POPULAR) with a pointer. Tapping a segment turns the wheel so that segment stops exactly under the pointer; **Spin** turns it several times and stops on a random segment. The result box shows e.g. "TALL → the tallest" and the rule.
- **Seven digital Sentence Cards** (deck of cards): the current card glows; tapping it flips it open to show the adjective clue and the sentence. A step list shows: open card ✔ → read clue ✔ → find the clue on the wheel → type. The typing box unlocks only when the wheel shows the card's clue.
- **Grammar Note:** flip cards under the wheel, plus a 📒 Grammar note pop-up with the superlative table and a Listen button (`grammar-explanation.mp3`).
- Correct: the padlock opens and the blank fills. Wrong: shake, the coach's thinking face and a rule hint.

## S7 · Checkpoint 4 — Virtual Referee (video learning)
- Left: the **Sports Lesson Video**, the teacher's YouTube video “Sports I – Vocabulary for Kids” (Smile and Learn – English), https://youtu.be/11e9IzV2cCQ, embedded with a responsive iframe (`https://www.youtube.com/embed/11e9IzV2cCQ`). Pupils watch inside the game. The game's Play, Pause, Replay, progress bar and volume control YouTube's player, and YouTube's CC button gives captions. The coach (listening pose) says "Watch and listen carefully!", and the coach's voice stops when the video plays.
- If the device is offline, or YouTube refuses to embed the video: a clear message with a **Watch it on YouTube** link. A small "Video not playing? Watch it on YouTube" link is always shown under the video.
- Below: the referee, whistle and scoreboard. Right: six timed questions (20 seconds each), unchanged.
- ⚠️ The questions were written for the earlier suggested script (equipment, sports, and the superlatives easiest / best / most difficult). Check them against the YouTube video and edit `CP4_Q` in `script.js` if the video does not cover them.

## S8 · Checkpoint 5 — Sports Reporter (writing + speaking practice)
- A cartoon broadcast studio with the coach as co-host.
- **Digital Reporter Card:** team name, the sentence frame "Hello everyone! I am your sports reporter. I think (sport) is the (superlative) sport because (reason)." and speaking tips.
- Builder: choose a sport → a superlative → a reason → live preview → **Put it in my report** → editable text → **Submit my report for feedback** (checklist: sport ✔, the + superlative ✔, because, capital letter, full stop).
- Speaking practice: read aloud, optional local recording, then **I practised speaking my report aloud** (self-ticked; pronunciation is not assessed).

## S9 · Checkpoint 6 — Champion Zone (final assessment)
- Five questions: vocabulary (water sport), equipment (hockey stick and puck image), superlative (bad → worst), sentence completion (the fastest runner) and reading comprehension (Mei Ling passage).
- Then the Champion Hall: the trophy spins in, confetti, team name, total points, stars, six achievement badges, the "What did you learn today?" reflection, a name entry and the printable Champion Certificate (A4 landscape).

## Coach expressions used

All images are cropped from the teacher's original artwork (`assets/images/coach-source/`).

| Role | Moment | Coach image | Floating-coach animation |
|---|---|---|---|
| Welcoming | Welcome screen (large pose) | `coach-welcome.jpg` (peace sign, full body) | — |
| Giving instructions | Team selection, checkpoint intros, Learning Path | `coach-wave.jpg` (peace sign) | bounce |
| Explaining | Objectives, notes, grammar note, idle | `coach-instructions.jpg` (smiling) | bounce / gentle float |
| Listening | Fact File audio, video | `coach-proud.jpg` (hands on cheeks) | gentle float |
| Celebrating | Correct answers | `coach-thumbs-up.jpg` or `coach-celebrate.jpg` | bounce + sparkles |
| Encouraging | Incorrect answer, time up, reminders | `coach-encourage.jpg` (thinking) | gentle head shake |
| Unlocking | Checkpoint unlocked | `coach-unlock.jpg` (surprised) | bounce + sparkles |
| Celebrating | Checkpoint completed, final celebration | `coach-celebrate.jpg`, `coach-achievement.jpg` (fists up) | celebration + sparkles |
| Celebrating | Champion Hall panel | `coach-champion.jpg` (fists up, full body) | — |

## Narration scripts

All 25 narration files (17 coach lines and 8 listening files) are listed with their exact paths and words in `assets/audio/NARRATION_SCRIPTS.txt`. That file is generated from the NARRATION manifest in `script.js`, so it always matches the subtitles.
