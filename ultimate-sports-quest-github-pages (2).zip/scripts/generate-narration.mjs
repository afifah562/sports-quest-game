#!/usr/bin/env node
// Offline audio export: generates every fixed coach line as a local MP3 with ONE
// ElevenLabs voice, saved to assets/audio/ under the exact filenames the game uses.
// The offline game then plays these files and needs no internet connection.
//
// Usage (Node 18 or newer, no packages needed), from the project folder:
//   ELEVENLABS_API_KEY=xxxx ELEVENLABS_VOICE_ID=yyyy node scripts/generate-narration.mjs
//   Windows PowerShell:  $env:ELEVENLABS_API_KEY="xxxx"; $env:ELEVENLABS_VOICE_ID="yyyy"; node scripts/generate-narration.mjs
// Options:  --force   regenerate files that already exist
//           --only=welcome,cp1   only these line keys
// Optional: ELEVENLABS_MODEL_ID (default eleven_multilingual_v2)
//
// Never commit your API key. Already-generated files are skipped (cache), so
// re-running only creates what is missing. A record of the text each file was made
// from is kept in assets/audio/.generated.json; if a line's text changes, that file
// is regenerated automatically.
import { mkdir, readFile, writeFile, access } from 'node:fs/promises'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { LINES, lineHash } from '../netlify/narration-lines.mjs'

const root = join(dirname(fileURLToPath(import.meta.url)), '..')
const audioDir = join(root, 'assets', 'audio')
const recordPath = join(audioDir, '.generated.json')
const apiKey = process.env.ELEVENLABS_API_KEY
const voiceId = process.env.ELEVENLABS_VOICE_ID
const model = process.env.ELEVENLABS_MODEL_ID || 'eleven_multilingual_v2'
const force = process.argv.includes('--force')
const onlyArg = process.argv.find((a) => a.startsWith('--only='))
const only = onlyArg ? onlyArg.slice(7).split(',') : null
// Same settings as netlify/functions/tts.mts, so online and offline audio sound identical.
const VOICE_SETTINGS = { stability: 0.55, similarity_boost: 0.8, style: 0.25, use_speaker_boost: true, speed: 0.92 }

if (!apiKey || !voiceId) {
  console.error('Missing ELEVENLABS_API_KEY or ELEVENLABS_VOICE_ID. See the "Coach voice" section of README.md.')
  process.exit(1)
}
const exists = (p) => access(p).then(() => true, () => false)
let record = {}
try { record = JSON.parse(await readFile(recordPath, 'utf8')) } catch {}

let made = 0, skipped = 0, failed = 0
for (const [key, line] of Object.entries(LINES)) {
  if (only && !only.includes(key)) continue
  const out = join(audioDir, line.file)
  const sig = `${voiceId}|${model}|${lineHash(line.text)}`
  if (!force && record[line.file] === sig && (await exists(out))) { skipped++; continue }
  process.stdout.write(`• ${line.file} … `)
  try {
    const res = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${encodeURIComponent(voiceId)}?output_format=mp3_44100_128`, {
      method: 'POST',
      headers: { 'xi-api-key': apiKey, 'Content-Type': 'application/json', Accept: 'audio/mpeg' },
      body: JSON.stringify({ text: line.text, model_id: model, voice_settings: VOICE_SETTINGS }),
    })
    if (!res.ok) throw new Error(`HTTP ${res.status}: ${(await res.text()).slice(0, 200)}`)
    const buf = Buffer.from(await res.arrayBuffer())
    await mkdir(dirname(out), { recursive: true })
    await writeFile(out, buf)
    record[line.file] = sig
    await writeFile(recordPath, JSON.stringify(record, null, 2))
    made++
    console.log(`saved (${Math.round(buf.length / 1024)} KB)`)
  } catch (e) {
    failed++
    console.log(`FAILED — ${e.message}`)
  }
}
console.log(`\nDone: ${made} generated, ${skipped} already up to date, ${failed} failed.`)
if (made) console.log('Re-create the ZIP so it includes the new audio (see README.md).')
process.exit(failed ? 1 : 0)
