# Teacher Manual — The Ultimate Sports Quest

**Class:** Year 4 English (ESL) · **Unit:** Get Smart Plus 4, Unit 9 — Get Active! · **Time:** about 30 minutes (provisional)

> **Before you teach:** the learning objectives below are **provisional** and need your confirmation. DSKP learning standards are **pending verification** and are not written into the game.

> **Standalone design.** The whole lesson happens inside the website. Pupils do **not** need any printed or physical materials. The Sports Fact Files, Decoder Wheel, Sentence Cards, lesson video and Reporter Card are all digital and built in.

## Provisional learning objectives

By the end of the lesson, pupils should be able to:
1. Identify different sports and their equipment.
2. Use superlative adjectives correctly (tall → tallest, easy → easiest, good → best, bad → worst, difficult → most difficult, popular → most popular).
3. Create simple sentences to talk about sports.

## Where the six EDUP6023 components are

Press **📚 Learn** in the top bar (or **Learning Path** on the objectives screen) to see them in the game.

| # | EDUP6023 component | Where in the game |
|---|---|---|
| 1 | Introduction and learning objectives | Welcome screen + Objectives screen (with narration) |
| 2 | Interactive text and graphic learning notes | 📒 Notes (flip cards with pictures) + the Grammar Note in Checkpoint 3 |
| 3 | Reading activity | Checkpoint 1: six Sports Fact Files (read-only, no audio) |
| 4 | Video learning activity | Checkpoint 4: the YouTube video *Sports I – Vocabulary for Kids*, embedded in the game, then six questions |
| 5 | Interactive animated pupil activity | Checkpoint 2 drag-and-drop, Checkpoint 3 Decoder Wheel, Checkpoint 5 Reporter Card |
| 6 | Formative quiz with immediate feedback | Checkpoint 6 Champion Zone (and instant feedback in every checkpoint) |

These are separate from the six game checkpoints on the Stadium Map, which unlock in order.

## Digital learning resources (all inside the game)

| Digital resource | Used in | What pupils do |
|---|---|---|
| Sports Fact Files (6) | Checkpoint 1 | Open a file, read it, answer its quick check. Reopen any time with **📁 Open the Sports Fact Files**. |
| Decoder Wheel | Checkpoint 3 | Tap an adjective or press **Spin**. The wheel stops on the segment and shows its superlative. |
| Sentence Cards (7) | Checkpoint 3 | Tap the glowing card to open it, read the clue, find the clue on the wheel, then type the answer. |
| Sports Lesson Video (YouTube embed) | Checkpoint 4 | Watch inside the game (CC for captions), then answer the questions. |
| Reporter Card | Checkpoint 5 | Use the sentence frame and tips to build and practise a short report. |

## Before the lesson (about 10 minutes)

1. Open the game on each device (laptop or tablet, in Chrome, Edge or Safari).
2. Press **👩‍🏫 Teacher** on the welcome screen. Check the **asset list** and the **Narration** box:
   - ✅ Found = your file is working.
   - ❌ MISSING = the game shows "AUDIO NOT YET AVAILABLE", "VIDEO NOT YET AVAILABLE" or a labelled placeholder.
   - ➖ Optional = not needed (for example equipment photos; the game has its own drawings).
3. Check the **Coach voice** box says *Connected* (online) or that the local MP3s are found (offline). Tap the screen once, then press **↺ Replay** next to the coach. Browsers only play sound after a tap.
4. **For offline lessons:** on the live site press **⬇ Download offline narration pack (ZIP)** in the Teacher Panel and unzip it into the game folder on the classroom device.
5. If a previous group used the device, press **↺ Reset**.

## Lesson flow (about 30 minutes)

| Time | Stage | What happens |
|---|---|---|
| 0–3 min | Welcome + teams | Pupils press **Start Adventure** and choose a team. The coach greets them. |
| 3–5 min | Objectives | Pupils listen to the coach and tap each goal. |
| 5–10 min | CP1 Sports Detective | Pupils open the six **Sports Fact Files**, read, answer the quick checks, then solve six Mystery Cards. |
| 10–13 min | CP2 Equipment Match | Pupils drag (or tap, then tap) the equipment pictures onto the correct sport. |
| 13–18 min | CP3 Grammar Decoder | Pupils open each **Sentence Card**, find its clue on the **Decoder Wheel** and type the superlative. |
| 18–21 min | CP4 Virtual Referee | Pupils watch the **YouTube lesson video** (internet needed), then answer six timed questions (20 seconds each). |
| 21–26 min | CP5 Sports Reporter | Pupils build a report on the **Reporter Card**, submit it for feedback and practise aloud. |
| 26–30 min | CP6 Champion Zone | Five final questions, then badges, a reflection and the certificate. |

## Checkpoint guidance

**Checkpoint 1 — Sports Detective (12 tasks).** Six Fact File quick checks and six Mystery Cards. The Fact File text is exactly the unit text (badminton, football, swimming, cycling, basketball, ice hockey). Wrong choices are greyed out and the coach encourages a retry.

**Checkpoint 2 — Equipment Match.** Racket and shuttlecock → badminton · football → football · goggles → swimming · bicycle and helmet → cycling · basketball → basketball · hockey stick and puck → ice hockey. The pictures are drawn inside the game. Drag works with mouse and touch; tap-then-tap and keyboard (Tab, Enter) also work.

**Checkpoint 3 — Grammar Decoder.** Seven Sentence Cards in order: tallest, fastest, easiest, best, worst, most difficult, most popular. The typing box unlocks only when the wheel shows the card's clue word. Answers are accepted in any capitals, with extra spaces, and with or without "the". The adjective clue decides the answer; the sentences are not claims about which sport really is easiest or best.

**Checkpoint 4 — Virtual Referee.** The lesson video is your YouTube video (https://youtu.be/11e9IzV2cCQ), played inside the game. Use the game's Play, Pause, Replay, progress bar and volume, or YouTube's own controls. Turn on captions with **CC** inside the video. It needs an internet connection; if it can't play, pupils see a **Watch it on YouTube** link. **Please check the six questions:** they were written for the earlier suggested script and include superlatives (easiest, best, most difficult), which a vocabulary video may not cover. Edit `CP4_Q` in `script.js` if needed. If time runs out, the question restarts and counts as a retry (5 points).

**Checkpoint 5 — Sports Reporter.** Pupils choose a sport, a superlative and a reason, then submit. The feedback checks for a sport and "the + superlative" (needed), plus "because", a capital letter and a full stop (tips). Pupils then read their report aloud, can optionally record and play back, and press **I practised speaking my report aloud**. *This is a self-ticked practice step. The game does not listen to or assess pronunciation.* If you want to assess speaking, listen to the pupil yourself.

**Checkpoint 6 — Champion Zone.** Five questions (vocabulary, equipment, superlatives, sentence completion and reading), each with instant feedback. Then pupils see their points, stars, six badges, the trophy and confetti, write a reflection and print their certificate.

## Assessment notes

- **Formative:** instant feedback on every answer. 10 points first time, 5 after a retry.
- **Evidence:** the Teacher Panel shows points, stars, completed checkpoints and the reflection.
- **Speaking:** not assessed by the software. Use your own observation if needed.

## Troubleshooting

| Problem | Fix |
|---|---|
| No sound | Tap the screen first; check the coach's 🗣️ Voice is ON and 🔊 is not muted; check device volume. |
| "The coach is getting ready to speak…" | The ElevenLabs voice is creating that line for the first time. It is quicker next time (cached). |
| "Speech generation failed: …" | The message says why (key rejected, Voice ID not found, quota reached, no internet). Fix it in Netlify → Environment variables and redeploy. The words stay on screen. |
| "AUDIO NOT YET AVAILABLE" | That MP3 has not been added. See `assets/audio/NARRATION_SCRIPTS.txt` (or `narration-manifest.csv`) for the filename and words. Your preferred voice sample is in the Teacher Panel as a reference. |
| "VIDEO NEEDS AN INTERNET CONNECTION" | The CP4 video comes from YouTube. Connect to the internet and reopen Checkpoint 4. |
| Video shows "Sign in" or won't play | Press **Watch it on YouTube** under the video, or check that the school network allows YouTube. |
| Placeholder images | Add PNGs with the exact names in `assets/images/ADD_IMAGES_HERE.txt`. |
| Markers don't line up with my board | Edit `pos: [x, y]` (percentages) in `CHECKPOINTS` in `script.js`. |
| Progress not saving | Private/incognito browsing can block saving. Use a normal window. |
| New pupil on the same device | Press ↺ Reset. |
