/* =====================================================================
   THE ULTIMATE SPORTS QUEST — STADIUM ADVENTURE
   Vanilla JavaScript · no frameworks · no CDN · no external requests
   Year 4 ESL · Get Smart Plus 4 · Unit 9 Get Active!
   ===================================================================== */
(function () {
  'use strict';

  /* ------------------------------------------------------------------
     1. ASSET REGISTER (relative paths only)
     Add your files with these exact names to switch placeholders off.
     ------------------------------------------------------------------ */
  /* ONLINE_VOICE: the optional ElevenLabs server function (/api/tts) only exists on Netlify.
     GitHub Pages is static-only, so it is OFF by default (no failing network calls).
     Set to true ONLY if you host on Netlify with the tts function configured. */
  var ONLINE_VOICE = false;
  var DIR = { image: 'assets/images/', audio: 'assets/audio/', video: 'assets/video/', captions: 'assets/video/' };
  var ASSET_LIST = [
    ['image', 'board', 'sports-quest-board.png', 'Sports Quest Board — interactive checkpoint map'],
    // Virtual Sports Coach — cut from the teacher's original artwork (assets/images/coach-source/)
    ['image', 'coach_welcome', 'coach-welcome.jpg', 'Virtual Sports Coach — welcoming pupils (peace sign, full pose)'],
    ['image', 'coach_wave', 'coach-wave.jpg', 'Virtual Sports Coach — greeting / giving screen instructions (peace sign)'],
    ['image', 'coach_instruct', 'coach-instructions.jpg', 'Virtual Sports Coach — idle / giving instructions (smiling)'],
    ['image', 'coach_thumbs', 'coach-thumbs-up.jpg', 'Virtual Sports Coach — correct answer (thumbs up)'],
    ['image', 'coach_celebrate', 'coach-celebrate.jpg', 'Virtual Sports Coach — correct answer (excited cheer)'],
    ['image', 'coach_encourage', 'coach-encourage.jpg', 'Virtual Sports Coach — incorrect answer (thinking)'],
    ['image', 'coach_unlock', 'coach-unlock.jpg', 'Virtual Sports Coach — unlocking a checkpoint (surprised)'],
    ['image', 'coach_achieve', 'coach-achievement.jpg', 'Virtual Sports Coach — checkpoint completed (fists up)'],
    ['image', 'coach_proud', 'coach-proud.jpg', 'Virtual Sports Coach — final celebration (proud, hearts)'],
    ['image', 'coach_champion', 'coach-champion.jpg', 'Virtual Sports Coach — Champion Hall (fists up, full pose)'],
    // Equipment photos are OPTIONAL: the game has its own drawn equipment illustrations (EQUIP_SVG).
    ['image', 'eq_badminton', 'equipment-racket-shuttlecock.png', 'Optional photo — racket and shuttlecock (replaces the built-in drawing)', 'optional'],
    ['image', 'eq_football', 'equipment-football.png', 'Optional photo — football (replaces the built-in drawing)', 'optional'],
    ['image', 'eq_swimming', 'equipment-goggles.png', 'Optional photo — goggles (replaces the built-in drawing)', 'optional'],
    ['image', 'eq_cycling', 'equipment-bicycle-helmet.png', 'Optional photo — bicycle and helmet (replaces the built-in drawing)', 'optional'],
    ['image', 'eq_basketball', 'equipment-basketball.png', 'Optional photo — basketball (replaces the built-in drawing)', 'optional'],
    ['image', 'eq_icehockey', 'equipment-hockey-stick-puck.png', 'Optional photo — hockey stick and puck (replaces the built-in drawing)', 'optional'],
    ['audio', 'music', 'background-music.mp3', 'Optional background music (a synthesised loop is used if missing)', 'optional'],
    // Checkpoint 4 video is the teacher's YouTube video (YT_ID below), embedded — no local MP4 is required.
    // Teacher's preferred coach voice: a STYLE REFERENCE for recording/generating the narration. It is not played to pupils.
    ['audio', 'voice_ref', 'reference/coach-voice-reference.mp3', 'Coach voice style reference (teacher upload, not used as narration)', 'optional']
    // All narration MP3s are added from the NARRATION manifest below.
  ];
  var A = {};
  ASSET_LIST.forEach(function (r) { A[r[1]] = DIR[r[0]] + r[2]; });
  var status = {}; // path -> true (found) | false (missing) | undefined (unchecked)

  /* ------------------------------------------------------------------
     2. GAME CONTENT
     ------------------------------------------------------------------ */
  var TEAMS = [
    { id: 'blue', name: 'Blue Lightning', mascot: '⚡', color: '#1f6bff', dark: '#0b3bb0', cheer: 'Fast as lightning!' },
    { id: 'green', name: 'Green Dragons', mascot: '🐉', color: '#22b04b', dark: '#127030', cheer: 'Brave as dragons!' },
    { id: 'orange', name: 'Orange Rockets', mascot: '🚀', color: '#ff7a1a', dark: '#b84c00', cheer: 'Blast off to win!' },
    { id: 'purple', name: 'Purple Panthers', mascot: '🐆', color: '#8a3ffc', dark: '#5317b3', cheer: 'Quick and clever!' }
  ];

  // Map hotspot positions in % of the board (x, y). Adjust to fit your Sports Quest Board.
  var CHECKPOINTS = [
    { n: 1, name: 'Sports Detective', focus: 'Reading & sports vocabulary', icon: '🔍', pos: [13, 78] },
    { n: 2, name: 'Equipment Match', focus: 'Matching sports equipment', icon: '🧩', pos: [37, 66] },
    { n: 3, name: 'Grammar Decoder', focus: 'Superlative adjectives', icon: '🔐', pos: [24, 33] },
    { n: 4, name: 'Virtual Referee', focus: 'Quick-fire game show', icon: '🟨', pos: [52, 22] },
    { n: 5, name: 'Sports Reporter', focus: 'Building & speaking a report', icon: '🎙️', pos: [72, 52] },
    { n: 6, name: 'Champion Zone', focus: 'Final assessment', icon: '🏆', pos: [87, 22] }
  ];

  var SPORTS = {
    badminton: { name: 'Badminton', icon: '🏸', clue: 'Players hit a shuttlecock over a net.' },
    football: { name: 'Football', icon: '⚽', clue: 'Players kick a ball to score goals.' },
    swimming: { name: 'Swimming', icon: '🏊', clue: 'People move through water using their arms and legs.' },
    cycling: { name: 'Cycling', icon: '🚴', clue: 'People ride bicycles and wear helmets.' },
    basketball: { name: 'Basketball', icon: '🏀', clue: 'Players shoot a ball into a hoop.' },
    icehockey: { name: 'Ice Hockey', icon: '🏒', clue: 'Players use sticks to hit a puck on ice.' }
  };
  var SPORT_IDS = Object.keys(SPORTS);

  var EQUIP = {
    badminton: { label: 'Racket and Shuttlecock', icon: '🏸' },
    football: { label: 'Football', icon: '⚽' },
    swimming: { label: 'Goggles', icon: '🥽' },
    cycling: { label: 'Bicycle and Helmet', icon: '🚲' },
    basketball: { label: 'Basketball', icon: '🏀' },
    icehockey: { label: 'Hockey Stick and Puck', icon: '🏒' }
  };
  var TRAY_ORDER = ['icehockey', 'swimming', 'badminton', 'basketball', 'cycling', 'football'];

  var RULE_HINT = {
    short: 'Short word: add -est.',
    y: 'Word ends in -y: change y to i, then add -est.',
    long: 'Long word: use "most" before the word.',
    good: 'Special word! GOOD changes completely.',
    bad: 'Special word! BAD changes completely.'
  };
  var CP3 = [
    { adj: 'TALL', answer: 'tallest', sentence: 'He is the ______ basketball player.', rule: 'short' },
    { adj: 'FAST', answer: 'fastest', sentence: 'I think cycling is the ______ sport.', rule: 'short' },
    { adj: 'EASY', answer: 'easiest', sentence: 'I think swimming is the ______ sport.', rule: 'y' },
    { adj: 'GOOD', answer: 'best', sentence: 'I think badminton is the ______ sport.', rule: 'good' },
    { adj: 'BAD', answer: 'worst', sentence: 'I think football is the ______ sport for me.', rule: 'bad' },
    { adj: 'DIFFICULT', answer: 'most difficult', sentence: 'I think ice hockey is the ______ sport.', rule: 'long' },
    { adj: 'POPULAR', answer: 'most popular', sentence: 'I think football is the ______ sport.', rule: 'long' }
  ];

  var CP4_Q = [
    { q: 'Which equipment do you need to play badminton?', opts: ['Racket and shuttlecock', 'Goggles', 'Hockey stick and puck'], a: 0 },
    { q: 'Swimming is the ______ sport for me. (EASY)', opts: ['easyest', 'easiest', 'most easy'], a: 1 },
    { q: 'In which sport do players hit a puck on ice?', opts: ['Football', 'Ice hockey', 'Cycling'], a: 1 },
    { q: 'GOOD → the ______', opts: ['goodest', 'most good', 'best'], a: 2 },
    { q: 'Players shoot a ball into a hoop. Which sport is it?', opts: ['Basketball', 'Badminton', 'Swimming'], a: 0 },
    { q: 'Ice hockey is the ______ sport. (DIFFICULT)', opts: ['difficultest', 'most difficult', 'more difficult'], a: 1 }
  ];
  var CP4_TIME = 20;

  var CP5 = {
    sport: SPORT_IDS.map(function (id) { return SPORTS[id].name; }),
    sup: ['most exciting', 'best', 'fastest', 'easiest', 'most popular', 'healthiest', 'most difficult'],
    reason: ['it is fun to play', 'it keeps me healthy', 'I can play with my friends', 'it is very fast', 'it makes me strong']
  };

  var CP6_Q = [
    { type: 'Sports Vocabulary', q: 'Which sport do people do in water?', opts: ['Cycling', 'Swimming', 'Basketball', 'Football'], a: 1 },
    { type: 'Equipment', q: 'Look at the equipment. Which sport needs it?', visual: 'icehockey', opts: ['Badminton', 'Football', 'Ice hockey', 'Swimming'], a: 2 },
    { type: 'Superlatives', q: 'BAD → the ______', opts: ['baddest', 'worst', 'most bad', 'badest'], a: 1 },
    { type: 'Sentence Completion', q: 'Ali runs very fast. He is the ______ runner in our class.', opts: ['fast', 'faster', 'fastest', 'most fast'], a: 2 },
    { type: 'Reading', passage: 'Mei Ling loves sports. She plays badminton on Monday and goes swimming on Saturday. She thinks swimming is the most relaxing sport because she enjoys the cool water.', q: 'Why does Mei Ling think swimming is the most relaxing sport?', opts: ['Because she plays on Monday', 'Because she enjoys the cool water', 'Because she likes shuttlecocks', 'Because it is the fastest sport'], a: 1 }
  ];

  var PRAISE = ['Brilliant!', 'Super star!', 'Fantastic!', 'Well done, champion!', 'Amazing!', 'You got it!', 'Excellent work!'];
  var ENCOURAGE = ['Nice try! Look again.', 'Almost! Try once more.', 'Keep going — you can do it!', 'Don\'t give up, champion!'];

  /* Digital Sports Fact Files (Checkpoint 1) — exact teacher text. */
  var FACTS = {
    badminton: { text: 'Badminton is played with a racket and a shuttlecock. Players hit the shuttlecock over a net. It can be played indoors or outdoors.',
      q: 'What do badminton players hit over the net?', opts: ['A puck', 'A shuttlecock', 'A basketball'], a: 1 },
    football: { text: 'Football is played on a field. Players kick a ball and try to score goals. Each team has eleven players in a standard match.',
      q: 'How many players does each team have in a standard football match?', opts: ['Eleven', 'Six', 'Two'], a: 0 },
    swimming: { text: 'Swimming takes place in a pool or open water. Swimmers move through the water using their arms and legs. They may wear goggles to protect their eyes.',
      q: 'Why may swimmers wear goggles?', opts: ['To protect their heads', 'To kick the ball', 'To protect their eyes'], a: 2 },
    cycling: { text: 'Cycling is an activity that uses a bicycle. Cyclists wear helmets to protect their heads. They can cycle on roads or special cycling tracks.',
      q: 'Why do cyclists wear helmets?', opts: ['To protect their heads', 'To swim faster', 'To hit a puck'], a: 0 },
    basketball: { text: 'Basketball is played by two teams. Players pass and bounce a ball before shooting it into a hoop.',
      q: 'Where do basketball players shoot the ball?', opts: ['Into a goal net on ice', 'Into a hoop', 'Over a badminton net'], a: 1 },
    icehockey: { text: 'Ice hockey is played on ice. Players wear skates and use sticks to move a puck. Helmets and protective equipment help keep players safe.',
      q: 'What do ice hockey players use to move the puck?', opts: ['Rackets', 'Their hands', 'Sticks'], a: 2 }
  };

  /* ------------------------------------------------------------------
     NARRATION MANIFEST — one place that links every narrated moment to
     its local MP3 file and its transcript (shown as subtitles).
     group 'coach' = coach voice lines · 'learning' = listening material.
     ------------------------------------------------------------------ */
  var NARRATION = {
    welcome: { group: 'coach', screen: 'Welcome screen', file: 'coach/coach-welcome.mp3', mood: 'wave', text: 'Hello, young champions! Welcome to The Ultimate Sports Quest! I\'m your Virtual Sports Coach, and I\'ll guide you through six exciting challenges. Are you ready to begin? Let\'s go!' },
    team: { group: 'coach', screen: 'Team selection', file: 'coach/coach-team.mp3', mood: 'wave', text: 'Choose your team and get ready to explore! Every great champion starts with a team. Let\'s work together and have fun!' },
    objectives: { group: 'learning', screen: 'Introduction & learning objectives', file: 'learning-objectives.mp3', mood: 'explain', text: 'Here is your mission! By the end of this adventure, you can do three things. One: identify different sports and their equipment. Two: use superlative adjectives correctly. Three: create simple sentences to talk about sports.' },
    cp1: { group: 'coach', screen: 'Checkpoint 1 — Sports Detective', file: 'coach/coach-checkpoint-1.mp3', mood: 'intro', text: 'Welcome to Sports Detective! Read the clues carefully and find the correct sport. You can use your Sports Fact File to help you!' },
    cp2: { group: 'coach', screen: 'Checkpoint 2 — Equipment Match', file: 'coach/coach-checkpoint-2.mp3', mood: 'intro', text: 'Great job, champions! Now match each sport with the correct equipment. Drag the equipment to the right place!' },
    cp3: { group: 'coach', screen: 'Checkpoint 3 — Grammar Decoder', file: 'coach/coach-checkpoint-3.mp3', mood: 'intro', text: 'It\'s time for the Grammar Decoder! Take your Sentence Card, spin your Decoder Wheel, and find the correct superlative adjective!' },
    cp4: { group: 'coach', screen: 'Checkpoint 4 — Virtual Referee', file: 'coach/coach-checkpoint-4.mp3', mood: 'intro', text: 'Welcome to the Virtual Referee Challenge! Watch carefully, listen closely, and choose the correct answer!' },
    cp5: { group: 'coach', screen: 'Checkpoint 5 — Sports Reporter', file: 'coach/coach-checkpoint-5.mp3', mood: 'intro', text: 'You\'re a sports reporter now! Use your Reporter Card and tell us about your favourite sport. Speak clearly and confidently!' },
    cp6: { group: 'coach', screen: 'Checkpoint 6 — Champion Zone', file: 'coach/coach-checkpoint-6.mp3', mood: 'intro', text: 'You\'ve made it to the Champion Zone! Complete the final challenge and show us what you\'ve learned!' },
    correct1: { group: 'coach', screen: 'Correct answer', file: 'coach/coach-correct-1.mp3', mood: 'correct', text: 'Excellent work!' },
    correct2: { group: 'coach', screen: 'Correct answer', file: 'coach/coach-correct-2.mp3', mood: 'correct', text: 'That\'s correct!' },
    correct3: { group: 'coach', screen: 'Correct answer', file: 'coach/coach-correct-3.mp3', mood: 'correct', text: 'Fantastic job!' },
    correct4: { group: 'coach', screen: 'Correct answer', file: 'coach/coach-correct-4.mp3', mood: 'correct', text: 'You\'re doing great!' },
    wrong1: { group: 'coach', screen: 'Incorrect answer', file: 'coach/coach-try-again-1.mp3', mood: 'wrong', text: 'Good try! Let\'s try again!' },
    wrong2: { group: 'coach', screen: 'Incorrect answer', file: 'coach/coach-try-again-2.mp3', mood: 'wrong', text: 'Not quite! Look at the clue carefully.' },
    wrong3: { group: 'coach', screen: 'Incorrect answer', file: 'coach/coach-try-again-3.mp3', mood: 'wrong', text: 'Keep going! You can do it!' },
    complete: { group: 'coach', screen: 'Checkpoint completed', file: 'coach/coach-checkpoint-complete.mp3', mood: 'complete', text: 'Congratulations! You\'ve completed this checkpoint. Let\'s move on!' },
    final: { group: 'coach', screen: 'Final celebration', file: 'coach/coach-final-celebration.mp3', mood: 'final', text: 'Congratulations, champions! You\'ve completed The Ultimate Sports Quest! I\'m so proud of your hard work!' },
    grammar: { group: 'learning', screen: 'Grammar note — superlatives (CP3 + Notes)', file: 'grammar-explanation.mp3', mood: 'explain', text: 'We use superlatives to compare three or more things. For short words, add e-s-t. Tall becomes tallest. Fast becomes fastest. For words ending in y, change y to i, then add e-s-t. Easy becomes easiest. For long words, put most before the word. Difficult becomes most difficult. Popular becomes most popular. Some words change completely. Good becomes best. Bad becomes worst. Remember to use the before a superlative: the tallest, the best, the most popular.' },
  };
  // Fact Files are read-only (no narration buttons), so they have no audio entries.
  Object.keys(NARRATION).forEach(function (k) {
    var n = NARRATION[k];
    ASSET_LIST.push(['audio', 'au_' + k, n.file, (n.group === 'coach' ? 'Coach voice — ' : 'Listening — ') + n.screen + ': “' + (n.text.length > 70 ? n.text.slice(0, 67) + '…' : n.text) + '”']);
    A['au_' + k] = DIR.audio + n.file;
  });

  /* ------------------------------------------------------------------
     3. STATE + localStorage
     ------------------------------------------------------------------ */
  var STORE_KEY = 'ultimateSportsQuest.v1';
  var storageOK = true;
  function defaultState() {
    return {
      team: null, points: 0, stars: 0, completed: [], answered: {}, attempts: {},
      screen: 'welcome', reportText: '', reportChecked: false, teacherConfirmed: false,
      reflection: '', pupilName: '', sound: true,
      voice: true, voiceVol: 0.9, muted: false
    };
  }
  function load() {
    try {
      var raw = localStorage.getItem(STORE_KEY);
      if (raw) {
        var s = defaultState(), p = JSON.parse(raw); for (var k in p) s[k] = p[k];
        return s;
      }
    } catch (e) { storageOK = false; }
    return defaultState();
  }
  function save() {
    try { localStorage.setItem(STORE_KEY, JSON.stringify(state)); storageOK = true; } catch (e) { storageOK = false; }
  }
  var state = load();
  var music = false;

  function teamObj() { for (var i = 0; i < TEAMS.length; i++) if (TEAMS[i].id === state.team) return TEAMS[i]; return null; }
  function isDone(n) { return state.completed.indexOf(n) !== -1; }
  function isUnlocked(n) { return n === 1 || isDone(n - 1); }
  function currentCP() { for (var i = 1; i <= 6; i++) if (!isDone(i)) return i; return 6; }
  function answered(qid) { return state.answered[qid] !== undefined; }

  /* Scoring: 10 on first try, 5 after a retry, never twice for the same item. */
  function award(qid, correct) {
    if (answered(qid)) return { already: true, pts: 0 };
    if (correct) {
      var pts = (state.attempts[qid] || 0) === 0 ? 10 : 5;
      state.answered[qid] = pts; state.points += pts; save(); updateHUD(true);
      return { pts: pts, retry: pts === 5 };
    }
    state.attempts[qid] = (state.attempts[qid] || 0) + 1; save();
    return { pts: 0 };
  }

  /* ------------------------------------------------------------------
     4. HELPERS
     ------------------------------------------------------------------ */
  function $(s, r) { return (r || document).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function pick(a) { return a[Math.floor(Math.random() * a.length)]; }
  /* Pick a narration line whose MP3 exists (never one known to be missing). Falls back to the
     full list only if none are available, in which case the line shows as subtitles. */
  function pickLine(keys) {
    var ok = keys.filter(function (k) { return status[A['au_' + k]] !== false; });
    return pick(ok.length ? ok : keys);
  }
  var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  var playToken = 0;
  function later(fn, ms) { var t = playToken; return setTimeout(function () { if (t === playToken) fn(); }, ms); }

  function fileOf(p) { return p.split('/').pop(); }

  /* Image with an honest, clearly-labelled placeholder if the file is missing. */
  function phHTML(cls, icon, label, src) {
    return '<div class="placeholder ' + cls + '" title="Missing asset: ' + esc(src) + '"><span class="ph-icon">' + icon + '</span><span class="ph-label">' + esc(label) + '</span><span class="ph-file">' + esc(fileOf(src)) + '</span></div>';
  }
  function imgTag(key, alt, cls, icon, label) {
    var src = A[key];
    if (status[src] === false) return phHTML(cls, icon, label, src);
    return '<img class="' + cls + '" src="' + src + '" alt="' + esc(alt) + '" data-ph-icon="' + esc(icon) + '" data-ph-label="' + esc(label) + '" onload="SQ.imgOk(this)" onerror="SQ.imgFail(this)" draggable="false">';
  }
  window.SQ = {
    imgOk: function (img) { status[img.getAttribute('src')] = true; },
    imgFail: function (img) {
      var src = img.getAttribute('src');
      status[src] = false;
      var d = document.createElement('div');
      d.innerHTML = phHTML(img.className, img.dataset.phIcon || '🖼️', img.dataset.phLabel || 'Image placeholder', src);
      img.replaceWith(d.firstChild);
      refreshTeacher();
    },
    boardOk: function (img) {
      status[img.getAttribute('src')] = true;
      var b = img.closest('.board');
      if (b) {
        b.classList.add('has-board');
        if (img.naturalWidth && img.naturalHeight) b.style.setProperty('--ar', (img.naturalWidth / img.naturalHeight).toFixed(4));
      }
    },
    boardFail: function (img) {
      status[img.getAttribute('src')] = false;
      var b = img.closest('.board'); if (b) b.classList.add('no-board');
      img.remove(); refreshTeacher();
    }
  };

  window.SQ.narration = NARRATION; // read-only view of the manifest (used to export the recording scripts)

  function coachImg(mood, cls) {
    var labels = { welcome: 'Coach: welcome', wave: 'Coach: greeting', instruct: 'Coach: instructions', thumbs: 'Coach: thumbs up', celebrate: 'Coach: celebrate', encourage: 'Coach: encourage', unlock: 'Coach: unlock', achieve: 'Coach: achievement', proud: 'Coach: proud', champion: 'Coach: champion' };
    return '<div class="coach ' + (cls || '') + '">' + imgTag('coach_' + mood, 'Virtual Sports Coach', 'coach-img', '🧕', (labels[mood] || 'Coach') + ' placeholder') + '</div>';
  }

  function audioCtl(key, label) {
    var missing = status[A['au_' + key]] === false;
    return '<span class="audio-ctl' + (missing ? ' missing' : '') + '"><button type="button" class="btn-audio" data-audio="' + key + '" data-label="' + esc(label) + '"><span class="ab-icon">' + (missing ? '🔇' : '▶') + '</span><span class="ab-text">' + esc(label) + '</span></button><span class="audio-status" role="status">' + (missing ? 'AUDIO NOT YET AVAILABLE' : '') + '</span></span>';
  }

  var TROPHY = '<svg class="trophy-svg" viewBox="0 0 200 230" aria-hidden="true"><defs><linearGradient id="tg" x1="0" x2="1"><stop offset="0" stop-color="#ffb300"/><stop offset=".45" stop-color="#ffe27a"/><stop offset="1" stop-color="#e09200"/></linearGradient></defs>' +
    '<path d="M48 40 H20 a8 8 0 0 0-8 8 c0 34 18 58 46 62" fill="none" stroke="#e09200" stroke-width="12" stroke-linecap="round"/>' +
    '<path d="M152 40 H180 a8 8 0 0 1 8 8 c0 34-18 58-46 62" fill="none" stroke="#e09200" stroke-width="12" stroke-linecap="round"/>' +
    '<path d="M44 22 H156 V70 c0 38-25 66-56 66 s-56-28-56-66z" fill="url(#tg)" stroke="#b87400" stroke-width="5"/>' +
    '<rect x="88" y="134" width="24" height="34" fill="#e09200"/><rect x="58" y="166" width="84" height="22" rx="6" fill="url(#tg)" stroke="#b87400" stroke-width="4"/>' +
    '<rect x="44" y="188" width="112" height="30" rx="8" fill="#5420b0" stroke="#2c0c66" stroke-width="4"/><text x="100" y="209" text-anchor="middle" font-size="15" font-weight="900" fill="#ffc928" font-family="Trebuchet MS, sans-serif">CHAMPION</text>' +
    '<path d="M100 46 l8 17 19 3-14 13 4 19-17-9-17 9 4-19-14-13 19-3z" fill="#fff" opacity=".95"/><path class="trophy-shine" d="M62 32 h14 l-10 70 h-10z" fill="#fff" opacity=".45"/></svg>';

  var PADLOCK = '<svg viewBox="0 0 100 120" aria-hidden="true"><path class="shackle" d="M28 56 V36 a22 22 0 0 1 44 0 V56" fill="none" stroke="#a8b2d6" stroke-width="11" stroke-linecap="round"/><rect x="14" y="52" width="72" height="60" rx="14" fill="#ffc928" stroke="#c98a00" stroke-width="5"/><circle cx="50" cy="76" r="9" fill="#1a1f4a"/><rect x="45.5" y="79" width="9" height="19" rx="3" fill="#1a1f4a"/></svg>';

  var REFEREE = '<svg class="ref-svg" viewBox="0 0 140 170" aria-hidden="true"><defs><pattern id="refStripes" width="16" height="10" patternUnits="userSpaceOnUse"><rect width="8" height="10" fill="#1a1f4a"/><rect x="8" width="8" height="10" fill="#fff"/></pattern></defs>' +
    '<g class="ref-waves" stroke="#ffc928" stroke-width="4" fill="none" stroke-linecap="round"><path d="M104 38 q8 8 0 16"/><path d="M112 32 q14 14 0 28"/><path d="M120 26 q20 20 0 40"/></g>' +
    '<rect x="34" y="78" width="72" height="70" rx="18" fill="url(#refStripes)" stroke="#1a1f4a" stroke-width="3"/>' +
    '<rect x="48" y="146" width="16" height="20" rx="5" fill="#1a1f4a"/><rect x="76" y="146" width="16" height="20" rx="5" fill="#1a1f4a"/>' +
    '<g class="ref-card-arm"><rect x="12" y="84" width="14" height="44" rx="7" fill="#f2c29b" transform="rotate(20 19 106)"/><rect class="ref-card" x="2" y="54" width="22" height="30" rx="4" fill="#ffc928" stroke="#c98a00" stroke-width="2"/></g>' +
    '<circle cx="70" cy="50" r="28" fill="#f2c29b" stroke="#c98a6a" stroke-width="2"/>' +
    '<path d="M42 44 a28 28 0 0 1 56 0 z" fill="#1a1f4a"/><rect x="40" y="40" width="64" height="7" rx="3" fill="#1a1f4a"/>' +
    '<circle cx="60" cy="54" r="3.5" fill="#1a1f4a"/><circle cx="80" cy="54" r="3.5" fill="#1a1f4a"/><path class="ref-mouth" d="M62 66 q8 6 16 0" stroke="#1a1f4a" stroke-width="3" fill="none" stroke-linecap="round"/>' +
    '<g class="ref-whistle"><rect x="80" y="62" width="20" height="10" rx="5" fill="#c0c8e0" stroke="#5a6488" stroke-width="2"/><circle cx="98" cy="67" r="7" fill="#c0c8e0" stroke="#5a6488" stroke-width="2"/></g>' +
    '<rect x="104" y="80" width="14" height="40" rx="7" fill="#f2c29b" transform="rotate(-25 111 100)"/></svg>';

  var MIC = '<svg class="mic-svg" viewBox="0 0 60 120" aria-hidden="true"><rect x="27" y="54" width="6" height="50" fill="#3c4266"/><rect x="10" y="102" width="40" height="10" rx="5" fill="#262a4a"/><rect x="15" y="6" width="30" height="52" rx="15" fill="#d7ddf0" stroke="#5a6488" stroke-width="3"/><g stroke="#8b94b8" stroke-width="2"><line x1="17" y1="18" x2="43" y2="18"/><line x1="16" y1="27" x2="44" y2="27"/><line x1="16" y1="36" x2="44" y2="36"/></g><rect x="13" y="44" width="34" height="12" rx="4" fill="#ff7a1a"/><text x="30" y="53.5" text-anchor="middle" font-size="8" font-weight="900" fill="#fff" font-family="sans-serif">SQ</text></svg>';

  /* Built-in equipment illustrations (original SVG drawn in code for this game).
     If the teacher adds the optional PNG photo, eqArt() shows that instead. */
  var EQUIP_SVG = {
    badminton: '<svg viewBox="0 0 120 90" aria-hidden="true"><g transform="rotate(-30 40 45)"><rect x="37" y="48" width="6" height="34" rx="3" fill="#2a2f5a"/><rect x="36" y="66" width="8" height="18" rx="3" fill="#ff7a1a"/><ellipse cx="40" cy="28" rx="17" ry="23" fill="#fff" stroke="#1f4fd8" stroke-width="5"/>' +
      '<g stroke="#9fb3e6" stroke-width="1.2"><line x1="30" y1="10" x2="30" y2="46"/><line x1="36" y1="6" x2="36" y2="50"/><line x1="42" y1="6" x2="42" y2="50"/><line x1="48" y1="9" x2="48" y2="47"/><line x1="25" y1="18" x2="55" y2="18"/><line x1="24" y1="26" x2="56" y2="26"/><line x1="24" y1="34" x2="56" y2="34"/><line x1="26" y1="42" x2="54" y2="42"/></g></g>' +
      '<g transform="rotate(25 88 44)"><path d="M78 20 L98 20 L94 50 L82 50 Z" fill="#fff" stroke="#8b94b8" stroke-width="2"/><g stroke="#c9d0e6" stroke-width="1.5"><line x1="84" y1="21" x2="85" y2="49"/><line x1="88" y1="21" x2="88" y2="49"/><line x1="92" y1="21" x2="91" y2="49"/></g><rect x="80" y="47" width="16" height="4" fill="#d6336c"/><ellipse cx="88" cy="56" rx="8" ry="6" fill="#f2c29b" stroke="#c98a6a" stroke-width="2"/></g></svg>',
    football: '<svg viewBox="0 0 120 90" aria-hidden="true"><ellipse cx="60" cy="84" rx="30" ry="4" fill="rgba(0,0,0,.18)"/><circle cx="60" cy="44" r="36" fill="#fff" stroke="#1a1f4a" stroke-width="4"/>' +
      '<path d="M60 30 l13 9 -5 15 h-16 l-5 -15z" fill="#1a1f4a"/><g fill="#1a1f4a"><path d="M60 9 l8 5 -2 7 h-12 l-2 -7z"/><path d="M27 33 l7 -6 6 4 -3 11 -9 2z"/><path d="M93 33 l-7 -6 -6 4 3 11 9 2z"/><path d="M38 70 l3 -10 10 1 2 9 -8 5z"/><path d="M82 70 l-3 -10 -10 1 -2 9 8 5z"/></g>' +
      '<g stroke="#1a1f4a" stroke-width="2.5" fill="none"><path d="M60 21 V30"/><path d="M47 39 L37 37"/><path d="M73 39 L83 37"/><path d="M52 54 L48 61"/><path d="M68 54 L72 61"/></g></svg>',
    swimming: '<svg viewBox="0 0 120 90" aria-hidden="true"><path d="M6 46 C 20 30, 30 30, 34 40 M114 46 C 100 30, 90 30, 86 40" fill="none" stroke="#1a1f4a" stroke-width="6" stroke-linecap="round"/>' +
      '<rect x="22" y="30" width="34" height="28" rx="14" fill="#29a3e8" stroke="#1a1f4a" stroke-width="5"/><rect x="64" y="30" width="34" height="28" rx="14" fill="#29a3e8" stroke="#1a1f4a" stroke-width="5"/>' +
      '<path d="M56 42 q4 -5 8 0" fill="none" stroke="#1a1f4a" stroke-width="5"/><path d="M29 38 q6 -5 14 -2" stroke="#fff" stroke-width="4" fill="none" stroke-linecap="round" opacity=".8"/><path d="M71 38 q6 -5 14 -2" stroke="#fff" stroke-width="4" fill="none" stroke-linecap="round" opacity=".8"/>' +
      '<path d="M10 76 q10 -6 20 0 t20 0 t20 0 t20 0 t20 0" fill="none" stroke="#7fd0ff" stroke-width="4" stroke-linecap="round"/></svg>',
    cycling: '<svg viewBox="0 0 120 90" aria-hidden="true"><g fill="none" stroke="#1a1f4a" stroke-width="4"><circle cx="26" cy="64" r="18"/><circle cx="84" cy="64" r="18"/></g><g stroke="#8b94b8" stroke-width="1.5"><line x1="26" y1="46" x2="26" y2="82"/><line x1="8" y1="64" x2="44" y2="64"/><line x1="84" y1="46" x2="84" y2="82"/><line x1="66" y1="64" x2="102" y2="64"/></g>' +
      '<g fill="none" stroke="#e0234e" stroke-width="5" stroke-linejoin="round" stroke-linecap="round"><path d="M26 64 L46 40 L74 40 L84 64"/><path d="M46 40 L56 64 L74 40"/><path d="M26 64 H56"/><path d="M74 40 L72 30 H80"/><path d="M46 40 L44 32"/></g><rect x="36" y="28" width="16" height="5" rx="2.5" fill="#1a1f4a"/>' +
      '<g transform="translate(78 2)"><path d="M2 22 C 2 6, 38 6, 38 22 Z" fill="#ffc928" stroke="#1a1f4a" stroke-width="3"/><path d="M10 14 h6 M20 11 h6 M30 14 h4" stroke="#1a1f4a" stroke-width="3" stroke-linecap="round"/><rect x="0" y="21" width="40" height="5" rx="2.5" fill="#1a1f4a"/></g></svg>',
    basketball: '<svg viewBox="0 0 120 90" aria-hidden="true"><ellipse cx="60" cy="84" rx="30" ry="4" fill="rgba(0,0,0,.18)"/><circle cx="60" cy="44" r="36" fill="#ff8a1f" stroke="#1a1f4a" stroke-width="4"/>' +
      '<g fill="none" stroke="#1a1f4a" stroke-width="3.5"><line x1="24" y1="44" x2="96" y2="44"/><line x1="60" y1="8" x2="60" y2="80"/><path d="M34 19 C 48 32, 48 56, 34 69"/><path d="M86 19 C 72 32, 72 56, 86 69"/></g><path d="M38 24 q8 -8 18 -10" stroke="#fff" stroke-width="4" fill="none" stroke-linecap="round" opacity=".5"/></svg>',
    icehockey: '<svg viewBox="0 0 120 90" aria-hidden="true"><path d="M30 6 L56 66 Q 60 74 70 74 L 100 74" fill="none" stroke="#8a5a2b" stroke-width="9" stroke-linecap="round" stroke-linejoin="round"/>' +
      '<path d="M68 74 H100" stroke="#1a1f4a" stroke-width="9" stroke-linecap="round"/><rect x="31" y="10" width="9" height="16" rx="3" transform="rotate(-23 35 18)" fill="#1a1f4a"/>' +
      '<ellipse cx="40" cy="80" rx="14" ry="5" fill="#111"/><rect x="26" y="74" width="28" height="6" fill="#111"/><ellipse cx="40" cy="74" rx="14" ry="5" fill="#333"/><path d="M8 86 H112" stroke="#bfe3fb" stroke-width="3"/></svg>'
  };
  function eqArt(id, cls) {
    var key = 'eq_' + id;
    if (status[A[key]] === true) return imgTag(key, EQUIP[id].label, cls || 'equip-img', EQUIP[id].icon, EQUIP[id].label);
    return '<span class="eq-art ' + (cls || 'equip-img') + '" role="img" aria-label="' + esc(EQUIP[id].label) + '">' + EQUIP_SVG[id] + '</span>';
  }

  /* ------------------------------------------------------------------
     5. SOUND (Web Audio API — original synthesised effects)
     ------------------------------------------------------------------ */
  var actx = null;
  function ac() {
    if (!actx) { var C = window.AudioContext || window.webkitAudioContext; if (!C) return null; try { actx = new C(); } catch (e) { return null; } }
    if (actx.state === 'suspended') actx.resume();
    return actx;
  }
  function tone(freq, dur, type, vol, when, slideTo, force) {
    if (!state.sound && !force) return;
    var c = ac(); if (!c) return;
    var t = c.currentTime + (when || 0);
    var o = c.createOscillator(), g = c.createGain();
    o.type = type || 'sine';
    o.frequency.setValueAtTime(freq, t);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol || 0.2, t + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(c.destination);
    o.start(t); o.stop(t + dur + 0.05);
  }
  var SFX = {
    click: function () { tone(700, 0.07, 'triangle', 0.12); },
    flip: function () { tone(320, 0.12, 'triangle', 0.12, 0, 720); },
    correct: function () { tone(523, 0.12, 'triangle', 0.2); tone(784, 0.25, 'triangle', 0.2, 0.1); },
    wrong: function () { tone(220, 0.3, 'sawtooth', 0.1, 0, 130); },
    star: function () { [1046, 1318, 1568, 2093].forEach(function (f, i) { tone(f, 0.16, 'sine', 0.12, i * 0.06); }); },
    unlock: function () { [523, 659, 784, 1046].forEach(function (f, i) { tone(f, 0.2, 'square', 0.07, i * 0.09); }); },
    drop: function () { tone(440, 0.12, 'triangle', 0.15, 0, 880); },
    tick: function () { tone(1250, 0.04, 'square', 0.05); },
    fanfare: function () {
      [[523, 0], [659, 0.15], [784, 0.3], [1046, 0.45], [784, 0.62], [1046, 0.75]].forEach(function (n) { tone(n[0], 0.3, 'square', 0.07, n[1]); tone(n[0] / 2, 0.3, 'triangle', 0.08, n[1]); });
    },
    whistle: function () {
      if (!state.sound) return;
      var c = ac(); if (!c) return;
      var t = c.currentTime, o = c.createOscillator(), lfo = c.createOscillator(), lg = c.createGain(), g = c.createGain();
      o.type = 'sine'; o.frequency.value = 2900; lfo.frequency.value = 28; lg.gain.value = 180;
      lfo.connect(lg); lg.connect(o.frequency);
      g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.16, t + 0.03);
      g.gain.setValueAtTime(0.16, t + 0.5); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.7);
      o.connect(g); g.connect(c.destination);
      o.start(t); lfo.start(t); o.stop(t + 0.75); lfo.stop(t + 0.75);
    }
  };

  /* Background music: uses background-music.mp3 if present, otherwise an
     original synthesised loop. Only starts after the pupil presses the button. */
  var Music = {
    el: null, timer: null, step: 0, usingSynth: false,
    start: function () {
      var self = this, src = A.music;
      if (status[src] === false) { self.synth(); return; }
      if (!self.el) {
        self.el = new Audio(src); self.el.loop = true; self.el.volume = 0.35;
        self.el.addEventListener('error', function () { status[src] = false; self.el = null; if (music) self.synth(); refreshTeacher(); });
      }
      self.el.play().then(function () { status[src] = true; }).catch(function (e) {
        if (e && e.name === 'NotSupportedError') { status[src] = false; self.el = null; if (music) self.synth(); }
      });
    },
    synth: function () {
      if (this.timer) return;
      this.usingSynth = true;
      var mel = [523, 659, 784, 659, 587, 698, 880, 698, 523, 659, 784, 1046, 988, 784, 659, 587];
      var bass = [131, 175, 131, 196];
      var self = this;
      this.timer = setInterval(function () {
        if (!ac()) return;
        var s = self.step++;
        if (s % 2 === 0 || s % 7 === 3) tone(mel[s % mel.length], 0.22, 'triangle', 0.035, 0, null, true);
        if (s % 4 === 0) tone(bass[(s / 4 | 0) % bass.length], 0.5, 'sine', 0.06, 0, null, true);
      }, 260);
    },
    stop: function () {
      if (this.el) this.el.pause();
      clearInterval(this.timer); this.timer = null; this.usingSynth = false;
    }
  };
  function toggleMusic() { music = !music; if (music) Music.start(); else Music.stop(); updateToggles(); }

  function setCtl(ctl, st) {
    if (!ctl || !ctl.isConnected) return;
    var btn = $('.btn-audio', ctl);
    ctl.classList.remove('playing', 'missing', 'loading');
    if (st === 'playing' || st === 'missing' || st === 'loading') ctl.classList.add(st);
    $('.ab-icon', btn).textContent = st === 'playing' ? '⏸' : st === 'missing' ? '🔇' : '▶';
    $('.ab-text', btn).textContent = st === 'playing' ? 'Pause' : st === 'paused' ? 'Resume' : btn.dataset.label;
    $('.audio-status', ctl).textContent = { missing: 'AUDIO NOT YET AVAILABLE', loading: 'Loading…', playing: 'Playing', paused: 'Paused' }[st] || '';
  }

  /* ------------------------------------------------------------------
     5b. VIRTUAL SPORTS COACH — floating character (teacher's original artwork)
     Nothing is spoken before the pupil's first tap/click/key press.
     ------------------------------------------------------------------ */
  // Each mood uses one of the teacher's real expressions + a CSS animation.
  var MOODS = {
    idle: { img: ['coach_instruct'], anim: 'float' },
    explain: { img: ['coach_instruct', 'coach_wave'], anim: 'bounce' },
    listen: { img: ['coach_proud'], anim: 'float' },
    wave: { img: ['coach_wave'], anim: 'bounce' },
    intro: { img: ['coach_wave', 'coach_instruct'], anim: 'bounce' },
    instruct: { img: ['coach_instruct'], anim: 'bounce' },
    think: { img: ['coach_encourage'], anim: 'bounce' },
    correct: { img: ['coach_thumbs', 'coach_celebrate'], anim: 'bounce', sparkle: true },
    wrong: { img: ['coach_encourage'], anim: 'shake' },
    unlock: { img: ['coach_unlock'], anim: 'bounce', sparkle: true },
    complete: { img: ['coach_celebrate', 'coach_achieve'], anim: 'celebrate', sparkle: true },
    final: { img: ['coach_proud', 'coach_achieve'], anim: 'celebrate', sparkle: true }
  };
  var OLD_MOOD = { welcome: 'wave', instruct: 'instruct', celebrate: 'correct', encourage: 'think', unlock: 'unlock', achieve: 'final' };

  var userActed = false;

  var Coach = {
    imgKey: null, hideT: null,
    render: function () {
      var d = $('#coach-dock'); if (!d) return;
      d.innerHTML =
        '<div class="cd-bubble" id="cd-bubble" role="status" aria-live="polite">' +
          '<button type="button" class="cd-close" data-action="bubble-close" aria-label="Hide speech bubble" title="Hide">✕</button>' +
          '<p class="cd-text" id="cd-text"></p><p class="cd-extra" id="cd-extra"></p>' +
          '<div class="cd-meta"><span class="cd-wave" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i></span><span class="cd-status" id="cd-status"></span></div>' +
        '</div>' +
        '<div class="cd-row">' +
          '<button type="button" class="cd-avatar" id="cd-avatar" data-action="replay" aria-label="Virtual Sports Coach. Tap to hear the instructions again.">' +
            '<span class="cd-img" id="cd-img"></span><span class="cd-spark" id="cd-spark" aria-hidden="true"></span></button>' +
          '<div class="cd-controls" role="group" aria-label="Coach voice controls">' +
            '<button type="button" class="cd-btn" data-action="voice" id="cd-voice" title="Voice on / off" aria-label="Voice on or off"><span class="ico">🔊</span><span class="lbl">Voice ON</span></button>' +
            '<button type="button" class="cd-btn" data-action="replay" title="Replay instructions" aria-label="Replay instructions"><span class="ico">↺</span><span class="lbl">Replay</span></button>' +
            '<button type="button" class="cd-btn" data-action="narr-toggle" id="cd-play" title="Play / pause narration" aria-label="Play or pause narration"><span class="ico">▶</span><span class="lbl">Play</span></button>' +
            '<button type="button" class="cd-btn" data-action="mute" id="cd-mute" title="Mute / unmute" aria-label="Mute or unmute"><span class="ico">🔊</span><span class="lbl">Mute</span></button>' +
            '<label class="cd-vol" title="Voice volume"><span aria-hidden="true">🔉</span><input type="range" id="cd-vol" min="0" max="1" step="0.05" aria-label="Voice volume"></label>' +
          '</div>' +
        '</div>';
      $('#cd-vol').value = state.voiceVol;
      $('#cd-vol').addEventListener('input', function (e) {
        state.voiceVol = +e.target.value; save();
        if (Voice.el) Voice.el.volume = state.voiceVol; // device voices apply volume from the next sentence (where supported)
      });
      this.setMood('idle');
      updateVoiceUI();
    },
    setMood: function (mood) {
      var m = MOODS[mood] || MOODS.idle, key = pick(m.img);
      if (key !== this.imgKey) {
        this.imgKey = key;
        $('#cd-img').innerHTML = imgTag(key, 'Virtual Sports Coach', 'cd-pic', '🧕', 'Coach image missing');
      }
      var av = $('#cd-avatar');
      ['float', 'bounce', 'shake', 'celebrate'].forEach(function (c) { av.classList.remove('anim-' + c); });
      void av.offsetWidth;
      av.classList.add('anim-' + m.anim);
      if (m.anim !== 'float') {
        clearTimeout(this.animT);
        this.animT = setTimeout(function () { av.classList.remove('anim-' + m.anim); av.classList.add('anim-float'); }, m.anim === 'celebrate' ? 2400 : 1300);
      }
      if (m.sparkle) this.sparkle();
    },
    sparkle: function () {
      if (reduceMotion) return;
      var box = $('#cd-spark'); if (!box) return;
      var html = '', ch = ['✦', '★', '✧', '✨'];
      for (var i = 0; i < 9; i++) {
        var ang = (i / 9) * Math.PI * 2;
        html += '<i style="--dx:' + Math.round(Math.cos(ang) * 64) + 'px;--dy:' + Math.round(Math.sin(ang) * 64) + 'px;animation-delay:' + (i % 3) * 0.08 + 's">' + ch[i % 4] + '</i>';
      }
      box.innerHTML = html;
      clearTimeout(this.sparkT);
      this.sparkT = setTimeout(function () { box.innerHTML = ''; }, 1400);
    },
    show: function (mood, text, extra) {
      clearTimeout(this.hideT);
      $('#cd-text').innerHTML = text;
      $('#cd-extra').innerHTML = extra || '';
      $('#cd-extra').classList.toggle('hidden', !extra);
      this.status('');
      var d = $('#coach-dock');
      d.classList.remove('mood-' + (d.dataset.mood || 'idle'));
      d.dataset.mood = mood; d.classList.add('mood-' + mood, 'open');
      $('#cd-bubble').classList.toggle('long', String(text).length > 200);
      restartAnim($('#cd-bubble'), 'pop-in');
      this.setMood(mood);
    },
    status: function (msg, warn) {
      var s = $('#cd-status'); if (!s) return;
      s.textContent = msg || ''; s.classList.toggle('warn', !!warn);
    },
    speaking: function (on) { $('#coach-dock').classList.toggle('speaking', !!on); updateVoiceUI(); },
    hideLater: function (ms) {
      var self = this; clearTimeout(this.hideT);
      this.hideT = setTimeout(function () { if (Voice.mode) return; $('#coach-dock').classList.remove('open'); self.setMood('idle'); }, ms || 4500);
    },
    hide: function () { clearTimeout(this.hideT); $('#coach-dock').classList.remove('open'); }
  };

  /* ------------------------------------------------------------------
     COACH VOICE (ElevenLabs) — one consistent voice for every line.
     The browser never sees the API key: it asks the site's own server
     function (/api/tts, netlify/functions/tts.mts) for a fixed line by key.
     Generated audio is cached by the CDN, the browser and in memory.
     Only used when a local MP3 is not present (local files always win, so
     the exported offline pack works with no internet connection).
     ------------------------------------------------------------------ */
  function lineHash(text) { var h = 5381; for (var i = 0; i < text.length; i++) h = ((h * 33) ^ text.charCodeAt(i)) >>> 0; return h.toString(36); }
  var AIVoice = {
    enabled: ONLINE_VOICE && (location.protocol === 'http:' || location.protocol === 'https:'),
    info: null, cache: {}, inflight: {},
    url: function (key) { return '/api/tts?key=' + encodeURIComponent(key) + '&v=' + lineHash(NARRATION[key].text); },
    check: function () {
      var self = this; if (!self.enabled) { self.info = { configured: false, offline: true }; return; }
      fetch('/api/tts?status=1', { cache: 'no-store' }).then(function (r) { return r.ok ? r.json() : null; })
        .then(function (j) { self.info = j && typeof j.configured === 'boolean' ? j : { configured: false, unreachable: true }; refreshTeacher(); })
        .catch(function () { self.info = { configured: false, unreachable: true }; refreshTeacher(); });
    },
    get: function (key) {
      var self = this;
      if (self.cache[key]) return Promise.resolve(self.cache[key]);
      if (self.inflight[key]) return self.inflight[key];
      var p = fetch(self.url(key)).then(function (r) {
        var ct = r.headers.get('content-type') || '';
        if (r.ok && ct.indexOf('audio') === 0) return r.blob();
        return r.json().catch(function () { return {}; }).then(function (j) { throw new Error(j.error || ('Speech generation failed (error ' + r.status + ').')); });
      }, function () { throw new Error('Could not reach the coach voice service. Check the internet connection.'); })
        .then(function (b) { var u = URL.createObjectURL(b); self.cache[key] = u; self.blobs[key] = b; delete self.inflight[key]; return u; },
          function (e) { delete self.inflight[key]; throw e; });
      self.inflight[key] = p; return p;
    },
    blobs: {}
  };

  /* ------------------------------------------------------------------
     NARRATOR — the one reusable HTML5 audio controller for every line in
     the NARRATION manifest. Order: 1) local MP3 in assets/audio/ (offline)
     2) ElevenLabs coach voice via /api/tts (online) 3) clear message.
     Play · Pause · Replay · Mute · Volume · subtitles in the speech bubble ·
     the coach's talking animation runs only while audio is actually playing ·
     previous audio always stops first · stops on every screen change ·
     nothing plays before the pupil's first interaction.
     ------------------------------------------------------------------ */
  var Voice = {
    el: null, mode: null, kind: null, paused: false, tok: 0, line: null, lastLine: null, instr: null, pending: null, ctl: null,
    init: function () {
      var self = this; self.el = new Audio(); self.el.preload = 'auto';
      // Speaking animation is driven by real playback events, so it is always in sync.
      self.el.addEventListener('playing', function () { if (self.mode === 'audio' && !self.paused) { Coach.speaking(true); self.statusUI(); } });
      self.el.addEventListener('waiting', function () { if (self.mode === 'audio') { Coach.speaking(false); Coach.status('⏳ Loading…'); } });
      self.el.addEventListener('pause', function () { Coach.speaking(false); });
    },
    /* opts: instruction (Replay target) · extra (HTML under subtitle) · mood · manual (pressed a Listen button) · ctl (.audio-ctl element) */
    say: function (key, opts) {
      var L = NARRATION[key]; if (!L) return;
      opts = opts || {};
      this.stop();
      this.pending = null; this.line = key; this.lastLine = key; this.ctl = opts.ctl || null; this.manual = !!opts.manual;
      if (opts.instruction) this.instr = key;
      Coach.show(opts.mood || L.mood, esc(L.text), opts.extra);
      if (!state.voice && !opts.manual) { Coach.status('🔇 Voice is OFF — read the speech bubble.'); Coach.hideLater(opts.hold || 7000); return; }
      if (!userActed) { this.pending = key; Coach.status('👆 Tap anywhere to hear the coach.'); return; }
      var src = A['au_' + key];
      if (status[src] === false) this.ai(key, this.tok); else this.playSrc(src, this.tok, 'local', key);
    },
    playSrc: function (src, tok, kind, key) {
      var self = this, a = self.el;
      a.onended = function () { if (tok === self.tok) self.done(); };
      a.onerror = function () {
        if (tok !== self.tok) return;
        // Only a file the server says does not exist (404) counts as "missing". Any other
        // error (no speaker/headset, device change, network blip) keeps the file usable,
        // so the next press of Play tries the real MP3 again.
        var soft = function () { self.failSoft('⚠️ The recording could not play on this device right now. Check the sound output, then press ▶ Play to try again.'); };
        if (kind !== 'local') { soft(); return; }
        if (status[src] === true) { soft(); return; }
        try {
          fetch(src, { method: 'HEAD', cache: 'no-store' }).then(function (r) {
            if (tok !== self.tok) return;
            if (r.status === 404) { status[src] = false; refreshTeacher(); self.ai(key, tok); } else soft();
          }, function () { if (tok !== self.tok) return; if (location.protocol === 'file:') { status[src] = false; refreshTeacher(); self.ai(key, tok); } else soft(); });
        } catch (e) { soft(); }
      };
      a.src = src; a.volume = state.voiceVol; a.muted = !!state.muted;
      self.mode = 'audio'; self.kind = kind; self.paused = false; setCtl(self.ctl, 'loading'); Coach.status('⏳ Loading…');
      var p = a.play();
      if (p && p.then) p.then(function () { if (kind === 'local') status[src] = true; if (tok === self.tok) setCtl(self.ctl, 'playing'); updateVoiceUI(); }).catch(function (e) {
        if (tok !== self.tok || !e) return;
        if (e.name === 'NotAllowedError') { self.mode = null; Coach.speaking(false); setCtl(self.ctl, 'idle'); Coach.status('Press ▶ Play to hear the coach.'); updateVoiceUI(); }
        else if (e.name === 'NotSupportedError') a.onerror();
      });
    },
    ai: function (key, tok) {
      var self = this;
      if (!AIVoice.enabled || (AIVoice.info && !AIVoice.info.configured)) {
        if (!self.manual) { self.quiet(); return; }   // automatic line: calm subtitle-only note
        self.fail('AUDIO NOT YET AVAILABLE — ' + NARRATION[key].file); return;
      }
      self.mode = 'gen'; self.paused = false; setCtl(self.ctl, 'loading');
      $('#coach-dock').classList.add('preparing'); Coach.status('✨ The coach is getting ready to speak…'); updateVoiceUI();
      AIVoice.get(key).then(function (u) {
        if (tok !== self.tok) return;
        $('#coach-dock').classList.remove('preparing'); self.playSrc(u, tok, 'ai', key);
      }, function (e) {
        if (tok !== self.tok) return;
        $('#coach-dock').classList.remove('preparing'); self.fail('⚠️ ' + e.message + ' The words are shown above.');
      });
    },
    /* Automatic coach line with no recording yet: the words stay on screen, nothing red or alarming. */
    quiet: function () { var q = this.queued; this.mode = null; this.paused = false; Coach.speaking(false); setCtl(this.ctl, 'idle'); Coach.status('💬 Read the words — recording not added yet.'); Coach.hideLater(7000); updateVoiceUI(); if (q) { this.queued = null; this.say(q[0], q[1]); } },
    failSoft: function (msg) { var q = this.queued; this.queued = null; this.mode = null; this.paused = false; Coach.speaking(false); setCtl(this.ctl, 'idle'); Coach.status(msg, true); Coach.hideLater(8000); updateVoiceUI(); if (q) this.say(q[0], q[1]); },
    fail: function (msg) { var q = this.queued; this.queued = null; this.mode = null; Coach.speaking(false); setCtl(this.ctl, 'missing'); Coach.status(msg, true); Coach.hideLater(8000); updateVoiceUI(); if (q) this.say(q[0], q[1]); },
    statusUI: function () {
      Coach.status(state.muted ? '🔇 Muted — subtitles on' : this.kind === 'ai' ? '🎙️ Coach voice (ElevenLabs)' : '🎙️ Playing recording');
    },
    done: function () { this.mode = null; this.paused = false; Coach.speaking(false); Coach.status(''); setCtl(this.ctl, 'idle'); Coach.hideLater(4500); updateVoiceUI(); this.flush(); },
    /* Say a line once the current one has finished (so narration never overlaps or cuts off). */
    sayAfter: function (key, opts) { if (!this.mode || this.paused) { this.say(key, opts); return; } this.queued = [key, opts]; },
    flush: function () { var q = this.queued; this.queued = null; if (q) this.say(q[0], q[1]); },
    stop: function () {
      this.tok++; this.queued = null;
      if (this.el) { try { this.el.pause(); } catch (e) {} }
      if (this.ctl && !this.ctl.classList.contains('missing')) setCtl(this.ctl, 'idle');
      this.mode = null; this.paused = false; this.pending = null;
      var d = $('#coach-dock'); if (d) { d.classList.remove('preparing'); Coach.speaking(false); }
    },
    toggle: function () {
      var self = this;
      if (self.mode === 'gen') { self.stop(); Coach.status('⏹ Stopped'); updateVoiceUI(); return; }
      if (self.mode && !self.paused) { self.paused = true; self.el.pause(); Coach.speaking(false); Coach.status('⏸ Paused'); setCtl(self.ctl, 'paused'); updateVoiceUI(); return; }
      if (self.mode && self.paused) { self.paused = false; setCtl(self.ctl, 'playing'); self.el.play().catch(function () {}); updateVoiceUI(); return; }
      self.say(self.lastLine || self.instr || 'welcome', { manual: true, ctl: self.ctl && self.ctl.isConnected ? self.ctl : null });
    },
    /* Listen buttons ([data-audio]) */
    button: function (key, ctl) {
      if (this.line === key && this.ctl === ctl && this.mode) { this.toggle(); return; }
      this.say(key, { manual: true, ctl: ctl });
    },
    replay: function () {
      var k = this.instr || this.lastLine || 'welcome';
      if (this.mode === 'audio' && this.line === k) { this.el.currentTime = 0; if (this.paused) this.toggle(); return; }
      this.say(k, { manual: true });
    },
    setOn: function (on) {
      state.voice = on; save();
      if (!on) { this.stop(); Coach.show('idle', 'Voice is OFF. I will still show my words here.'); Coach.hideLater(3500); }
      else { Coach.show('wave', 'Voice is ON!'); this.replay(); }
      updateVoiceUI();
    },
    setMuted: function (m) {
      state.muted = m; save();
      if (this.el) this.el.muted = m;
      if (this.mode === 'audio' && !this.paused) this.statusUI();
      updateVoiceUI();
    }
  };
  function updateVoiceUI() {
    var vb = $('#cd-voice'), pb = $('#cd-play'), mb = $('#cd-mute'); if (!vb) return;
    $('.ico', vb).textContent = state.voice ? '🗣️' : '🤐';
    $('.lbl', vb).textContent = state.voice ? 'Voice ON' : 'Voice OFF';
    vb.classList.toggle('off', !state.voice); vb.setAttribute('aria-pressed', state.voice ? 'true' : 'false');
    $('.ico', mb).textContent = state.muted ? '🔇' : '🔊';
    $('.lbl', mb).textContent = state.muted ? 'Unmute' : 'Mute';
    mb.classList.toggle('off', !!state.muted); mb.setAttribute('aria-pressed', state.muted ? 'true' : 'false');
    var playing = !!Voice.mode && !Voice.paused;
    $('.ico', pb).textContent = playing ? '⏸' : '▶';
    $('.lbl', pb).textContent = playing ? 'Pause' : (Voice.paused ? 'Resume' : 'Play');
    $('#coach-dock').classList.toggle('voice-off', !state.voice);
  }
  // Tiny silent WAV, generated in the browser, used once to unlock audio on iPad/iPhone.
  function silentWav() {
    var n = 160, b = new Uint8Array(44 + n), v = new DataView(b.buffer), w = function (o, s) { for (var i = 0; i < s.length; i++) b[o + i] = s.charCodeAt(i); };
    w(0, 'RIFF'); v.setUint32(4, 36 + n, true); w(8, 'WAVEfmt '); v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
    v.setUint32(24, 8000, true); v.setUint32(28, 8000, true); v.setUint16(32, 1, true); v.setUint16(34, 8, true); w(36, 'data'); v.setUint32(40, n, true);
    for (var i = 0; i < n; i++) b[44 + i] = 128;
    return URL.createObjectURL(new Blob([b], { type: 'audio/wav' }));
  }
  function firstInteraction() {
    if (userActed) return;
    userActed = true;
    if (!Voice.mode && Voice.el) { try { Voice.el.src = silentWav(); Voice.el.volume = 0; var p = Voice.el.play(); if (p && p.catch) p.catch(function () {}); } catch (e) {} }
  }

  /* If the board or an equipment photo was uploaded as .jpg/.jpeg/.webp instead of .png,
     use it. Only real files that load are used; nothing is invented. */
  function probeAltImages() {
    var keys = ['board', 'eq_badminton', 'eq_football', 'eq_swimming', 'eq_cycling', 'eq_basketball', 'eq_icehockey'];
    keys.forEach(function (k) {
      var base = A[k].replace(/\.png$/i, ''), exts = ['.png', '.jpg', '.jpeg', '.webp'], i = 0;
      (function next() {
        if (i >= exts.length) return;
        var path = base + exts[i++], im = new Image();
        im.onload = function () { A[k] = path; status[path] = true; };
        im.onerror = next;
        im.src = path;
      })();
    });
  }

  /* Asset check — honest report shown in the Teacher panel. */
  function checkAssets() {
    ASSET_LIST.forEach(function (r) {
      var src = A[r[1]];
      if (status[src] !== undefined) return;
      var done = function (ok) { if (status[src] === undefined) status[src] = ok; refreshTeacher(); };
      if (r[0] === 'captions') {
        // file:// pages cannot fetch; leave "not confirmed" there and let CP4's <track> report it.
        try { fetch(src, { method: 'GET', cache: 'no-store' }).then(function (res) { done(res.ok); }).catch(function () {}); } catch (e) {}
      } else if (r[0] === 'image') {
        var im = new Image(); im.onload = function () { done(true); }; im.onerror = function () { done(false); }; im.src = src;
      } else {
        var m = document.createElement(r[0] === 'video' ? 'video' : 'audio');
        m.preload = 'metadata'; m.muted = true;
        m.addEventListener('loadedmetadata', function () { done(true); });
        m.addEventListener('error', function () { done(false); });
        m.src = src;
      }
    });
  }

  /* ------------------------------------------------------------------
     6. FEEDBACK + ANIMATION
     ------------------------------------------------------------------ */
  /* Text-only coach message (not one of the narrated lines): shown in the coach's speech bubble. */
  function coachSay(mood, text, ms) {
    Voice.stop();
    Coach.show(OLD_MOOD[mood] || mood, text);
    Coach.hideLater(ms || 4000);
  }
  function floatText(el, text) {
    if (!el) return;
    var r = el.getBoundingClientRect(), f = document.createElement('div');
    f.className = 'float-pts'; f.textContent = text;
    f.style.left = (r.left + r.width / 2) + 'px'; f.style.top = (r.top + r.height / 2) + 'px';
    document.body.appendChild(f); setTimeout(function () { f.remove(); }, 1300);
  }
  function starBurst(el) {
    if (!el || reduceMotion) return;
    var r = el.getBoundingClientRect();
    for (var i = 0; i < 8; i++) {
      var s = document.createElement('span'), ang = (i / 8) * Math.PI * 2;
      s.className = 'burst-star'; s.textContent = '★';
      s.style.left = (r.left + r.width / 2) + 'px'; s.style.top = (r.top + r.height / 2) + 'px';
      s.style.setProperty('--dx', Math.cos(ang) * 70 + 'px'); s.style.setProperty('--dy', Math.sin(ang) * 70 + 'px');
      document.body.appendChild(s);
      (function (n) { setTimeout(function () { n.remove(); }, 900); })(s);
    }
  }
  function restartAnim(el, cls) { if (!el) return; el.classList.remove(cls); void el.offsetWidth; el.classList.add(cls); }
  function good(res, el, extra) {
    SFX.correct();
    if (el) { restartAnim(el, 'pop'); floatText(el, res.pts ? '+' + res.pts : '✓'); starBurst(el); }
    var info = (res.pts ? '<b>+' + res.pts + ' points</b>' + (res.retry ? ' (second try)' : '') : '') + (extra ? ' ' + extra : '');
    Voice.say(pickLine(['correct1', 'correct2', 'correct3', 'correct4']), { extra: info });
  }
  /* quiet = a reminder (e.g. "type your answer first"), not a wrong answer: no voice line. */
  function bad(el, hint, quiet) {
    SFX.wrong();
    restartAnim(el, 'shake');
    if (quiet) { coachSay('encourage', hint || pick(ENCOURAGE)); return; }
    var scr = state.screen, lines = (scr === 'cp2' || scr === 'cp5') ? ['wrong1', 'wrong3'] : ['wrong1', 'wrong2', 'wrong3'];
    Voice.say(pickLine(lines), { extra: hint ? '💡 ' + hint : '' });
  }

  /* Confetti (canvas) */
  var conf = { parts: [], running: false };
  function confetti(n) {
    var cv = $('#confetti'), ctx = cv.getContext('2d');
    cv.width = window.innerWidth; cv.height = window.innerHeight;
    var cols = ['#ffc928', '#ff7a1a', '#2fbf4a', '#8a3ffc', '#1f6bff', '#ffffff', '#ff4d8d'];
    n = reduceMotion ? 30 : (n || 180);
    for (var i = 0; i < n; i++) conf.parts.push({ x: Math.random() * cv.width, y: -20 - Math.random() * cv.height * 0.6, vx: (Math.random() - 0.5) * 4, vy: 2 + Math.random() * 4, s: 6 + Math.random() * 8, r: Math.random() * 6, vr: (Math.random() - 0.5) * 0.3, c: pick(cols), circ: Math.random() < 0.35 });
    if (conf.running) return;
    conf.running = true;
    (function loop() {
      ctx.clearRect(0, 0, cv.width, cv.height);
      conf.parts.forEach(function (p) {
        p.x += p.vx; p.y += p.vy; p.vy += 0.04; p.r += p.vr;
        ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.r); ctx.fillStyle = p.c;
        if (p.circ) { ctx.beginPath(); ctx.arc(0, 0, p.s / 2, 0, 7); ctx.fill(); } else ctx.fillRect(-p.s / 2, -p.s / 4, p.s, p.s / 2);
        ctx.restore();
      });
      conf.parts = conf.parts.filter(function (p) { return p.y < cv.height + 30; });
      if (conf.parts.length) requestAnimationFrame(loop); else { conf.running = false; ctx.clearRect(0, 0, cv.width, cv.height); }
    })();
  }

  function spawnStars() {
    var box = $('#stars-float'), html = '';
    for (var i = 0; i < 22; i++) {
      html += '<span style="left:' + (Math.random() * 100).toFixed(1) + '%;top:' + (Math.random() * 60).toFixed(1) + '%;font-size:' + (10 + Math.random() * 22).toFixed(0) + 'px;animation-delay:-' + (Math.random() * 6).toFixed(1) + 's;animation-duration:' + (4 + Math.random() * 5).toFixed(1) + 's">★</span>';
    }
    box.innerHTML = html;
  }

  /* ------------------------------------------------------------------
     7. HUD + SCREENS
     ------------------------------------------------------------------ */
  function renderHUD() {
    $('#hud').innerHTML =
      '<div class="hud-team"><span class="hud-mascot" id="hud-mascot"></span><span class="hud-team-text"><small>TEAM</small><b id="hud-name"></b></span></div>' +
      '<div class="hud-stats">' +
        '<div class="stat" id="stat-points"><span class="stat-ico">🪙</span><b id="hud-points">0</b><small>points</small></div>' +
        '<div class="stat" id="stat-stars"><span class="stat-ico">⭐</span><b id="hud-stars">0</b><small>stars</small></div>' +
        '<div class="stat"><span class="stat-ico">🏁</span><b id="hud-cp">0/6</b><small>checkpoints</small></div>' +
      '</div>' +
      '<nav class="hud-btns">' +
        '<button class="hbtn" data-action="map" title="Stadium Map">🗺️<span>Map</span></button>' +
        '<button class="hbtn" data-action="learn" title="Learning path — the six lesson parts">📚<span>Learn</span></button>' +
        '<button class="hbtn" data-action="notes" title="Interactive notes">📒<span>Notes</span></button>' +
        '<button class="hbtn" data-action="music" title="Music on/off">🎵<span class="state">OFF</span></button>' +
        '<button class="hbtn" data-action="sound" title="Sound effects on/off">🔊<span class="state">ON</span></button>' +
        '<button class="hbtn" data-action="teacher" title="Teacher panel">👩‍🏫<span>Teacher</span></button>' +
        '<button class="hbtn hbtn-reset" data-action="reset" title="Reset game">↺<span>Reset</span></button>' +
      '</nav>';
  }
  function updateHUD(bump) {
    var t = teamObj();
    if (t) {
      document.documentElement.style.setProperty('--team', t.color);
      document.documentElement.style.setProperty('--team-d', t.dark);
      $('#hud-mascot').textContent = t.mascot; $('#hud-name').textContent = t.name;
    }
    var p = $('#hud-points'); if (!p) return;
    p.textContent = state.points; $('#hud-stars').textContent = state.stars; $('#hud-cp').textContent = state.completed.length + '/6';
    if (bump) restartAnim($('#stat-points'), 'bump');
  }
  function updateToggles() {
    $$('[data-action="music"] .state').forEach(function (e) { e.textContent = music ? 'ON' : 'OFF'; });
    $$('[data-action="sound"] .state').forEach(function (e) { e.textContent = state.sound ? 'ON' : 'OFF'; });
    $$('[data-action="music"]').forEach(function (e) { e.classList.toggle('on', music); });
    $$('[data-action="sound"]').forEach(function (e) { e.classList.toggle('on', state.sound); });
  }

  var cleanupFns = [];
  function cleanup() { cleanupFns.forEach(function (f) { try { f(); } catch (e) {} }); cleanupFns = []; }

  function show(id) {
    playToken++;
    cleanup(); Voice.stop();
    $$('.screen').forEach(function (s) { s.classList.toggle('active', s.id === 'screen-' + id); });
    document.body.dataset.screen = id;
    var hud = !!state.team && id !== 'welcome' && id !== 'team';
    $('#hud').classList.toggle('hidden', !hud);
    document.body.classList.toggle('has-hud', hud);
    if (id === 'objectives' || id === 'map') { state.screen = id; save(); }
    updateHUD(); updateToggles();
    var s = $('#screen-' + id); if (s) s.scrollTop = 0;
    if (id === 'welcome' || id === 'team') Voice.say(id, { instruction: true });
    else { Voice.instr = null; Coach.hide(); Coach.setMood('idle'); }
  }

  function letters(str, cls) {
    // Letters are grouped into words so a long title can only wrap BETWEEN words, never inside one.
    var i = 0;
    return str.split(' ').map(function (w) {
      var h = w.split('').map(function (ch) { return '<span class="ltr ' + (cls || '') + '" style="--i:' + (i++) + '">' + esc(ch) + '</span>'; }).join('');
      i++;
      return '<span class="tword">' + h + '</span>';
    }).join('<span class="sp"> </span>');
  }

  /* ---------- WELCOME ---------- */
  function renderWelcome() {
    var t = teamObj();
    $('#screen-welcome').innerHTML =
      '<div class="welcome">' +
        '<div class="welcome-left">' +
          '<div class="pill-badge">Get Smart Plus 4 · Unit 9 · Get Active!</div>' +
          '<h1 class="game-title"><span class="t1">' + letters('THE ULTIMATE') + '</span><span class="t2">' + letters('SPORTS QUEST') + '</span><span class="t3">★ STADIUM ADVENTURE ★</span></h1>' +
          '<p class="tagline">Explore. Learn. Play. Become a Champion!</p>' +
          '<div class="welcome-btns">' +
            '<button class="btn btn-gold btn-xl glow" data-action="start">▶ Start Adventure</button>' +
            (t ? '<button class="btn btn-green btn-lg" data-action="continue">⏩ Continue: ' + t.mascot + ' ' + esc(t.name) + '</button>' : '') +
            '<button class="btn btn-purple btn-lg" data-action="howto">❓ How to Play</button>' +
          '</div>' +
          '<div class="welcome-toggles">' +
            '<button class="toggle" data-action="music">🎵 Music: <span class="state">OFF</span></button>' +
            '<button class="toggle" data-action="sound">🔊 Sound: <span class="state">ON</span></button>' +
            audioCtl('welcome', 'Play Coach Voice') + '<button class="toggle" data-action="replay-welcome">↺ Replay</button>' +
            '<button class="toggle" data-action="teacher">👩‍🏫 Teacher</button>' +
          '</div>' +
        '</div>' +
        '<div class="welcome-right">' +
          '<div class="trophy-wrap">' + TROPHY + '<div class="trophy-glow"></div></div>' +
          '<div class="coach-stand">' + coachImg('welcome', 'coach-big') +
            '<div class="bubble bubble-big">WELCOME TO THE ULTIMATE SPORTS QUEST!</div>' +
          '</div>' +
          '<div class="ball-row" aria-hidden="true"><span>⚽</span><span>🏀</span><span>🏸</span><span>🏒</span><span>🚴</span><span>🏊</span></div>' +
        '</div>' +
      '</div>';
    updateToggles();
  }

  /* ---------- TEAM ---------- */
  function renderTeam() {
    $('#screen-team').innerHTML =
      '<div class="team-screen">' +
        '<div class="screen-head"><button class="btn btn-small btn-navy" data-action="home">⬅ Back</button><h2 class="screen-title">Choose Your Team!</h2><span></span></div>' +
        '<div class="team-grid">' + TEAMS.map(function (t) {
          return '<button class="team-card' + (state.team === t.id ? ' selected' : '') + '" data-team="' + t.id + '" style="--c:' + t.color + ';--d:' + t.dark + '">' +
            '<span class="team-mascot">' + t.mascot + '</span><span class="team-name">' + t.name + '</span><span class="team-cheer">' + t.cheer + '</span><span class="team-tick">✔ Selected</span></button>';
        }).join('') + '</div>' +
        '<div class="team-foot">' + coachImg('instruct', 'coach-small') + '<div class="bubble">Pick a team, then press <b>Let\'s Go!</b></div>' +
          '<span class="team-voice">' + audioCtl('team', 'Play Coach Voice') + '<button class="toggle" data-action="replay-team">↺ Replay</button></span>' +
        '<button class="btn btn-gold btn-xl" data-action="team-go" ' + (state.team ? '' : 'disabled') + '>Let\'s Go! ➜</button></div>' +
      '</div>';
  }

  /* ---------- OBJECTIVES ---------- */
  function renderObjectives() {
    var t = teamObj();
    var objs = [
      ['🏸', 'Identify different sports and their equipment.'],
      ['🔤', 'Use superlative adjectives correctly.'],
      ['💬', 'Create simple sentences to talk about sports.']
    ];
    $('#screen-objectives').innerHTML =
      '<div class="objectives panel">' +
        '<div class="obj-coach">' + coachImg('instruct', 'coach-mid') + '<div class="bubble">Here is your mission, <b>' + esc(t ? t.name : 'champion') + '</b>! Tap each goal when you are ready.</div></div>' +
        '<div class="obj-main">' +
          '<h2 class="obj-title">By the end of this adventure, you can:</h2>' +
          '<div class="obj-list">' + objs.map(function (o, i) {
            return '<button class="obj-card" style="--i:' + i + '"><span class="obj-num">' + (i + 1) + '</span><span class="obj-ico">' + o[0] + '</span><span class="obj-text">' + o[1] + '</span><span class="obj-tick">✅ I\'m ready!</span></button>';
          }).join('') + '</div>' +
          '<div class="obj-actions">' + audioCtl('objectives', 'Listen') + '<button class="btn btn-purple" data-action="learn">📚 Learning Path</button>' +
            '<button class="btn btn-gold btn-lg glow" data-action="map">🗺️ Go to the Stadium Map</button></div>' +
        '</div>' +
      '</div>';
    $$('.obj-card').forEach(function (b) { b.addEventListener('click', function () { b.classList.toggle('ticked'); if (b.classList.contains('ticked')) { SFX.star(); starBurst(b); } }); });
  }

  /* ---------- MAP ---------- */
  var lastTokenCP = null, mapSel = null;
  function goMap() { renderMap(); show('map'); }
  function renderMap() {
    var cur = currentCP(), done = state.completed.length, t = teamObj() || TEAMS[0];
    if (mapSel === null || !isUnlocked(mapSel)) mapSel = cur;
    var from = lastTokenCP || cur;
    var pts = CHECKPOINTS.map(function (c) { return c.pos.join(','); }).join(' ');
    var markers = CHECKPOINTS.map(function (c) {
      var st = isDone(c.n) ? 'done' : isUnlocked(c.n) ? 'open' : 'locked';
      return '<button class="marker ' + st + (mapSel === c.n ? ' sel' : '') + '" data-marker="' + c.n + '" style="left:' + c.pos[0] + '%;top:' + c.pos[1] + '%" aria-label="Checkpoint ' + c.n + ': ' + c.name + ' (' + st + ')">' +
        '<span class="m-ring"></span><span class="m-core"><span class="m-num">' + c.n + '</span><span class="m-ico">' + (st === 'locked' ? '🔒' : c.icon) + '</span></span>' +
        (st === 'done' ? '<span class="m-badge">✔</span>' : '') +
        '<span class="m-label">' + c.name + '</span></button>';
    }).join('');
    var fp = CHECKPOINTS[from - 1].pos;
    $('#screen-map').innerHTML =
      '<div class="map-wrap">' +
        '<div class="map-main">' +
          '<div class="map-top"><h2>🏟️ Stadium Map</h2><div class="progress"><div class="progress-fill" style="width:' + (done / 6 * 100) + '%"></div><span>' + done + ' / 6 checkpoints</span></div></div>' +
          '<div class="board" id="board">' +
            '<div class="board-art"><div class="ba-track"></div><div class="ba-centre"></div><div class="ba-goal ba-goal-l"></div><div class="ba-goal ba-goal-r"></div>' +
              '<svg class="ba-path" viewBox="0 0 100 100" preserveAspectRatio="none"><polyline points="' + pts + '" /></svg>' +
              '<span class="ba-deco d1">🏸</span><span class="ba-deco d2">⚽</span><span class="ba-deco d3">🏀</span><span class="ba-deco d4">🏒</span><span class="ba-deco d5">🚴</span><span class="ba-deco d6">🏊</span>' +
              '<div class="ba-plaque">SPORTS QUEST BOARD</div></div>' +
            (status[A.board] === false ? '' : '<img class="board-img" src="' + A.board + '" alt="Sports Quest Board" onload="SQ.boardOk(this)" onerror="SQ.boardFail(this)" draggable="false">') +
            '<div class="board-missing">Placeholder board — add <code>' + fileOf(A.board) + '</code></div>' +
            markers +
            '<div class="token" id="token" style="left:' + fp[0] + '%;top:' + fp[1] + '%;--tc:' + t.color + '"><span>' + t.mascot + '</span></div>' +
          '</div>' +
        '</div>' +
        '<aside class="map-side panel" id="map-side"></aside>' +
      '</div>';
    if (status[A.board] === false) $('#board').classList.add('no-board');
    renderMapSide();
    $('#board').addEventListener('click', function (e) {
      var m = e.target.closest('.marker'); if (!m) return;
      var n = +m.dataset.marker;
      if (!isUnlocked(n)) { bad(m, 'Complete Checkpoint ' + (n - 1) + ' first to unlock ' + CHECKPOINTS[n - 1].name + '.', true); return; }
      SFX.click(); mapSel = n;
      $$('.marker').forEach(function (x) { x.classList.toggle('sel', +x.dataset.marker === n); });
      renderMapSide();
    });
    // move the team token
    var to = CHECKPOINTS[cur - 1].pos;
    requestAnimationFrame(function () { requestAnimationFrame(function () {
      var tk = $('#token'); if (!tk) return;
      tk.style.left = to[0] + '%'; tk.style.top = to[1] + '%';
      if (from !== cur) { tk.classList.add('moving'); setTimeout(function () { tk.classList.remove('moving'); SFX.star(); }, 1300); }
    }); });
    lastTokenCP = cur;
  }
  function renderMapSide() {
    var c = CHECKPOINTS[mapSel - 1], st = isDone(c.n) ? 'done' : isUnlocked(c.n) ? 'open' : 'locked';
    var all = state.completed.length === 6;
    var msg = all ? 'You completed every checkpoint! Visit the Champion Hall.' : st === 'done' ? 'Great job on this one! You can review it any time.' : 'Tap a glowing marker, then press <b>Enter</b>.';
    $('#map-side').innerHTML =
      '<div class="side-coach">' + coachImg(all ? 'achieve' : 'instruct', 'coach-small') + '<div class="bubble">' + msg + '</div></div>' +
      '<div class="cp-card ' + st + '">' +
        '<small>CHECKPOINT ' + c.n + '</small><h3>' + c.icon + ' ' + c.name + '</h3><p>' + c.focus + '</p>' +
        '<div class="cp-status">' + (st === 'done' ? '✅ Completed · ⭐ earned' : st === 'open' ? '▶ Ready to play' : '🔒 Locked') + '</div>' +
        '<button class="btn btn-gold btn-lg glow" data-action="enter" data-n="' + c.n + '">' + (st === 'done' ? '🔁 Review' : '▶ Enter Checkpoint') + '</button>' +
      '</div>' +
      (all ? '<button class="btn btn-purple" data-action="enter" data-n="6">🏆 Champion Hall</button>' : '');
  }

  function openCheckpoint(n) {
    if (!isUnlocked(n)) { coachSay('encourage', 'Complete Checkpoint ' + (n - 1) + ' first!'); return; }
    show('play');
    state.screen = 'cp' + n; save();
    var root = $('#screen-play');
    root.innerHTML = '';
    Voice.say('cp' + n, { instruction: true });
    [null, renderCP1, renderCP2, renderCP3, renderCP4, renderCP5, renderCP6][n](root);
    SFX.unlock();
  }

  function cpHeader(n, trackerHTML) {
    var c = CHECKPOINTS[n - 1];
    return '<div class="cp-head"><button class="btn btn-small btn-navy" data-action="map">⬅ Map</button>' +
      '<div class="cp-title"><span class="cp-ico">' + c.icon + '</span><div><small>CHECKPOINT ' + n + ' OF 6</small><h2>' + c.name + '</h2></div></div>' +
      '<div class="cp-tracker" id="cp-tracker">' + trackerHTML + '</div></div>';
  }
  function tracker(done, total, label) {
    var dots = ''; for (var i = 0; i < total; i++) dots += '<span class="' + (i < done ? 'on' : '') + '"></span>';
    return '<div class="tracker"><div class="tracker-dots">' + dots + '</div><b>' + done + ' / ' + total + '</b><small>' + label + '</small></div>';
  }
  function setTracker(done, total, label) { var t = $('#cp-tracker'); if (t) t.innerHTML = tracker(done, total, label); }
  function doneBanner(n) {
    return '<div class="done-banner">✅ Checkpoint complete! You earned the <b>' + CHECKPOINTS[n - 1].name + '</b> badge. <button class="btn btn-small btn-gold" data-action="map">🗺️ Back to Map</button></div>';
  }

  function complete(n) {
    var first = !isDone(n);
    if (first) { state.completed.push(n); state.stars++; save(); updateHUD(); restartAnim($('#stat-stars'), 'bump'); }
    if (n === 6) return;
    var c = CHECKPOINTS[n - 1], next = CHECKPOINTS[n];
    SFX.unlock(); setTimeout(SFX.star, 400); confetti(120);
    Voice.sayAfter('complete');
    openModal(
      '<div class="unlock-modal">' + coachImg('unlock', 'coach-mid') +
        '<div class="um-body"><div class="big-star">⭐</div><h2>Checkpoint ' + n + ' complete!</h2>' +
        '<p>You earned the <b>' + c.icon + ' ' + c.name + '</b> badge' + (first ? ' and <b>+1 star</b>!' : '!') + '</p>' +
        (next ? '<div class="unlocked-next"><span class="padlock small open">' + PADLOCK + '</span><span>Checkpoint ' + next.n + ': <b>' + next.name + '</b> is now unlocked!</span></div>' : '') +
        '<button class="btn btn-gold btn-lg glow" data-action="map">🗺️ Back to the Stadium Map</button></div></div>', 'modal-unlock');
  }

  /* ------------------------------------------------------------------
     CHECKPOINT 1 — SPORTS DETECTIVE
     ------------------------------------------------------------------ */
  function choicesFor(id) {
    var others = SPORT_IDS.filter(function (x) { return x !== id; });
    var i = SPORT_IDS.indexOf(id);
    var arr = [others[i % 5], others[(i + 2) % 5], others[(i + 4) % 5]];
    arr.splice(i % 4, 0, id);
    return arr;
  }
  function solvedFace(s) { return '<span class="mc-icon">' + s.icon + '</span><span class="mc-name">' + s.name + '</span><span class="mc-check">✔ Solved</span>'; }
  function cp1Count() { return SPORT_IDS.filter(function (id) { return answered('cp1-' + id); }).length + SPORT_IDS.filter(function (id) { return answered('cp1f-' + id); }).length; }
  function cp1Check() {
    var n = cp1Count(); setTracker(n, 12, 'tasks');
    var sh = $('#ff-tabs'); if (sh) sh.innerHTML = factShelf();
    if (n === 12 && !isDone(1)) later(function () { complete(1); }, 1300);
  }
  function factShelf() {
    return SPORT_IDS.map(function (id) {
      var d = answered('cp1f-' + id);
      return '<button class="ff-tab' + (d ? ' done' : '') + '" data-ff="' + id + '"><span class="ff-tab-art court-' + id + '">' + eqArt(id, 'ff-mini') + '</span><b>' + SPORTS[id].name + '</b><small>' + (d ? '✔ Checked' : '📂 Open file') + '</small></button>';
    }).join('');
  }
  function renderCP1(root) {
    var solved = SPORT_IDS.filter(function (id) { return answered('cp1-' + id); }).length;
    root.innerHTML = cpHeader(1, tracker(cp1Count(), 12, 'tasks')) +
      '<div class="kit-banner"><span class="kb-ico">📁</span><span><b>Step 1:</b> open each digital <b>Sports Fact File</b>, read it, and answer its quick check. <b>Step 2:</b> solve the <b>Mystery Cards</b>. You can reopen the Fact Files at any time.</span></div>' +
      (cp1Count() === 12 ? doneBanner(1) : '') +
      '<div class="panel ff-shelf"><div class="ff-shelf-head"><h3>📁 Sports Fact Files</h3><small>' + SPORT_IDS.filter(function (id) { return answered('cp1f-' + id); }).length + ' / 6 checked</small></div><div class="ff-tabs" id="ff-tabs">' + factShelf() + '</div></div>' +
      '<div class="cp1-layout">' +
        '<div class="mystery-grid">' + SPORT_IDS.map(function (id, i) {
          var s = SPORTS[id], d = answered('cp1-' + id);
          return '<button class="mystery-card' + (d ? ' flipped solved' : '') + '" data-card="' + id + '" aria-label="Mystery card ' + (i + 1) + '">' +
            '<span class="mc-inner"><span class="mc-front"><span class="mc-q">?</span><span class="mc-label">Mystery Card ' + (i + 1) + '</span><span class="mc-tap">Tap to flip</span></span>' +
            '<span class="mc-back">' + (d ? solvedFace(s) : '<span class="mc-clue-ico">🔍</span><span class="mc-clue">“' + s.clue + '”</span>') + '</span></span></button>';
        }).join('') + '</div>' +
        '<div class="panel investigate" id="cp1-panel">' +
          '<div class="inv-intro">' + coachImg('instruct', 'coach-mid') + '<h3>Detective Mission</h3><p>Flip a <b>Mystery Card</b>, read the clue and find the correct sport.</p><p class="small">Correct first time = <b>10 points</b>. After a retry = <b>5 points</b>.</p>' +
          '<button class="btn btn-small btn-purple" data-action="fact-files">📁 Open the Sports Fact Files</button></div>' +
        '</div>' +
      '</div>';
    $('.mystery-grid', root).addEventListener('click', function (e) {
      var card = e.target.closest('.mystery-card'); if (card) openMystery(card.dataset.card);
    });
    $('#ff-tabs', root).addEventListener('click', function (e) {
      var t = e.target.closest('.ff-tab'); if (t) { SFX.flip(); openFactFile(t.dataset.ff); }
    });
  }
  /* A Sports Fact File (modal, flip-open animation). Works from CP1 and from the Notes. */
  function openFactFile(id) {
    var s = SPORTS[id], f = FACTS[id], qid = 'cp1f-' + id, d = answered(qid), inCP1 = state.screen === 'cp1' && document.body.dataset.screen === 'play';
    var i = SPORT_IDS.indexOf(id);
    openModal(
      '<div class="fact-file">' +
        '<div class="ff-label">SPORTS FACT FILE ' + (i + 1) + ' OF 6</div>' +
        '<div class="ff-grid">' +
          '<div class="ff-art court-' + id + '">' + eqArt(id, 'ff-big') + '<span class="ff-ico">' + s.icon + '</span></div>' +
          '<div class="ff-body"><h2>' + s.icon + ' ' + s.name + '</h2><p class="ff-text">' + esc(f.text) + '</p>' +
            '<p class="ff-eq"><b>Equipment:</b> ' + EQUIP[id].label + '</p>' + '</div>' +
        '</div>' +
        '<div class="ff-check"><h4>✏️ Quick check' + (inCP1 ? '' : ' <small>(score it in Checkpoint 1)</small>') + '</h4><p class="ff-q">' + esc(f.q) + '</p>' +
          '<div class="choices" id="ff-choices">' + f.opts.map(function (o, j) {
            return '<button class="choice' + (d && j === f.a ? ' right' : '') + '" data-j="' + j + '"' + (d ? ' disabled' : '') + '><span class="ch-letter">' + 'ABC'[j] + '</span><span>' + esc(o) + '</span></button>';
          }).join('') + '</div><div class="gs-feedback" id="ff-fb">' + (d ? '✅ Checked!' : '') + '</div></div>' +
        '<div class="ff-nav">' + SPORT_IDS.map(function (x) { return '<button class="ff-dot' + (x === id ? ' on' : '') + (answered('cp1f-' + x) ? ' done' : '') + '" data-ffnav="' + x + '" title="' + SPORTS[x].name + '">' + SPORTS[x].icon + '</button>'; }).join('') + '</div>' +
      '</div>', 'modal-wide modal-fact');
    var box = $('.fact-file');
    $('.ff-nav', box).addEventListener('click', function (e) { var b = e.target.closest('[data-ffnav]'); if (b) { SFX.flip(); openFactFile(b.dataset.ffnav); } });
    $('#ff-choices', box).addEventListener('click', function (e) {
      var b = e.target.closest('.choice'); if (!b || b.disabled) return;
      var ok = +b.dataset.j === f.a;
      if (!inCP1) {
        b.classList.add(ok ? 'right' : 'wrong'); if (!ok) b.disabled = true;
        $('#ff-fb').textContent = ok ? '✅ Correct! (Practice — answer it in Checkpoint 1 to earn points.)' : '❌ Not quite. Read the Fact File again.';
        if (ok) SFX.correct(); else SFX.wrong();
        return;
      }
      if (ok) {
        var res = award(qid, true);
        b.classList.add('right'); $$('#ff-choices .choice').forEach(function (x) { x.disabled = true; });
        $('#ff-fb').innerHTML = '✅ Correct! ' + (res.pts ? '+' + res.pts + ' points' : '');
        good(res, b); cp1Check();
        var dot = $('.ff-dot.on'); if (dot) dot.classList.add('done');
      } else {
        award(qid, false); b.disabled = true; b.classList.add('wrong');
        $('#ff-fb').innerHTML = '❌ Not quite. Read the Fact File again carefully.';
        bad(b, 'The answer is in the Fact File text.');
      }
    });
  }
  function openFactPicker() {
    openModal('<h2 class="modal-title">📁 Sports Fact Files</h2><p class="small">Choose a file to open. You can come back to your Mystery Card at any time.</p><div class="ff-tabs picker">' + factShelf() + '</div>', 'modal-wide');
    $('.ff-tabs.picker').addEventListener('click', function (e) { var t = e.target.closest('.ff-tab'); if (t) { SFX.flip(); openFactFile(t.dataset.ff); } });
  }
  function openMystery(id) {
    var s = SPORTS[id], card = $('.mystery-card[data-card="' + id + '"]'), panel = $('#cp1-panel');
    $$('.mystery-card').forEach(function (c) { c.classList.toggle('active', c === card); });
    if (!card.classList.contains('flipped')) { card.classList.add('flipped'); SFX.flip(); }
    var num = SPORT_IDS.indexOf(id) + 1;
    if (answered('cp1-' + id)) {
      panel.innerHTML = '<div class="inv-solved"><span class="big-ico">' + s.icon + '</span><h3>Case closed: ' + s.name + '!</h3><p>“' + s.clue + '”</p>' + nextMysteryBtn() + '</div>';
      return;
    }
    panel.innerHTML =
      '<small class="inv-tag">MYSTERY CARD ' + num + '</small>' +
      '<div class="inv-clue">🔍 “' + s.clue + '”</div>' +
      '<button class="btn btn-small btn-purple" data-action="fact-files">📁 Check the Sports Fact Files</button>' +
      '<h4>Which sport is it?</h4>' +
      '<div class="choices">' + choicesFor(id).map(function (c) { return '<button class="choice" data-c="' + c + '"><span>' + SPORTS[c].name + '</span></button>'; }).join('') + '</div>';
    $('.choices', panel).addEventListener('click', function (e) {
      var b = e.target.closest('.choice'); if (!b || b.disabled) return;
      if (b.dataset.c === id) {
        var res = award('cp1-' + id, true);
        b.classList.add('right');
        $$('.choice', panel).forEach(function (x) { x.disabled = true; });
        $('.mc-back', card).innerHTML = solvedFace(s); card.classList.add('solved');
        good(res, card);
        cp1Check();
        later(function () {
          panel.innerHTML = '<div class="inv-solved"><span class="big-ico">' + s.icon + '</span><h3>Yes! It\'s ' + s.name + '!</h3><p>“' + s.clue + '”</p>' + nextMysteryBtn() + '</div>';
        }, 700);
      } else {
        award('cp1-' + id, false);
        b.disabled = true; b.classList.add('wrong');
        bad(b, 'Read the clue again and open the Sports Fact Files to check.');
      }
    });
  }
  function nextMysteryBtn() {
    var next = SPORT_IDS.filter(function (x) { return !answered('cp1-' + x); })[0];
    if (!next) return '<p class="all-done">🎉 All mysteries solved!' + (cp1Count() < 12 ? ' Now finish the quick checks in the <b>Sports Fact Files</b> above.' : '') + '</p>';
    setTimeout(function () { var b = $('#next-mystery'); if (b) b.onclick = function () { SFX.click(); openMystery(next); }; }, 0);
    return '<button class="btn btn-orange" id="next-mystery">Next mystery ➜</button>';
  }

  /* ------------------------------------------------------------------
     CHECKPOINT 2 — EQUIPMENT MATCH (pointer drag + click-to-match)
     ------------------------------------------------------------------ */
  function equipCard(id, matched) {
    var e = EQUIP[id];
    return '<button class="equip' + (matched ? ' matched' : '') + '" data-eq="' + id + '" aria-label="' + e.label + '">' +
      eqArt(id) + '<span class="equip-label">' + e.label + '</span></button>';
  }
  function cp2Count() { return SPORT_IDS.filter(function (id) { return answered('cp2-' + id); }).length; }
  function renderCP2(root) {
    var n = cp2Count();
    root.innerHTML = cpHeader(2, tracker(n, 6, 'matches')) +
      '<div class="kit-banner green"><span class="kb-ico">🧩</span><span><b>Drag</b> each piece of equipment to its sport — or <b>tap</b> the equipment, then <b>tap</b> the sport.</span></div>' +
      (n === 6 ? doneBanner(2) : '') +
      '<div class="cp2-layout">' +
        '<div class="zones">' + SPORT_IDS.map(function (id) {
          var m = answered('cp2-' + id);
          return '<div class="dropzone court-' + id + (m ? ' filled' : '') + '" data-sport="' + id + '" tabindex="0" role="button" aria-label="Drop zone: ' + SPORTS[id].name + '">' +
            '<div class="dz-name">' + SPORTS[id].name + '</div><div class="dz-slot">' + (m ? equipCard(id, true) : '<span class="dz-hint">Drop equipment here</span>') + '</div></div>';
        }).join('') + '</div>' +
        '<div class="tray panel"><h3>🎒 Equipment Bag</h3><div class="tray-items" id="tray">' +
          TRAY_ORDER.filter(function (id) { return !answered('cp2-' + id); }).map(function (id) { return equipCard(id, false); }).join('') +
          (n === 6 ? '<p class="all-done">🎉 Every item matched!</p>' : '') +
        '</div></div>' +
      '</div>';
    wireDrag($('.cp2-layout', root));
  }
  function wireDrag(root) {
    var drag = null, selected = null, suppress = false;
    function clearHi() { $$('.dropzone.hover', root).forEach(function (z) { z.classList.remove('hover'); }); }
    function zoneAt(x, y) { var el = document.elementFromPoint(x, y); return el && el.closest('.dropzone'); }
    function select(card) {
      if (selected) selected.classList.remove('selected');
      selected = (selected === card) ? null : card;
      if (selected) { selected.classList.add('selected'); SFX.click(); }
      root.classList.toggle('picking', !!selected);
    }
    root.addEventListener('pointerdown', function (e) {
      var card = e.target.closest('.equip'); if (!card || card.classList.contains('matched') || e.button > 0) return;
      drag = { card: card, x: e.clientX, y: e.clientY, ghost: null, id: e.pointerId };
      try { card.setPointerCapture(e.pointerId); } catch (err) {}
    });
    root.addEventListener('pointermove', function (e) {
      if (!drag || e.pointerId !== drag.id) return;
      if (!drag.ghost && Math.hypot(e.clientX - drag.x, e.clientY - drag.y) > 8) {
        var r = drag.card.getBoundingClientRect();
        drag.ghost = drag.card.cloneNode(true); drag.ghost.classList.add('ghost');
        drag.ghost.style.width = r.width + 'px'; drag.ghost.style.height = r.height + 'px';
        drag.offX = drag.x - r.left; drag.offY = drag.y - r.top;
        document.body.appendChild(drag.ghost); drag.card.classList.add('dragging'); document.body.classList.add('is-dragging');
        if (selected) select(selected);
      }
      if (drag.ghost) {
        e.preventDefault();
        drag.ghost.style.left = (e.clientX - drag.offX) + 'px'; drag.ghost.style.top = (e.clientY - drag.offY) + 'px';
        clearHi(); var z = zoneAt(e.clientX, e.clientY); if (z && !z.classList.contains('filled')) z.classList.add('hover');
      }
    });
    function end(e, cancel) {
      if (!drag || e.pointerId !== drag.id) return;
      var d = drag; drag = null;
      if (d.ghost) {
        suppress = true; setTimeout(function () { suppress = false; }, 50);
        var z = cancel ? null : zoneAt(e.clientX, e.clientY);
        d.ghost.remove(); d.card.classList.remove('dragging'); document.body.classList.remove('is-dragging'); clearHi();
        if (z) tryMatch(d.card, z);
      }
    }
    root.addEventListener('pointerup', function (e) { end(e, false); });
    root.addEventListener('pointercancel', function (e) { end(e, true); });
    root.addEventListener('click', function (e) {
      if (suppress) return;
      var card = e.target.closest('.equip');
      if (card && !card.classList.contains('matched')) { select(card); return; }
      var z = e.target.closest('.dropzone');
      if (z && selected) { var c = selected; select(c); tryMatch(c, z); }
      else if (z && !z.classList.contains('filled')) coachSay('instruct', 'First tap a piece of equipment from the bag, then tap its sport.');
    });
    root.addEventListener('keydown', function (e) {
      var z = e.target.closest('.dropzone');
      if (z && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); z.click(); }
    });
    cleanupFns.push(function () { $$('.equip.ghost').forEach(function (g) { g.remove(); }); document.body.classList.remove('is-dragging'); });
  }
  function tryMatch(card, zone) {
    if (card.classList.contains('matched') || zone.classList.contains('filled')) { if (zone.classList.contains('filled')) bad(zone, 'This sport already has its equipment.', true); return; }
    var eq = card.dataset.eq, sport = zone.dataset.sport;
    if (eq === sport) {
      var res = award('cp2-' + eq, true);
      var slot = $('.dz-slot', zone); slot.innerHTML = '';
      card.classList.remove('selected'); card.classList.add('matched'); slot.appendChild(card);
      zone.classList.add('filled'); SFX.drop(); good(res, zone, EQUIP[eq].label + ' → ' + SPORTS[sport].name + '!');
      var n = cp2Count(); setTracker(n, 6, 'matches');
      if (n === 6) {
        // validate every match before awarding completion
        var valid = $$('.dropzone').every(function (z) { var c = $('.equip', z); return c && c.dataset.eq === z.dataset.sport; });
        if (valid) {
          $('#tray').innerHTML = '<p class="all-done">🎉 Every item matched!</p>';
          $$('.dropzone').forEach(function (z, i) { setTimeout(function () { restartAnim(z, 'pop'); }, i * 120); });
          later(function () { complete(2); }, 1500);
        }
      }
    } else {
      award('cp2-' + eq, false);
      bad(zone, EQUIP[eq].label + ' is not used for ' + SPORTS[sport].name + '. Try again!'); restartAnim(card, 'shake');
    }
  }

  /* ------------------------------------------------------------------
     CHECKPOINT 3 — GRAMMAR DECODER
     ------------------------------------------------------------------ */
  function norm(s) { return String(s).toLowerCase().replace(/[.,!?"“”']/g, ' ').replace(/\s+/g, ' ').trim().replace(/^the /, ''); }
  function superlativeNotes() {
    return '<div class="note-cards">' +
      noteCard('📏', 'Short words', '<b>add -est</b><div class="bars"><span style="height:35%">tall</span><span style="height:60%">taller</span><span style="height:92%">tallest</span></div><p>tall → tallest · fast → fastest</p>') +
      noteCard('🔤', 'Words ending in -y', '<b>y → i + est</b><div class="morph">eas<s>y</s><em>i</em>est</div><p>easy → easiest</p>') +
      noteCard('📚', 'Long words', '<b>most + word</b><div class="morph"><em>most</em> difficult</div><p>difficult → most difficult<br>popular → most popular</p>') +
      noteCard('⭐', 'Special words', '<b>they change!</b><div class="morph">good → <em>best</em><br>bad → <em>worst</em></div>') +
      '</div><p class="note-tip">💡 Use <b>the</b> before a superlative: <i>the tallest</i>, <i>the best</i>, <i>the most popular</i>.</p>';
  }
  function noteCard(ico, title, back) {
    return '<div class="note-card" role="button" tabindex="0"><div class="nc-inner"><div class="nc-front"><span class="nc-ico">' + ico + '</span><b>' + title + '</b><small>Tap to learn</small></div><div class="nc-back">' + back + '</div></div></div>';
  }
  /* ---- Digital Decoder Wheel ---- */
  var WHEEL_COLS = ['#1f4fd8', '#ff7a1a', '#2fbf4a', '#7b3fe4', '#e0234e', '#ffc928', '#14a7b8'];
  var wheel = { rot: 0, sel: null, busy: false }, cp3Open = null;
  function wheelSVG() {
    var n = CP3.length, step = 360 / n, cx = 130, cy = 130, r = 122, out = '';
    var pt = function (deg, rad) { var t = deg * Math.PI / 180; return (cx + rad * Math.sin(t)).toFixed(2) + ' ' + (cy - rad * Math.cos(t)).toFixed(2); };
    CP3.forEach(function (c, i) {
      out += '<g class="wseg" data-seg="' + i + '" role="button" aria-label="' + c.adj + '"><path d="M' + cx + ' ' + cy + ' L' + pt((i - 0.5) * step, r) + ' A' + r + ' ' + r + ' 0 0 1 ' + pt((i + 0.5) * step, r) + ' Z" fill="' + WHEEL_COLS[i] + '" stroke="#fff" stroke-width="3"/>' +
        '<text x="' + cx + '" y="' + (cy - 82) + '" transform="rotate(' + (i * step).toFixed(3) + ' ' + cx + ' ' + cy + ')" text-anchor="middle" font-size="' + (c.adj.length > 7 ? 11.5 : 15) + '" font-weight="900" fill="' + (i === 5 ? '#1a1f4a' : '#fff') + '">' + c.adj + '</text></g>';
    });
    return '<svg class="wheel-svg" viewBox="0 0 260 260"><circle cx="130" cy="130" r="128" fill="#0b1650"/>' + out +
      '<circle cx="130" cy="130" r="28" fill="#fff" stroke="#0b1650" stroke-width="5"/><text x="130" y="136" text-anchor="middle" font-size="15" font-weight="900" fill="#0b1650">SPIN</text></svg>';
  }
  function wheelPanel() {
    return '<div class="panel wheel-panel"><h3>🎡 Digital Decoder Wheel</h3>' +
      '<p class="small">Tap an adjective, or press <b>Spin</b>. The wheel shows its superlative.</p>' +
      '<div class="wheel-wrap"><div class="wheel-pointer" aria-hidden="true">▼</div><div class="wheel-disc" id="wheel-disc">' + wheelSVG() + '</div></div>' +
      '<div class="wheel-result" id="wheel-result" aria-live="polite">Choose an adjective on the wheel.</div>' +
      '<div class="row center"><button class="btn btn-orange" id="wheel-spin">🎡 Spin the wheel</button><button class="btn btn-purple btn-small" data-action="grammar-note">📒 Grammar note</button></div></div>';
  }
  function spinTo(i, spins) {
    var disc = $('#wheel-disc'); if (!disc || wheel.busy) return;
    wheel.busy = true; wheel.sel = null;
    $$('.wseg').forEach(function (g) { g.classList.remove('on'); });
    var step = 360 / CP3.length, target = (360 - i * step) % 360, cur = ((wheel.rot % 360) + 360) % 360;
    wheel.rot += spins * 360 + ((target - cur + 360) % 360);
    disc.style.transform = 'rotate(' + wheel.rot + 'deg)';
    $('#wheel-result').innerHTML = '🎡 Spinning…'; SFX.flip();
    later(function () { wheel.busy = false; wheelLanded(i); }, reduceMotion ? 120 : 2700);
  }
  function wheelLanded(i) {
    var c = CP3[i], seg = $('.wseg[data-seg="' + i + '"]');
    wheel.sel = i; if (seg) seg.classList.add('on'); SFX.star();
    $('#wheel-result').innerHTML = '<span class="wr-adj">' + c.adj + '</span> → <span class="wr-sup">the ' + c.answer + '</span><small>' + RULE_HINT[c.rule] + '</small>';
    restartAnim($('#wheel-result'), 'pop');
    updateDecodeGate();
  }
  function updateDecodeGate() {
    var i = cp3Index(), inp = $('#decode-input'), msg = $('#gate-msg'); if (!inp || cp3Open !== i) return;
    var ok = wheel.sel === i;
    inp.disabled = !ok; $('#decode-go').disabled = !ok;
    var st = $('#step-wheel'); if (st) st.classList.toggle('done', ok);
    if (ok) { msg.innerHTML = '✅ The wheel matches your clue <b>' + CP3[i].adj + '</b>. Now type the superlative!'; inp.focus(); }
    else if (wheel.sel !== null) msg.innerHTML = 'The wheel shows <b>' + CP3[wheel.sel].adj + '</b>. Your clue is <b>' + CP3[i].adj + '</b> — tap <b>' + CP3[i].adj + '</b> on the wheel.';
    else msg.innerHTML = 'Find your clue <b>' + CP3[i].adj + '</b> on the Decoder Wheel.';
  }
  function renderCP3(root) {
    wheel = { rot: 0, sel: null, busy: false }; cp3Open = null;
    var done = CP3.filter(function (c, i) { return answered('cp3-' + i); }).length;
    root.innerHTML = cpHeader(3, tracker(done, 7, 'cards decoded')) +
      '<div class="kit-banner purple"><span class="kb-ico">🎡</span><span>Open a digital <b>Sentence Card</b>, read the adjective clue, find it on the <b>Decoder Wheel</b>, then type the superlative.</span></div>' +
      '<div class="cp3-layout">' + wheelPanel() +
        '<div class="panel mission" id="cp3-mission"></div>' +
        '<div class="panel notes-panel"><div class="np-head"><h3>📒 Grammar Note: superlatives</h3>' + audioCtl('grammar', 'Listen') + '</div>' + superlativeNotes() + '</div>' +
      '</div>';
    $('#wheel-disc', root).addEventListener('click', function (e) { var g = e.target.closest('.wseg'); if (g) spinTo(+g.dataset.seg, 1); });
    $('#wheel-spin', root).addEventListener('click', function () { spinTo(Math.floor(Math.random() * CP3.length), 3); });
    drawMission();
  }
  function cp3Index() { for (var i = 0; i < CP3.length; i++) if (!answered('cp3-' + i)) return i; return -1; }
  function cardDeck(cur) {
    return '<div class="s-deck" id="s-deck">' + CP3.map(function (c, j) {
      var o = answered('cp3-' + j);
      return '<button class="s-card' + (o ? ' done' : j === cur ? ' current' + (cp3Open === j ? ' opened' : '') : ' locked') + '" data-sc="' + j + '"' + (!o && j !== cur ? ' disabled' : '') + ' aria-label="Sentence card ' + (j + 1) + '">' +
        '<small>CARD ' + (j + 1) + '</small>' + (o ? '<b>🔓 ' + c.answer + '</b>' : j === cur ? '<b>' + (cp3Open === j ? '📖 Open' : '📇 Tap to open') + '</b>' : '<b>🔒</b>') + '</button>';
    }).join('') + '</div>';
  }
  function drawMission() {
    var m = $('#cp3-mission'); if (!m) return;
    var i = cp3Index();
    if (i === -1) {
      m.innerHTML = cardDeck(-1) + '<div class="mission-done"><div class="padlock big open">' + PADLOCK + '</div><h3>Secret mission complete!</h3><p>You decoded all 7 Sentence Cards.</p>' +
        '<ul class="decoded">' + CP3.map(function (c) { return '<li><b>' + c.adj + '</b> → ' + c.answer + '</li>'; }).join('') + '</ul>' +
        (isDone(3) ? '<button class="btn btn-gold" data-action="map">🗺️ Back to Map</button>' : '') + '</div>';
      wireDeck(m);
      if (!isDone(3)) later(function () { complete(3); }, 1400);
      return;
    }
    var c = CP3[i];
    if (cp3Open !== i) {
      m.innerHTML = cardDeck(i) + '<div class="card-prompt"><span class="cp-big">📇</span><h3>Sentence Card ' + (i + 1) + ' is waiting!</h3><p>Tap the glowing card to open it.</p></div>';
      wireDeck(m); return;
    }
    m.innerHTML = cardDeck(i) +
      '<div class="mission-body"><div class="padlock" id="padlock">' + PADLOCK + '</div>' +
        '<div class="secret-card flip-in"><small>SENTENCE CARD ' + (i + 1) + ' OF 7</small><div class="clue-chip">' + c.adj + '</div>' +
        '<p class="sentence">' + esc(c.sentence).replace('______', '<span class="blank" id="blank">______</span>') + '</p></div></div>' +
      '<ol class="steps"><li class="done">Open the card</li><li class="done">Read the clue: <b>' + c.adj + '</b></li><li id="step-wheel">Find <b>' + c.adj + '</b> on the wheel</li><li>Type the superlative</li></ol>' +
      '<p class="gate-msg" id="gate-msg"></p>' +
      '<form class="decode-form" id="decode-form" autocomplete="off"><input id="decode-input" type="text" spellcheck="false" autocapitalize="off" placeholder="Type the superlative…" disabled aria-label="Type the superlative"><button class="btn btn-green" id="decode-go" disabled>🔓 Unlock</button></form>' +
      '<div class="hint" id="cp3-hint"></div>';
    wireDeck(m); updateDecodeGate();
    $('#decode-form').addEventListener('submit', function (e) {
      e.preventDefault();
      var inp = $('#decode-input'), val = inp.value;
      if (!norm(val)) { bad(inp, 'Type your answer first.', true); return; }
      if (norm(val) === c.answer) {
        var res = award('cp3-' + i, true);
        inp.disabled = true; $('#decode-go').disabled = true;
        $('#blank').textContent = c.answer; $('#blank').classList.add('filled');
        $('#padlock').classList.add('open'); SFX.unlock();
        good(res, $('#padlock'));
        setTracker(CP3.filter(function (x, j) { return answered('cp3-' + j); }).length, 7, 'cards decoded');
        later(drawMission, 1700);
      } else {
        award('cp3-' + i, false);
        bad(inp, RULE_HINT[c.rule]);
        $('#cp3-hint').innerHTML = '💡 Hint: ' + RULE_HINT[c.rule];
        inp.select();
      }
    });
  }
  function wireDeck(m) {
    $('#s-deck', m).addEventListener('click', function (e) {
      var b = e.target.closest('.s-card'); if (!b || b.disabled) return;
      var j = +b.dataset.sc;
      if (answered('cp3-' + j)) { coachSay('instruct', 'Card ' + (j + 1) + ': ' + esc(CP3[j].sentence.replace('______', 'the ' + CP3[j].answer).replace('the the ', 'the ')), 5000); return; }
      if (cp3Open !== j) { cp3Open = j; SFX.flip(); drawMission(); }
    });
  }
  function openGrammarNote() {
    openModal('<div class="modal-coach-head">' + coachImg('instruct', 'coach-small') + '<h2 class="modal-title">📒 Grammar Note: Superlatives</h2></div><div class="np-head">' + audioCtl('grammar', 'Listen to the grammar note') + '</div>' + superlativeNotes() +
      '<table class="sup-table"><tr><th>Adjective</th><th>Superlative</th></tr>' + CP3.map(function (c) { return '<tr><td>' + c.adj.toLowerCase() + '</td><td>the ' + c.answer + '</td></tr>'; }).join('') + '</table>', 'modal-wide');
  }

  /* ------------------------------------------------------------------
     CHECKPOINT 4 — VIRTUAL REFEREE
     ------------------------------------------------------------------ */
  var cp4Timer = null;
  /* Checkpoint 4 lesson video: the teacher's YouTube video, embedded with a responsive
     iframe. Our buttons talk to YouTube's player through its standard postMessage
     embed API (enablejsapi=1); no extra scripts are loaded. If YouTube reports that
     embedding is blocked, or the device is offline, a clear "Watch on YouTube" link shows. */
  var YT_ID = '11e9IzV2cCQ', YT_EMBED = 'https://www.youtube.com/embed/' + YT_ID, YT_WATCH = 'https://youtu.be/' + YT_ID;
  var YT_TITLE = 'Sports I — Vocabulary for Kids (Smile and Learn – English)';
  var ytPlayer = null; // { frame, ready, dur, state, root }
  function videoPlayer() {
    var http = location.protocol === 'http:' || location.protocol === 'https:';
    var src = YT_EMBED + '?enablejsapi=1&rel=0&playsinline=1&modestbranding=1&cc_load_policy=1&cc_lang_pref=en&hl=en' + (http ? '&origin=' + encodeURIComponent(location.origin) : '');
    return '<div class="tv"><div class="tv-top"><span class="live">● LESSON</span><span>Sports Lesson Video</span></div>' +
      '<div class="tv-screen yt-screen"><iframe id="yt-frame" src="' + src + '" title="' + esc(YT_TITLE) + '" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>' +
        '<div class="video-missing hidden" id="video-missing"><span>🎬</span><b id="vm-title">VIDEO CANNOT PLAY HERE</b><small id="vm-msg"></small>' +
        '<a class="btn btn-small btn-gold" href="' + YT_WATCH + '" target="_blank" rel="noopener">▶ Watch it on YouTube</a></div></div>' +
      '<div class="vcontrols" id="vcontrols">' +
        '<button class="vbtn" data-v="play" aria-label="Play">▶ Play</button><button class="vbtn" data-v="pause" aria-label="Pause">⏸ Pause</button><button class="vbtn" data-v="replay" aria-label="Replay">↺ Replay</button>' +
        '<input class="vprogress" id="vprogress" type="range" min="0" max="1000" value="0" aria-label="Video progress">' +
        '<span class="vtime" id="vtime">0:00 / 0:00</span>' +
        '<label class="vvol">🔊<input id="vvol" type="range" min="0" max="100" step="5" value="80" aria-label="Volume"></label></div>' +
      '<div class="vcap-note" id="vcap-note">Captions: use the <b>CC</b> button inside the video. · Video not playing? <a href="' + YT_WATCH + '" target="_blank" rel="noopener">Watch it on YouTube ↗</a></div></div>';
  }
  function fmt(t) { t = isFinite(t) ? t : 0; var m = Math.floor(t / 60), s = Math.floor(t % 60); return m + ':' + (s < 10 ? '0' : '') + s; }
  function ytCmd(func, args) {
    if (!ytPlayer || !ytPlayer.frame.contentWindow) return;
    ytPlayer.frame.contentWindow.postMessage(JSON.stringify({ event: 'command', func: func, args: args || [] }), 'https://www.youtube.com');
  }
  function ytFallback(title, msg) {
    var m = $('#video-missing'); if (!m) return;
    $('#vm-title').textContent = title; $('#vm-msg').textContent = msg; m.classList.remove('hidden');
    var ctl = $('#vcontrols'); if (ctl) { ctl.classList.add('disabled'); $$('button,input', ctl).forEach(function (x) { x.disabled = true; }); }
  }
  window.addEventListener('message', function (e) {
    if (!ytPlayer || e.source !== ytPlayer.frame.contentWindow || !/youtube(-nocookie)?\.com$/.test(String(e.origin).replace(/^https?:\/\//, '').replace(/^www\./, ''))) return;
    var d; try { d = typeof e.data === 'string' ? JSON.parse(e.data) : e.data; } catch (err) { return; }
    if (!d || !d.event) return;
    if (d.event === 'onReady') { ytPlayer.ready = true; ytCmd('setVolume', [+($('#vvol') || { value: 80 }).value]); }
    if (d.event === 'onError') {
      var c = +d.info;
      ytFallback(c === 101 || c === 150 || c === 153 ? 'VIDEO CANNOT PLAY INSIDE THE GAME' : 'VIDEO NOT AVAILABLE',
        c === 101 || c === 150 || c === 153 ? 'The video owner does not allow it to play on other websites.' : 'YouTube could not play this video (error ' + c + ').');
    }
    var info = d.info || {};
    if (d.event === 'onStateChange') info = { playerState: d.info };
    if (info.playerState === 1) { ytPlayer.ready = true; Voice.stop(); } // playing: stop the coach so voices never overlap
    if (typeof info.duration === 'number' && info.duration > 0) ytPlayer.dur = info.duration;
    if (typeof info.currentTime === 'number') {
      var pr = $('#vprogress'), tm = $('#vtime');
      if (pr && ytPlayer.dur && !ytPlayer.seeking) pr.value = Math.round(info.currentTime / ytPlayer.dur * 1000);
      if (tm) tm.textContent = fmt(info.currentTime) + ' / ' + fmt(ytPlayer.dur);
    }
  });
  function wireVideo(root) {
    var frame = $('#yt-frame', root), ctl = $('#vcontrols', root);
    ytPlayer = { frame: frame, ready: false, dur: 0 };
    var me = ytPlayer;
    if (!navigator.onLine) ytFallback('VIDEO NEEDS AN INTERNET CONNECTION', 'This lesson video plays from YouTube. Connect to the internet, then reopen Checkpoint 4.');
    var listen = function () { if (frame.contentWindow) frame.contentWindow.postMessage(JSON.stringify({ event: 'listening', id: 'sq-yt', channel: 'widget' }), 'https://www.youtube.com'); };
    frame.addEventListener('load', function () { listen(); later(listen, 600); });
    later(function () { if (ytPlayer === me && !me.ready && !navigator.onLine) ytFallback('VIDEO NEEDS AN INTERNET CONNECTION', 'This lesson video plays from YouTube. Connect to the internet, then reopen Checkpoint 4.'); }, 8000);
    ctl.addEventListener('click', function (e) {
      var b = e.target.closest('[data-v]'); if (!b || b.disabled) return;
      if (b.dataset.v === 'play' || b.dataset.v === 'replay') { Voice.stop(); Coach.show('listen', 'Watch and listen carefully! Then answer the questions.'); Coach.hideLater(3500); }
      if (b.dataset.v === 'play') ytCmd('playVideo');
      if (b.dataset.v === 'pause') ytCmd('pauseVideo');
      if (b.dataset.v === 'replay') { ytCmd('seekTo', [0, true]); ytCmd('playVideo'); }
    });
    var pr = $('#vprogress', root);
    pr.addEventListener('pointerdown', function () { me.seeking = true; });
    pr.addEventListener('change', function (e) { me.seeking = false; if (me.dur) ytCmd('seekTo', [e.target.value / 1000 * me.dur, true]); });
    $('#vvol', root).addEventListener('input', function (e) { var v = +e.target.value; ytCmd('setVolume', [v]); ytCmd(v === 0 ? 'mute' : 'unMute'); });
    cleanupFns.push(function () { ytCmd('pauseVideo'); if (ytPlayer === me) ytPlayer = null; if (frame.parentNode) frame.parentNode.removeChild(frame); });
  }
  function cp4Stats() {
    var c = 0, p = 0; CP4_Q.forEach(function (q, i) { if (answered('cp4-' + i)) { c++; p += state.answered['cp4-' + i]; } });
    return { correct: c, pts: p };
  }
  function cp4Index() { for (var i = 0; i < CP4_Q.length; i++) if (!answered('cp4-' + i)) return i; return -1; }
  function updateScoreboard(i) {
    var s = cp4Stats();
    if ($('#sb-correct')) { $('#sb-correct').textContent = s.correct; $('#sb-pts').textContent = s.pts; $('#sb-q').textContent = (i === -1 ? 6 : i + 1) + '/6'; }
    setTracker(s.correct, 6, 'calls made');
  }
  function refBlow(mood) {
    var r = $('#referee'); if (!r) return;
    r.classList.remove('blow', 'happy'); void r.offsetWidth; r.classList.add(mood || 'blow');
  }
  function renderCP4(root) {
    var t = teamObj() || TEAMS[0], s = cp4Stats(), qi = cp4Index();
    root.innerHTML = cpHeader(4, tracker(s.correct, 6, 'calls made')) +
      '<div class="kit-banner orange"><span class="kb-ico">🎬</span><span><b>Step 1:</b> watch the <b>Sports Lesson Video</b> (press CC in the video for captions). <b>Step 2:</b> answer the referee\'s questions before time runs out. You can rewatch the video at any time.</span></div>' +
      '<div class="cp4-layout">' +
        '<div class="cp4-left">' + videoPlayer() +
          '<div class="video-coach">' + coachImg('proud', 'coach-small') + '<div class="bubble">Watch and listen carefully. The answers are in the lesson!</div></div>' +
          '<div class="ref-row"><div class="referee" id="referee">' + REFEREE + '</div>' +
          '<div class="scoreboard"><div class="sb-title">SCOREBOARD</div><div class="sb-grid">' +
            '<div class="sb-team"><small>TEAM</small><b>' + t.mascot + ' ' + t.name + '</b></div>' +
            '<div><small>CORRECT</small><b id="sb-correct">' + s.correct + '</b></div>' +
            '<div><small>QUESTION</small><b id="sb-q">' + (qi === -1 ? 6 : qi + 1) + '/6</b></div>' +
            '<div><small>POINTS</small><b id="sb-pts">' + s.pts + '</b></div></div></div></div>' +
        '</div>' +
        '<div class="panel cp4-show" id="cp4-show"></div>' +
      '</div>';
    wireVideo(root);
    cleanupFns.push(function () { clearInterval(cp4Timer); cp4Timer = null; });
    var show4 = $('#cp4-show');
    if (qi === -1) { cp4Finished(); return; }
    show4.innerHTML = '<div class="gs-start"><div class="gs-lights"><span></span><span></span><span></span><span></span><span></span></div><h3>🎙️ The Referee Game Show!</h3>' +
      '<p>6 questions about the <b>video lesson</b>: <b>sports</b>, <b>equipment</b> and <b>superlatives</b>. You have <b>' + CP4_TIME + ' seconds</b> for each question.</p>' +
      '<button class="btn btn-orange btn-xl glow" id="gs-go">🟨 Blow the whistle & start!</button></div>';
    $('#gs-go').addEventListener('click', function () { SFX.whistle(); refBlow(); askCP4(cp4Index()); });
  }
  function askCP4(i) {
    var q = CP4_Q[i], box = $('#cp4-show'); if (!box) return;
    updateScoreboard(i);
    box.innerHTML = '<div class="gs-q"><div class="gs-top"><small>QUESTION ' + (i + 1) + ' OF 6</small>' +
      '<div class="timer" id="timer"><svg viewBox="0 0 44 44"><circle cx="22" cy="22" r="19" class="t-bg"/><circle cx="22" cy="22" r="19" class="t-fg" id="t-fg"/></svg><b id="t-num">' + CP4_TIME + '</b></div></div>' +
      '<h3 class="gs-question">' + esc(q.q) + '</h3><div class="choices big" id="gs-choices">' +
      q.opts.map(function (o, j) { return '<button class="choice" data-j="' + j + '"><span class="ch-letter">' + 'ABC'[j] + '</span><span>' + esc(o) + '</span></button>'; }).join('') +
      '</div><div class="gs-feedback" id="gs-fb"></div></div>';
    startTimer(i);
    $('#gs-choices').addEventListener('click', function (e) {
      var b = e.target.closest('.choice'); if (!b || b.disabled) return;
      if (+b.dataset.j === q.a) {
        clearInterval(cp4Timer);
        var res = award('cp4-' + i, true);
        b.classList.add('right'); $$('#gs-choices .choice').forEach(function (x) { x.disabled = true; });
        $('#gs-fb').innerHTML = '✅ Good call!'; refBlow('happy'); good(res, b); updateScoreboard(i);
        var n = cp4Index();
        later(function () { if (n === -1) { SFX.whistle(); refBlow(); cp4Finished(); } else askCP4(n); }, 1500);
      } else {
        award('cp4-' + i, false);
        b.disabled = true; b.classList.add('wrong'); $('#gs-fb').innerHTML = '❌ Not that one — try again!';
        bad(b);
      }
    });
  }
  function startTimer(i) {
    if (answered('cp4-' + i) || !$('#t-fg')) return;
    clearInterval(cp4Timer);
    var t = CP4_TIME, fg = $('#t-fg'), C = 2 * Math.PI * 19;
    var draw = function () { if (!fg) return; fg.style.strokeDasharray = C; fg.style.strokeDashoffset = C * (1 - t / CP4_TIME); $('#t-num').textContent = t; $('#timer').classList.toggle('low', t <= 5); };
    draw();
    cp4Timer = setInterval(function () {
      t--; draw(); if (t > 0 && t <= 5) SFX.tick();
      if (t <= 0) {
        clearInterval(cp4Timer);
        award('cp4-' + i, false);
        SFX.whistle(); refBlow();
        var fb = $('#gs-fb'); if (fb) fb.innerHTML = '⏰ Time\'s up! The referee gives you another try.';
        coachSay('encourage', 'Time\'s up! Read carefully and try again.');
        later(function () { startTimer(i); }, 1600);
      }
    }, 1000);
  }
  function cp4Finished() {
    var s = cp4Stats(), box = $('#cp4-show');
    box.innerHTML = '<div class="gs-end"><span class="big-ico">🏅</span><h3>Full time!</h3><p>You made <b>' + s.correct + ' / 6</b> correct calls and scored <b>' + s.pts + ' points</b> in the game show.</p>' +
      (isDone(4) ? '<button class="btn btn-gold" data-action="map">🗺️ Back to Map</button>' : '') + '</div>';
    updateScoreboard(-1);
    if (!isDone(4)) later(function () { complete(4); }, 1400);
  }

  /* ------------------------------------------------------------------
     CHECKPOINT 5 — SPORTS REPORTER
     ------------------------------------------------------------------ */
  var pick5 = {}, rec = null, recStream = null, recChunks = [], recUrl = null;
  function renderCP5(root) {
    pick5 = { sport: null, sup: null, reason: null };
    var tasks = (state.reportChecked ? 1 : 0) + (state.teacherConfirmed ? 1 : 0);
    var group = function (g, title) {
      return '<div class="word-group"><h4>' + title + '</h4><div class="words" data-group="' + g + '">' + CP5[g].map(function (w) { return '<button class="word" data-val="' + esc(w) + '">' + esc(w) + '</button>'; }).join('') + '</div></div>';
    };
    root.innerHTML = cpHeader(5, tracker(tasks, 2, 'tasks')) +
      '<div class="kit-banner green"><span class="kb-ico">🎤</span><span>Use your digital <b>Reporter Card</b>: choose words, build your report, check it, then practise saying it aloud.</span></div>' +
      (isDone(5) ? doneBanner(5) : '') +
      '<div class="cp5-layout">' +
        '<div class="studio">' +
          '<div class="studio-window"><div class="sw-crowd"></div><div class="sw-field"></div></div>' +
          '<div class="on-air">● ON AIR</div>' +
          '<div class="studio-monitor"><span id="monitor-icon">📺</span><small id="monitor-text">Choose a sport</small></div>' +
          '<div class="studio-coach">' + coachImg('instruct', 'coach-mid') + '</div>' +
          '<div class="desk"><div class="desk-mic">' + MIC + '</div><div class="desk-logo">SPORTS QUEST NEWS</div></div>' +
          '<div class="ticker"><span>BREAKING: Year 4 reporters share their favourite sports! ⚽ 🏀 🏸 🏒 🚴 🏊 · </span></div>' +
        '</div>' +
        '<div class="panel builder">' +
          '<div class="reporter-card"><div class="rc-head"><span>📇 REPORTER CARD</span><small>' + esc((teamObj() || TEAMS[0]).mascot + ' ' + (teamObj() || TEAMS[0]).name) + ' · Sports Quest News</small></div>' +
            '<p class="rc-frame">“Hello everyone! I am your sports reporter. I think <u>(sport)</u> is the <u>(superlative)</u> sport because <u>(reason)</u>.”</p>' +
            '<ul class="rc-tips"><li>🗣️ Speak clearly and slowly.</li><li>👀 Look up at your audience.</li><li>😊 Smile and sound confident!</li></ul></div>' +
          group('sport', '1 · Choose a sport') + group('sup', '2 · Choose a superlative') + group('reason', '3 · Choose a reason') +
          '<div class="preview" id="preview"></div>' +
          '<div class="row"><button class="btn btn-gold" id="build-btn">📝 Put it in my report</button></div>' +
          '<label class="ta-label" for="report-text">✏️ My sports report (you can edit it):</label>' +
          '<textarea id="report-text" rows="3" placeholder="Hello everyone! I am your sports reporter. I think …">' + esc(state.reportText) + '</textarea>' +
          '<div class="row"><button class="btn btn-green" id="check-report">✅ Submit my report for feedback</button><span class="report-ok" id="report-ok">' + (state.reportChecked ? '✔ Report checked' : '') + '</span></div>' +
          '<ul class="report-fb" id="report-fb"></ul>' +
          '<div class="speak-box"><h4>🗣️ Speaking practice</h4><ol><li>Read your own report <b>aloud</b>, clearly and slowly.</li><li>Optional: <b>record</b> yourself and listen back.</li><li>Press <b>I practised speaking</b>.</li></ol>' +
            '<div class="rec"><button class="btn btn-small btn-orange" id="rec-start">⏺ Record (optional)</button><button class="btn btn-small btn-navy" id="rec-stop" disabled>⏹ Stop</button><audio id="rec-play" controls class="hidden"></audio></div>' +
            '<p class="rec-note" id="rec-note">Optional: recording only works if your browser supports it and you allow the microphone. It stays on this device and is not uploaded. The game does not listen to or assess your pronunciation.</p></div>' +
          // state.teacherConfirmed (old name kept so saved progress still works) now means "pupil ticked speaking practice".
          '<button class="btn btn-purple btn-lg" id="teacher-confirm">' + (state.teacherConfirmed ? '✔ Speaking practice done' : '🗣️ I practised speaking my report aloud') + '</button>' +
          '<p class="rec-note">This is a practice step you tick yourself. Pronunciation is <b>not</b> assessed by the game.</p>' +
        '</div>' +
      '</div>';
    updatePreview();
    $$('.words', root).forEach(function (w) {
      w.addEventListener('click', function (e) {
        var b = e.target.closest('.word'); if (!b) return;
        $$('.word', w).forEach(function (x) { x.classList.toggle('on', x === b); });
        pick5[w.dataset.group] = b.dataset.val; SFX.click(); updatePreview();
      });
    });
    $('#build-btn').addEventListener('click', function () {
      if (!pick5.sport || !pick5.sup || !pick5.reason) { bad($('#build-btn'), 'Choose a sport, a superlative and a reason first.', true); return; }
      var txt = 'Hello everyone! I am your sports reporter. I think ' + pick5.sport.toLowerCase() + ' is the ' + pick5.sup + ' sport because ' + pick5.reason + '.';
      $('#report-text').value = txt; state.reportText = txt; save(); SFX.drop(); restartAnim($('#report-text'), 'pop');
    });
    $('#report-text').addEventListener('input', function (e) { state.reportText = e.target.value; save(); });
    $('#check-report').addEventListener('click', function () {
      var raw = $('#report-text').value.trim(), txt = raw.toLowerCase();
      var hasSport = SPORT_IDS.some(function (id) { return txt.indexOf(SPORTS[id].name.toLowerCase()) !== -1; });
      var hasSup = /\bthe\s+(most\s+[a-z]+|best|worst|[a-z]+est)\b/.test(txt);
      var checks = [
        [hasSport, 'Names a sport (e.g. badminton)', true],
        [hasSup, 'Uses "the" + a superlative (e.g. the most exciting)', true],
        [/\bbecause\b/.test(txt), 'Gives a reason with "because"', false],
        [/^[A-Z]/.test(raw), 'Starts with a capital letter', false],
        [/[.!]$/.test(raw), 'Ends with a full stop or !', false]
      ];
      $('#report-fb').innerHTML = checks.map(function (c) { return '<li class="' + (c[0] ? 'ok' : 'no') + '">' + (c[0] ? '✔' : '✖') + ' ' + c[1] + (c[2] ? ' <small>(needed)</small>' : ' <small>(tip)</small>') + '</li>'; }).join('');
      var res = award('cp5-report', hasSport && hasSup);
      if (hasSport && hasSup) {
        state.reportChecked = true; save();
        $('#report-ok').textContent = '✔ Report checked'; good(res, $('#check-report'), 'Now read it aloud!');
        setTracker(1 + (state.teacherConfirmed ? 1 : 0), 2, 'tasks');
      } else {
        bad($('#report-text'), !hasSport ? 'Include a sport, e.g. badminton.' : 'Include a superlative, e.g. "the most exciting".');
      }
    });
    $('#teacher-confirm').addEventListener('click', function () {
      if (state.teacherConfirmed) { coachSay('celebrate', 'You have already practised. Great speaking!'); return; }
      if (!state.reportChecked) { coachSay('instruct', 'First build your report and press <b>Submit my report for feedback</b>.'); return; }
      var res = award('cp5-speaking', true);
      state.teacherConfirmed = true; save();
      $('#teacher-confirm').textContent = '✔ Speaking practice done';
      setTracker(2, 2, 'tasks'); good(res, $('#teacher-confirm'), 'Well done for practising!');
      later(function () { complete(5); }, 1200);
    });
    wireRecorder();
  }
  function updatePreview() {
    var p = $('#preview'); if (!p) return;
    var f = function (v) { return v ? '<b>' + esc(v) + '</b>' : '<span class="gap">____</span>'; };
    p.innerHTML = '🎙️ I think ' + f(pick5.sport && pick5.sport.toLowerCase()) + ' is the ' + f(pick5.sup) + ' sport because ' + f(pick5.reason) + '.';
    var id = null; SPORT_IDS.forEach(function (x) { if (pick5.sport === SPORTS[x].name) id = x; });
    $('#monitor-icon').textContent = id ? SPORTS[id].icon : '📺';
    $('#monitor-text').textContent = id ? SPORTS[id].name : 'Choose a sport';
  }
  function wireRecorder() {
    var note = $('#rec-note'), start = $('#rec-start'), stop = $('#rec-stop'), play = $('#rec-play');
    var supported = !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia && window.MediaRecorder);
    if (!supported) { start.disabled = true; note.textContent = 'Recording is not supported in this browser. You can still read your report aloud and practise without recording.'; return; }
    start.addEventListener('click', function () {
      navigator.mediaDevices.getUserMedia({ audio: true }).then(function (stream) {
        recStream = stream; recChunks = [];
        rec = new MediaRecorder(stream);
        rec.ondataavailable = function (e) { if (e.data && e.data.size) recChunks.push(e.data); };
        rec.onstop = function () {
          var blob = new Blob(recChunks, { type: rec.mimeType || 'audio/webm' });
          if (recUrl) URL.revokeObjectURL(recUrl);
          recUrl = URL.createObjectURL(blob); play.src = recUrl; play.classList.remove('hidden');
          stopStream(); note.textContent = 'Recording ready — press play to listen to yourself. (Saved on this device only, until you leave this screen.)';
        };
        rec.start(); start.disabled = true; stop.disabled = false; start.classList.add('recording');
        note.textContent = '🔴 Recording… read your report aloud, then press Stop.';
      }).catch(function () { note.textContent = 'Microphone permission was not given. That is OK — read your report aloud without recording.'; });
    });
    stop.addEventListener('click', function () {
      if (rec && rec.state !== 'inactive') rec.stop();
      start.disabled = false; stop.disabled = true; start.classList.remove('recording');
    });
    cleanupFns.push(function () { if (rec && rec.state !== 'inactive') { rec.onstop = null; rec.stop(); } stopStream(); });
  }
  function stopStream() { if (recStream) { recStream.getTracks().forEach(function (t) { t.stop(); }); recStream = null; } }

  /* ------------------------------------------------------------------
     CHECKPOINT 6 — CHAMPION ZONE + CERTIFICATE
     ------------------------------------------------------------------ */
  function cp6Index() { for (var i = 0; i < CP6_Q.length; i++) if (!answered('cp6-' + i)) return i; return -1; }
  function renderCP6(root) {
    var qi = cp6Index();
    if (qi === -1) { if (!isDone(6)) complete(6); renderFinale(root); return; }
    root.innerHTML = cpHeader(6, tracker(qi, 5, 'questions')) +
      '<div class="kit-banner gold"><span class="kb-ico">🏆</span><span>Final challenge! Answer <b>5 questions</b> to become a <b>Champion</b>.</span></div>' +
      '<div class="cp6-layout"><div class="panel cp6-q" id="cp6-q"></div>' +
      '<div class="cp6-side">' + coachImg('instruct', 'coach-mid') + '<div class="bubble">Read carefully. You can do it, champion!</div>' +
      '<div class="cp6-types">' + CP6_Q.map(function (q, i) { return '<span class="' + (answered('cp6-' + i) ? 'on' : '') + '">' + (i + 1) + '. ' + q.type + '</span>'; }).join('') + '</div></div></div>';
    askCP6(qi);
  }
  function askCP6(i) {
    var q = CP6_Q[i], box = $('#cp6-q'); if (!box) return;
    box.innerHTML = '<small class="q-type">QUESTION ' + (i + 1) + ' OF 5 · ' + q.type.toUpperCase() + '</small>' +
      (q.passage ? '<div class="passage">📖 ' + esc(q.passage) + '</div>' : '') +
      (q.visual ? '<div class="q-visual">' + eqArt(q.visual) + '<span>' + EQUIP[q.visual].label + '</span></div>' : '') +
      '<h3 class="cz-question">' + esc(q.q) + '</h3>' +
      '<div class="choices grid2" id="cz-choices">' + q.opts.map(function (o, j) { return '<button class="choice" data-j="' + j + '"><span class="ch-letter">' + 'ABCD'[j] + '</span><span>' + esc(o) + '</span></button>'; }).join('') + '</div>' +
      '<div class="gs-feedback" id="cz-fb"></div>';
    $('#cz-choices').addEventListener('click', function (e) {
      var b = e.target.closest('.choice'); if (!b || b.disabled) return;
      if (+b.dataset.j === q.a) {
        var res = award('cp6-' + i, true);
        b.classList.add('right'); $$('#cz-choices .choice').forEach(function (x) { x.disabled = true; });
        $('#cz-fb').innerHTML = '✅ Correct! ' + (res.pts ? '+' + res.pts + ' points' : '');
        good(res, b);
        var n = cp6Index(); setTracker(n === -1 ? 5 : n, 5, 'questions');
        var types = $$('.cp6-types span'); if (types[i]) types[i].classList.add('on');
        later(function () {
          if (n === -1) { complete(6); renderFinale($('#screen-play')); } else askCP6(n);
        }, 1400);
      } else {
        award('cp6-' + i, false);
        b.disabled = true; b.classList.add('wrong'); $('#cz-fb').innerHTML = '❌ Not quite. Try again!';
        bad(b);
      }
    });
  }
  function badgesHTML() {
    return CHECKPOINTS.map(function (c) { var e = isDone(c.n); return '<div class="badge' + (e ? ' earned' : '') + '" style="--i:' + c.n + '"><span class="bd-ico">' + (e ? c.icon : '🔒') + '</span><span class="bd-name">' + c.name + '</span></div>'; }).join('');
  }
  function certificateHTML() {
    var t = teamObj() || TEAMS[0];
    var d = new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' });
    return '<div class="certificate"><div class="cert-inner">' +
      '<div class="cert-trophy">' + TROPHY + '</div>' +
      '<div class="cert-kicker">THE ULTIMATE SPORTS QUEST — STADIUM ADVENTURE</div>' +
      '<h2 class="cert-title">Champion Certificate</h2>' +
      '<p>This certificate is proudly presented to</p>' +
      '<div class="cert-name" id="cert-name">' + (state.pupilName ? esc(state.pupilName) : '______________________') + '</div>' +
      '<p>of team <b>' + t.mascot + ' ' + t.name + '</b> for completing all six checkpoints<br>of the Sports and Health adventure (Year 4 English).</p>' +
      '<div class="cert-stats"><span>🪙 ' + state.points + ' points</span><span>⭐ ' + state.stars + ' stars</span><span>🏁 ' + state.completed.length + '/6 checkpoints</span></div>' +
      '<div class="cert-badges">' + CHECKPOINTS.map(function (c) { return '<span>' + c.icon + '<small>' + c.name + '</small></span>'; }).join('') + '</div>' +
      '<div class="cert-foot"><span>Date: ' + d + '</span><span>Teacher: ____________________</span></div>' +
      '</div></div>';
  }
  function renderFinale(root) {
    var t = teamObj() || TEAMS[0], champ = state.completed.length === 6;
    root.innerHTML =
      '<div class="cp-head"><button class="btn btn-small btn-navy" data-action="map">⬅ Map</button><div class="cp-title"><span class="cp-ico">🏆</span><div><small>CHAMPION HALL</small><h2>' + (champ ? 'Champion Status Unlocked!' : 'Champion Zone') + '</h2></div></div><span></span></div>' +
      '<div class="finale">' +
        '<div class="finale-top panel">' +
          '<div class="finale-trophy">' + TROPHY + '<div class="trophy-glow"></div></div>' +
          '<div class="finale-text"><small>' + t.mascot + ' TEAM ' + t.name.toUpperCase() + '</small><h2>You are a Sports Quest Champion!</h2>' +
            '<div class="finale-stats"><div><b>' + state.points + '</b><small>Total points</small></div><div><b>' + state.stars + '</b><small>Stars</small></div><div><b>' + state.completed.length + '/6</b><small>Checkpoints</small></div></div></div>' +
          coachImg('champion', 'coach-tall') +
        '</div>' +
        '<div class="badges">' + badgesHTML() + '</div>' +
        '<div class="finale-bottom">' +
          '<div class="panel reflect"><h3>💭 What did you learn today?</h3><textarea id="reflection" rows="4" placeholder="Today I learned…">' + esc(state.reflection) + '</textarea>' +
            '<div class="row"><button class="btn btn-green" id="save-reflect">💾 Save my reflection</button><span id="reflect-saved" class="report-ok"></span></div></div>' +
          '<div class="panel cert-panel"><h3>📜 Champion Certificate</h3>' +
            '<div class="row"><label class="name-label">Your name: <input id="pupil-name" maxlength="40" value="' + esc(state.pupilName) + '" placeholder="Type your name"></label>' +
            '<button class="btn btn-gold" id="print-cert">🖨️ Print certificate</button></div>' +
            '<div class="cert-preview" id="cert-preview">' + certificateHTML() + '</div></div>' +
        '</div>' +
      '</div>';
    SFX.fanfare(); confetti(220); setTimeout(function () { confetti(120); }, 1200);
    Voice.say('final', { instruction: true, extra: '🏆 ' + esc(t.mascot + ' ' + t.name) + ' — you are CHAMPIONS!' });
    $('#save-reflect').addEventListener('click', function () {
      state.reflection = $('#reflection').value; save();
      $('#reflect-saved').textContent = state.reflection.trim() ? '✔ Saved!' : 'Write something first!';
      if (state.reflection.trim()) SFX.star();
    });
    $('#pupil-name').addEventListener('input', function (e) {
      state.pupilName = e.target.value; save();
      $('#cert-preview').innerHTML = certificateHTML();
    });
    $('#print-cert').addEventListener('click', function () {
      $('#print-area').innerHTML = certificateHTML();
      window.print();
    });
  }

  /* ------------------------------------------------------------------
     8. MODALS: How to Play · Notes · Teacher
     ------------------------------------------------------------------ */
  function openModal(html, cls) {
    $('#modal-root').innerHTML = '<div class="modal-backdrop"><div class="modal panel ' + (cls || '') + '" role="dialog" aria-modal="true"><button class="modal-x" data-action="close-modal" aria-label="Close">✕</button>' + html + '</div></div>';
  }
  function closeModal() { $('#modal-root').innerHTML = ''; }
  function openHowTo() {
    var steps = [['👥', 'Choose your team', 'Pick Blue Lightning, Green Dragons, Orange Rockets or Purple Panthers.'], ['🗺️', 'Explore the Stadium Map', 'Start at Checkpoint 1. Finish one checkpoint to unlock the next.'], ['🪙', 'Earn points', 'Correct first try = 10 points. Correct after a retry = 5 points.'], ['⭐', 'Collect stars', 'Every completed checkpoint gives you 1 star.'], ['🧰', 'Everything is inside the game', 'Sports Fact Files, the Decoder Wheel, Sentence Cards, the lesson video and the Reporter Card are all built in. Press 📚 Learn to see the learning path.'], ['🏆', 'Become a Champion', 'Complete all 6 checkpoints to unlock Champion status and your certificate.']];
    openModal('<h2 class="modal-title">❓ How to Play</h2><div class="howto">' + steps.map(function (s, i) { return '<div class="how-step" style="--i:' + i + '"><span class="hs-ico">' + s[0] + '</span><div><b>' + s[1] + '</b><p>' + s[2] + '</p></div></div>'; }).join('') + '</div>' +
      '<div class="modal-actions"><button class="btn btn-gold btn-lg" data-action="close-modal">Got it! 👍</button></div>', 'modal-wide');
  }
  function openNotes() {
    var sportsTab = '<div class="note-cards six">' + SPORT_IDS.map(function (id) {
      var s = SPORTS[id];
      return '<div class="note-card" role="button" tabindex="0"><div class="nc-inner"><div class="nc-front"><span class="nc-ico">' + s.icon + '</span><b>' + s.name + '</b><small>Tap to learn</small></div>' +
        '<div class="nc-back">' + eqArt(id, 'nc-art') + '<span class="nc-eq">' + EQUIP[id].label + '</span><p>' + esc(FACTS[id].text) + '</p>' + '</div></div></div>';
    }).join('') + '</div>';
    openModal('<div class="modal-coach-head">' + coachImg('instruct', 'coach-small') + '<h2 class="modal-title">📒 Interactive Notes</h2></div><div class="tabs"><button class="tab on" data-tab="t-sports">🏅 Sports & Equipment</button><button class="tab" data-tab="t-sup">🔤 Superlatives</button></div>' +
      '<div class="tab-panel" id="t-sports">' + sportsTab + '</div><div class="tab-panel hidden" id="t-sup"><div class="np-head">' + audioCtl('grammar', 'Listen to the grammar notes') + '</div>' + superlativeNotes() +
      '<table class="sup-table"><tr><th>Adjective</th><th>Superlative</th></tr>' + CP3.map(function (c) { return '<tr><td>' + c.adj.toLowerCase() + '</td><td>the ' + c.answer + '</td></tr>'; }).join('') + '</table></div>', 'modal-wide');
  }
  /* The six EDUP6023 multimedia components (separate from the six game checkpoints). */
  function mp3Count(prefix) { var k = Object.keys(NARRATION).filter(function (x) { return x.indexOf(prefix) === 0; }); return k.filter(function (x) { return status[A['au_' + x]] === true; }).length + ' / ' + k.length; }
  function openLearningPath() {
    var cpBtn = function (n, label) {
      var c = CHECKPOINTS[n - 1], open = isUnlocked(n);
      return '<button class="btn btn-small ' + (open ? 'btn-gold' : 'btn-navy') + '" ' + (open ? 'data-action="enter" data-n="' + n + '"' : 'disabled') + '>' + (open ? '▶ ' : '🔒 ') + (label || 'CP' + n + ' ' + c.name) + (isDone(n) ? ' ✔' : '') + '</button>';
    };
    var vid = '▶ Provided via YouTube embed (needs internet)';
    var parts = [
      ['🎯', 'Introduction & learning objectives', 'Meet the coach and see your three learning goals.', '<button class="btn btn-small btn-gold" data-action="objectives">▶ Open objectives</button>', 'Narration: ' + mp3Count('objectives') + ' MP3'],
      ['📒', 'Interactive text & graphic learning notes', 'Flip cards with pictures about sports, equipment and superlatives, plus the Grammar Note.', '<button class="btn btn-small btn-gold" data-action="notes">▶ Open notes</button><button class="btn btn-small btn-gold" data-action="grammar-note">▶ Grammar note</button>', ''],
      ['📖', 'Reading activity', 'Read the six Sports Fact Files, then answer their questions.', cpBtn(1, 'CP1 Sports Detective'), 'Text only (no audio)'],
      ['🎬', 'Video learning activity (MP4)', 'Watch the sports lesson video (YouTube) and answer the questions.', cpBtn(4, 'CP4 Virtual Referee'), vid],
      ['🎡', 'Interactive animated activities', 'Drag-and-drop Equipment Match, the spinning Decoder Wheel and the Reporter Card builder.', cpBtn(2, 'CP2') + cpBtn(3, 'CP3') + cpBtn(5, 'CP5'), ''],
      ['🏆', 'Formative quiz with immediate feedback', 'The Champion Zone final quiz. Every checkpoint also gives instant feedback.', cpBtn(6, 'CP6 Champion Zone'), '']
    ];
    openModal('<div class="modal-coach-head">' + coachImg('wave', 'coach-small') + '<h2 class="modal-title">📚 Learning Path</h2></div>' +
      '<p class="small">The lesson has six learning parts. They are spread across the six checkpoints on the Stadium Map, which unlock in order.</p>' +
      '<div class="lpath">' + parts.map(function (p, i) {
        return '<div class="lp-item" style="--i:' + i + '"><span class="lp-num">' + (i + 1) + '</span><span class="lp-ico">' + p[0] + '</span><div class="lp-body"><b>' + p[1] + '</b><p>' + p[2] + '</p>' + (p[4] ? '<small class="lp-media">' + p[4] + '</small>' : '') + '</div><div class="lp-go">' + p[3] + '</div></div>';
      }).join('') + '</div>' +
      '<div class="modal-actions"><button class="btn btn-gold" data-action="map">🗺️ Stadium Map</button></div>', 'modal-wide');
  }
  function openTeacher() { openModal('<div id="teacher-body"></div>', 'modal-wide modal-teacher'); refreshTeacher(); }
  function refreshTeacher() {
    var body = $('#teacher-body'); if (!body) return;
    var found = 0, missing = 0, unk = 0, opt = 0;
    var rows = ASSET_LIST.map(function (r) {
      var s = status[A[r[1]]], label;
      if (s === true) { found++; label = '<span class="st ok">✅ Found</span>'; }
      else if (s === false && r[4] === 'optional') { opt++; label = '<span class="st un">➖ Optional — not added</span>'; }
      else if (s === false) { missing++; label = '<span class="st no">❌ MISSING</span>'; }
      else { unk++; label = '<span class="st un">⏳ Checking / not confirmed</span>'; }
      return '<tr><td>' + r[0] + '</td><td><code>' + A[r[1]] + '</code></td><td>' + r[3] + '</td><td>' + label + '</td></tr>';
    }).join('');
    body.innerHTML = '<h2 class="modal-title">👩‍🏫 Teacher Panel</h2>' +
      '<div class="teacher-grid"><div class="t-box"><b>' + found + '</b><small>assets found</small></div><div class="t-box bad"><b>' + missing + '</b><small>assets missing</small></div><div class="t-box"><b>' + unk + '</b><small>not confirmed</small></div><div class="t-box"><b>' + opt + '</b><small>optional, not added</small></div><div class="t-box"><b>' + (storageOK ? 'Yes' : 'No') + '</b><small>progress saving</small></div></div>' +
      '<p class="t-note">⚠️ <b>Learning objectives are provisional</b> and need teacher confirmation. DSKP learning standards are <b>pending verification</b> and are not stated in the game.</p>' +
      '<p class="t-note">Missing images show labelled placeholders. Missing audio (no local MP3 and no online coach voice) shows “AUDIO NOT YET AVAILABLE”. The Checkpoint 4 video is the YouTube video <code>' + YT_ID + '</code>, embedded in the game (it needs an internet connection; a “Watch on YouTube” link shows if it cannot play). Equipment pictures are built-in drawings unless optional photos are added. Background music uses an original synthesised loop when <code>background-music.mp3</code> is missing.</p>' +
      '<p class="t-note">Pupil progress: <b>' + state.points + '</b> points · <b>' + state.stars + '</b> stars · checkpoints completed: <b>' + (state.completed.slice().sort().join(', ') || 'none') + '</b>' + (state.reflection ? '<br>Reflection: “' + esc(state.reflection) + '”' : '') + '</p>' +
      voiceReport() +
      '<div class="t-table-wrap"><table class="asset-table"><tr><th>Type</th><th>File</th><th>Purpose</th><th>Status</th></tr>' + rows + '</table></div>' +
      '<div class="modal-actions"><button class="btn btn-orange" data-action="reset">↺ Reset game for a new pupil</button><button class="btn btn-gold" data-action="close-modal">Close</button></div>';
  }

  function voiceReport() {
    var keys = Object.keys(NARRATION), rec = 0, miss = 0;
    keys.forEach(function (k) { var st = status[A['au_' + k]]; if (st === true) rec++; else if (st === false) miss++; });
    var ai = AIVoice.info;
    var aiLine = !AIVoice.enabled ? '⚪ Not available when the game is opened as a local file (offline mode uses the local MP3s).' :
      !ai ? '⏳ Checking the coach voice service…' :
      ai.configured ? '✅ <b>Connected.</b> The coach speaks every line with your one ElevenLabs Voice ID (model ' + esc(ai.model || '') + '). Generated lines are cached, so each one is only created once per deploy.' :
      ai.unreachable ? '❌ The voice service could not be reached (no internet, or running without Netlify Functions).' :
      '❌ <b>Not set up.</b> Add <code>ELEVENLABS_API_KEY</code> and <code>ELEVENLABS_VOICE_ID</code> in Netlify: Site configuration → Environment variables, then redeploy.';
    var ex = exportState;
    return '<div class="t-voice"><h3>🎙️ Coach voice</h3>' +
      '<p class="t-note">ElevenLabs voice: ' + aiLine + '</p>' +
      '<p class="t-note">Local MP3s found in <code>assets/audio/</code>: <b>' + rec + ' / ' + keys.length + '</b>' + (miss ? ' (missing: ' + miss + ')' : '') + '. Local files are always played first and work offline. Without a local file and without the online voice, the coach shows “AUDIO NOT YET AVAILABLE”.</p>' +
      '<p class="t-note"><b>Make the offline audio pack:</b> download every line as an MP3 in the same voice, then unzip it into the game folder (it fills <code>assets/audio/</code>).</p>' +
      '<div class="modal-actions" style="justify-content:flex-start;margin-top:6px"><button class="btn btn-small btn-green" data-action="export-audio"' + (ai && ai.configured && !ex.busy ? '' : ' disabled') + '>⬇ Download offline narration pack (ZIP)</button>' +
        (ex.msg ? '<span class="t-note" style="margin:0">' + ex.msg + '</span>' : '') + '</div>' +
      '<p class="t-note">🎧 Your voice style sample (reference only, not played to pupils):</p><audio class="t-ref" controls preload="none" src="' + A.voice_ref + '"></audio></div>';
  }

  /* Offline narration pack: fetches every line through /api/tts (same Voice ID)
     and saves them in one ZIP laid out as assets/audio/... */
  var exportState = { busy: false, msg: '' };
  function crc32(buf) {
    var t = crc32.t, c, i, k, crc = -1;
    if (!t) { t = crc32.t = []; for (i = 0; i < 256; i++) { c = i; for (k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[i] = c >>> 0; } }
    for (i = 0; i < buf.length; i++) crc = (crc >>> 8) ^ t[(crc ^ buf[i]) & 255];
    return (crc ^ -1) >>> 0;
  }
  function makeZip(files) {
    var parts = [], central = [], off = 0, enc = new TextEncoder();
    files.forEach(function (f) {
      var n = enc.encode(f.name), crc = crc32(f.data), len = f.data.length, h = new DataView(new ArrayBuffer(30)), c = new DataView(new ArrayBuffer(46));
      h.setUint32(0, 0x04034b50, true); h.setUint16(4, 20, true); h.setUint16(6, 0x0800, true); h.setUint16(12, 0x21, true);
      h.setUint32(14, crc, true); h.setUint32(18, len, true); h.setUint32(22, len, true); h.setUint16(26, n.length, true);
      c.setUint32(0, 0x02014b50, true); c.setUint16(4, 20, true); c.setUint16(6, 20, true); c.setUint16(8, 0x0800, true); c.setUint16(14, 0x21, true);
      c.setUint32(16, crc, true); c.setUint32(20, len, true); c.setUint32(24, len, true); c.setUint16(28, n.length, true); c.setUint32(42, off, true);
      parts.push(h.buffer, n, f.data); central.push(c.buffer, n); off += 30 + n.length + len;
    });
    var size = 0; central.forEach(function (x) { size += x.byteLength; });
    var e = new DataView(new ArrayBuffer(22));
    e.setUint32(0, 0x06054b50, true); e.setUint16(8, files.length, true); e.setUint16(10, files.length, true); e.setUint32(12, size, true); e.setUint32(16, off, true);
    return new Blob(parts.concat(central, [e.buffer]), { type: 'application/zip' });
  }
  function exportNarration() {
    if (exportState.busy) return;
    var keys = Object.keys(NARRATION), files = [], i = 0;
    exportState = { busy: true, msg: 'Preparing 0 / ' + keys.length + '…' }; refreshTeacher();
    (function next() {
      if (i >= keys.length) {
        var url = URL.createObjectURL(makeZip(files)), a = document.createElement('a');
        a.href = url; a.download = 'sports-quest-narration.zip'; document.body.appendChild(a); a.click(); a.remove();
        setTimeout(function () { URL.revokeObjectURL(url); }, 60000);
        exportState = { busy: false, msg: '✅ Downloaded ' + files.length + ' MP3s. Unzip into the game folder.' }; refreshTeacher(); return;
      }
      var k = keys[i];
      AIVoice.get(k).then(function () { return AIVoice.blobs[k].arrayBuffer(); }).then(function (buf) {
        files.push({ name: 'assets/audio/' + NARRATION[k].file, data: new Uint8Array(buf) });
        i++; exportState.msg = 'Preparing ' + i + ' / ' + keys.length + '…'; refreshTeacher(); next();
      }, function (e) { exportState = { busy: false, msg: '❌ Stopped at ' + esc(NARRATION[k].file) + ': ' + esc(e.message) }; refreshTeacher(); });
    })();
  }
  function doReset() {
    if (!window.confirm('Reset the game?\n\nThis clears the team, points, stars and all checkpoint progress on this device.')) return;
    try { localStorage.removeItem(STORE_KEY); } catch (e) {}
    var keep = { voice: state.voice, voiceVol: state.voiceVol, muted: state.muted, sound: state.sound };
    state = defaultState(); for (var k in keep) state[k] = keep[k]; save();
    lastTokenCP = null; mapSel = null;
    closeModal(); Voice.stop();
    renderWelcome(); show('welcome');
    coachSay('welcome', 'The game has been reset. Ready for a new adventure!');
  }
  function resume() {
    var s = state.screen || '';
    if (!state.team) { renderTeam(); show('team'); return; }
    if (s.indexOf('cp') === 0) { var n = +s.slice(2); if (n >= 1 && n <= 6 && isUnlocked(n)) { openCheckpoint(n); return; } }
    if (s === 'objectives') { renderObjectives(); show('objectives'); return; }
    goMap();
  }

  /* ------------------------------------------------------------------
     9. GLOBAL EVENTS
     ------------------------------------------------------------------ */
  document.addEventListener('click', function (e) {
    var au = e.target.closest('[data-audio]');
    if (au) { Voice.button(au.dataset.audio, au.closest('.audio-ctl')); return; }
    var nc = e.target.closest('.note-card');
    if (nc) { nc.classList.toggle('flipped'); SFX.flip(); return; }
    var tab = e.target.closest('.tab');
    if (tab) {
      $$('.tab').forEach(function (x) { x.classList.toggle('on', x === tab); });
      $$('.tab-panel').forEach(function (p) { p.classList.toggle('hidden', p.id !== tab.dataset.tab); });
      SFX.click(); return;
    }
    var tc = e.target.closest('.team-card');
    if (tc) {
      state.team = tc.dataset.team; save(); SFX.star(); starBurst(tc);
      $$('.team-card').forEach(function (x) { x.classList.toggle('selected', x === tc); });
      var go = $('[data-action="team-go"]'); if (go) go.disabled = false;
      updateHUD(); return;
    }
    if (e.target.classList.contains('modal-backdrop')) { closeModal(); return; }
    var t = e.target.closest('[data-action]');
    if (!t || t.disabled) return;
    SFX.click();
    switch (t.dataset.action) {
      case 'start': renderTeam(); show('team'); break;
      case 'continue': resume(); break;
      case 'home': renderWelcome(); show('welcome'); break;
      case 'howto': openHowTo(); break;
      case 'teacher': openTeacher(); break;
      case 'music': toggleMusic(); break;
      case 'sound': state.sound = !state.sound; save(); updateToggles(); break;
      case 'team-go': if (state.team) { renderObjectives(); show('objectives'); coachSay('welcome', 'Welcome, ' + esc(teamObj().name) + '! ' + teamObj().cheer); } break;
      case 'map': closeModal(); goMap(); break;
      case 'notes': openNotes(); break;
      case 'learn': openLearningPath(); break;
      case 'objectives': closeModal(); if (state.team) { renderObjectives(); show('objectives'); } break;
      case 'fact-files': openFactPicker(); break;
      case 'grammar-note': openGrammarNote(); break;
      case 'reset': doReset(); break;
      case 'close-modal': closeModal(); break;
      case 'enter': closeModal(); openCheckpoint(+t.dataset.n); break;
      case 'voice': Voice.setOn(!state.voice); break;
      case 'replay': Voice.replay(); break;
      case 'replay-team': Voice.say('team', { manual: true, instruction: true, ctl: $('#screen-team .audio-ctl') }); break;
      case 'replay-welcome': Voice.say('welcome', { manual: true, instruction: true, ctl: $('#screen-welcome .audio-ctl') }); break;
      case 'bubble-close': Coach.hide(); break;
      case 'narr-toggle': Voice.toggle(); break;
      case 'mute': Voice.setMuted(!state.muted); break;
      case 'export-audio': exportNarration(); break;
    }
  });
  // First interaction: unlock audio, then play any narration that was waiting (e.g. the welcome line).
  document.addEventListener('pointerdown', firstInteraction, true);
  // A tap anywhere else tucks away a silent speech bubble, so it never sits over questions.
  document.addEventListener('pointerdown', function (e) { if (!Voice.mode && !e.target.closest('#coach-dock') && !Voice.pending) Coach.hide(); });
  document.addEventListener('keydown', firstInteraction, true);
  document.addEventListener('click', function () {
    if (Voice.pending && !Voice.mode) { var k = Voice.pending; Voice.say(k, { instruction: Voice.instr === k || k === 'welcome' || k === 'team' }); }
  });
  document.addEventListener('keydown', function (e) {
    if ((e.key === 'Enter' || e.key === ' ') && e.target.matches && e.target.matches('.note-card')) { e.preventDefault(); e.target.click(); }
    if (e.key === 'Escape' && $('.modal-backdrop')) closeModal();
  });

  /* ------------------------------------------------------------------
     10. START
     ------------------------------------------------------------------ */
  Voice.init();
  AIVoice.check();
  Coach.render();
  renderHUD();
  renderWelcome();
  spawnStars();
  show('welcome');
  probeAltImages();
  checkAssets();
})();
