// Single source of the coach's spoken lines for the ElevenLabs function and the offline export.
// Generated from the NARRATION manifest in script.js (window.SQ.narration). Keep the two in sync:
// The function refuses any request whose text hash does not match, so stale pages get a clear error.
export const LINES = {
  "welcome": { file: "coach/coach-welcome.mp3", text: "Hello, young champions! Welcome to The Ultimate Sports Quest! I'm your Virtual Sports Coach, and I'll guide you through six exciting challenges. Are you ready to begin? Let's go!" },
  "team": { file: "coach/coach-team.mp3", text: "Choose your team and get ready to explore! Every great champion starts with a team. Let's work together and have fun!" },
  "objectives": { file: "learning-objectives.mp3", text: "Here is your mission! By the end of this adventure, you can do three things. One: identify different sports and their equipment. Two: use superlative adjectives correctly. Three: create simple sentences to talk about sports." },
  "cp1": { file: "coach/coach-checkpoint-1.mp3", text: "Welcome to Sports Detective! Read the clues carefully and find the correct sport. You can use your Sports Fact File to help you!" },
  "cp2": { file: "coach/coach-checkpoint-2.mp3", text: "Great job, champions! Now match each sport with the correct equipment. Drag the equipment to the right place!" },
  "cp3": { file: "coach/coach-checkpoint-3.mp3", text: "It's time for the Grammar Decoder! Take your Sentence Card, spin your Decoder Wheel, and find the correct superlative adjective!" },
  "cp4": { file: "coach/coach-checkpoint-4.mp3", text: "Welcome to the Virtual Referee Challenge! Watch carefully, listen closely, and choose the correct answer!" },
  "cp5": { file: "coach/coach-checkpoint-5.mp3", text: "You're a sports reporter now! Use your Reporter Card and tell us about your favourite sport. Speak clearly and confidently!" },
  "cp6": { file: "coach/coach-checkpoint-6.mp3", text: "You've made it to the Champion Zone! Complete the final challenge and show us what you've learned!" },
  "correct1": { file: "coach/coach-correct-1.mp3", text: "Excellent work!" },
  "correct2": { file: "coach/coach-correct-2.mp3", text: "That's correct!" },
  "correct3": { file: "coach/coach-correct-3.mp3", text: "Fantastic job!" },
  "correct4": { file: "coach/coach-correct-4.mp3", text: "You're doing great!" },
  "wrong1": { file: "coach/coach-try-again-1.mp3", text: "Good try! Let's try again!" },
  "wrong2": { file: "coach/coach-try-again-2.mp3", text: "Not quite! Look at the clue carefully." },
  "wrong3": { file: "coach/coach-try-again-3.mp3", text: "Keep going! You can do it!" },
  "complete": { file: "coach/coach-checkpoint-complete.mp3", text: "Congratulations! You've completed this checkpoint. Let's move on!" },
  "final": { file: "coach/coach-final-celebration.mp3", text: "Congratulations, champions! You've completed The Ultimate Sports Quest! I'm so proud of your hard work!" },
  "grammar": { file: "grammar-explanation.mp3", text: "We use superlatives to compare three or more things. For short words, add e-s-t. Tall becomes tallest. Fast becomes fastest. For words ending in y, change y to i, then add e-s-t. Easy becomes easiest. For long words, put most before the word. Difficult becomes most difficult. Popular becomes most popular. Some words change completely. Good becomes best. Bad becomes worst. Remember to use the before a superlative: the tallest, the best, the most popular." }
};

// Small stable hash (djb2, base 36). The same function is used in script.js.
export function lineHash(text) {
  let h = 5381;
  for (let i = 0; i < text.length; i++) h = ((h * 33) ^ text.charCodeAt(i)) >>> 0;
  return h.toString(36);
}
