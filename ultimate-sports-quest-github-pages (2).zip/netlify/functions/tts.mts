// Coach voice: ElevenLabs Text-to-Speech, server-side only.
//
// GET /api/tts?key=<line key>&v=<text hash>  → audio/mpeg for one fixed coach line
// GET /api/tts?status=1                      → { configured, model } (never reveals secrets)
//
// Configure in Netlify: Site configuration → Environment variables
//   ELEVENLABS_API_KEY   (secret)   ELEVENLABS_VOICE_ID   ELEVENLABS_MODEL_ID (optional)
//
// Safety: only the game's own lines (LINES) can be spoken, and `v` must match the
// line's text hash, so there are exactly one cacheable URL per line. Responses are
// stored in Netlify's durable CDN cache, so each line is generated once per deploy.
import { LINES, lineHash } from '../narration-lines.mjs'

const DEFAULT_MODEL = 'eleven_multilingual_v2'
// One consistent voice character for every line: friendly, clear, moderate pace.
const VOICE_SETTINGS = { stability: 0.55, similarity_boost: 0.8, style: 0.25, use_speaker_boost: true, speed: 0.92 }

const json = (status: number, body: Record<string, unknown>) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
  })

export default async (req: Request) => {
  if (req.method !== 'GET') return json(405, { error: 'Only GET is supported.' })

  const url = new URL(req.url)
  const apiKey = process.env.ELEVENLABS_API_KEY
  const voiceId = process.env.ELEVENLABS_VOICE_ID
  const model = process.env.ELEVENLABS_MODEL_ID || DEFAULT_MODEL

  if (url.searchParams.has('status')) {
    return json(200, { configured: Boolean(apiKey && voiceId), model, lines: Object.keys(LINES).length })
  }

  // Only ?key=&v= is accepted, so there is exactly one cacheable URL per line.
  if ([...url.searchParams.keys()].some((k) => k !== 'key' && k !== 'v')) return json(400, { error: 'Unexpected parameter.' })
  const key = url.searchParams.get('key') || ''
  const line = (LINES as Record<string, { file: string; text: string }>)[key]
  if (!line) return json(404, { error: 'Unknown narration line.' })
  if (url.searchParams.get('v') !== lineHash(line.text)) {
    return json(409, { error: 'This narration text has changed. Reload the page to get the latest game version.' })
  }
  if (!apiKey || !voiceId) {
    return json(503, { error: 'The ElevenLabs voice is not set up yet (ELEVENLABS_API_KEY and ELEVENLABS_VOICE_ID are missing).' })
  }

  let res: Response
  try {
    res = await fetch(
      `https://api.elevenlabs.io/v1/text-to-speech/${encodeURIComponent(voiceId)}?output_format=mp3_44100_128`,
      {
        method: 'POST',
        headers: { 'xi-api-key': apiKey, 'Content-Type': 'application/json', Accept: 'audio/mpeg' },
        body: JSON.stringify({ text: line.text, model_id: model, voice_settings: VOICE_SETTINGS }),
      },
    )
  } catch {
    return json(502, { error: 'Could not reach ElevenLabs. Check the internet connection and try again.' })
  }

  if (!res.ok) {
    let detail = ''
    try {
      const body = await res.json()
      detail = body?.detail?.message || body?.detail?.status || (typeof body?.detail === 'string' ? body.detail : '')
    } catch {
      /* not JSON */
    }
    const reason =
      res.status === 401 ? 'the API key was rejected' :
      res.status === 404 ? 'the Voice ID was not found' :
      res.status === 429 ? 'the ElevenLabs quota or rate limit was reached' :
      `ElevenLabs returned an error (${res.status})`
    console.error('ElevenLabs TTS failed', res.status, detail)
    return json(502, { error: `Speech generation failed: ${reason}.`, detail })
  }

  const audio = await res.arrayBuffer()
  return new Response(audio, {
    status: 200,
    headers: {
      'Content-Type': 'audio/mpeg',
      'Content-Length': String(audio.byteLength),
      // Browser keeps it for a day; Netlify's CDN keeps it until the next deploy.
      'Cache-Control': 'public, max-age=86400',
      'Netlify-CDN-Cache-Control': 'public, durable, max-age=31536000, immutable',
      'Netlify-Vary': 'query=key|v',
    },
  })
}

export const config = { path: '/api/tts' }
