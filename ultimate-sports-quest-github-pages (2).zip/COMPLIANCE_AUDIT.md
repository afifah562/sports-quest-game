# EDUP6023 Compliance Audit — The Ultimate Sports Quest

**Audit date:** 4 November 2026 · **Version:** 2.0 (standalone digital lesson)

**Audio status (4 November 2026):** 25 narration MP3s are required. 9 are integrated and working: `coach/coach-welcome.mp3`, `coach-team.mp3`, `coach-checkpoint-1.mp3` … `coach-checkpoint-6.mp3` and `coach-correct-1.mp3`. 16 are still needed. The six Mystery Card clue recordings are NOT REQUIRED.

**Update 4 November 2026 (v2.1):** the coach can now speak every line automatically with one ElevenLabs Voice ID, through a secure server-side Netlify Function. Offline copies use exported local MP3s. **Neither the API key/Voice ID nor any generated audio has been added yet**, so no narration has been heard or checked.

**Overall status: NOT YET COMPLETE.** The game is now fully self-contained: every learning resource (Sports Fact Files, Decoder Wheel, Sentence Cards, Reporter Card, equipment pictures, notes, quiz) is inside the website and no physical materials are needed. However, **16 of the 25 required narration MP3s** have **not been supplied**, so EDUP6023 item 3 cannot honestly be marked as met. The Checkpoint 4 video is now **provided via YouTube embed** (see item 4). No audio-generation tool was available to the builder, so no MP3s were generated or faked.

Legend: ✅ Met · 🟡 Built, waiting for media or verification · ❌ Not met · ⬜ Not yet tested

## 1. EDUP6023 multimedia components

All six are listed in the game's **📚 Learning Path** with links.

| # | Component | Where | Status | Notes |
|---|---|---|---|---|
| 1 | Introduction and learning objectives | Welcome + Objectives screens | ✅ content / 🟡 verification / 🟡 narration MP3 | Objectives are **provisional**; DSKP standards pending verification. |
| 2 | Interactive text + graphic notes | 📒 Notes (flip cards with drawings), CP3 Grammar Note + table | ✅ | |
| 3 | Actual MP3 listening activity | CP1: 6 Fact File Listen buttons, each followed by a question (Mystery Card clue audio removed at the teacher's request) | 🟡 **Waiting for the ElevenLabs set-up / exported MP3s** | HTML5 audio controller built and tested with a test MP3. Missing files show "AUDIO NOT YET AVAILABLE" with the transcript. |
| 4 | Video learning activity | CP4: the teacher's YouTube video “Sports I – Vocabulary for Kids” (Smile and Learn – English), https://youtu.be/11e9IzV2cCQ, embedded in the game, then 6 questions | ✅ **PROVIDED VIA YOUTUBE EMBED** / 🟡 playback + quiz match not verified | It is a YouTube embed, not a local MP4, at the teacher's request. It needs an internet connection. YouTube's own captions (CC) are used. ⚠️ The six questions were written for the earlier recommended script and include superlatives; the teacher should check that this vocabulary video covers what they ask. |
| 5 | Interactive animated pupil activity | CP2 drag-and-drop, CP3 spinning Decoder Wheel + Sentence Cards, CP5 Reporter Card, map token, trophy/confetti | ✅ | |
| 6 | Formative quiz with immediate feedback | CP6 (5 questions) + instant feedback in every checkpoint | ✅ | |

## 2. Brief requirements checklist (standalone update)

| Rule | Requirement | Status | Notes |
|---|---|---|---|
| 1 | No physical materials; all recreated digitally | ✅ | All kit prompts, "microphone prop", "I have spun my Decoder Wheel" and "ask your teacher" steps were removed. An automated text scan of every screen found no physical-material instructions. |
| 2 | Teacher's original coach throughout, with expressions for explaining, listening, encouraging, celebrating, instructing | ✅ | Floating coach on every screen plus welcome, Notes, Learning Path, Grammar Note, video side panel, studio and Champion Hall. Cropped from the teacher's own sheets only. |
| 3 | Real MP3 voice narration via a reusable HTML5 controller and manifest | ✅ integration / 🟡 **MP3s not supplied** | `NARRATION` manifest + `Voice` controller: play, pause, replay, mute, volume, subtitles, speaking animation, stops on screen change, no autoplay before interaction. Lines come from local MP3s or, online, from one ElevenLabs Voice ID via a server function. Browser speechSynthesis has been removed. |
| 4 | Six digital Sports Fact Files (exact text, illustration, flip animation, Listen, comprehension question, reopenable) | ✅ / 🟡 audio | |
| 5 | Digital Equipment Match (images inside the app, drag + tap) | ✅ | Equipment pictures are SVG drawings created in code. |
| 6 | Digital Decoder Wheel (7 segments, click or spin, accurate stop) + 7 Sentence Cards + grammar note | ✅ | All 7 transformations and stop positions verified automatically. |
| 7 | Video with play, pause, replay, volume, captions, questions | ✅ **PROVIDED VIA YOUTUBE EMBED** | At the teacher's request, the local MP4 requirement was replaced by the teacher's YouTube video. The game's Play, Pause, Replay, progress and volume controls drive YouTube's player; YouTube's CC button gives captions. If embedding is blocked or the device is offline, a clear "Watch it on YouTube" link shows. Not available offline. |
| 8 | Digital Reporter Card, builder, practice, typed report, text feedback, optional recording | ✅ | The model-report MP3 was removed at the teacher's request. | Pronunciation is **not** assessed; the practice step is self-ticked. |
| 9 | Champion Zone (5 questions, feedback, points, stars, progress, reflection, trophy, confetti, certificate) | ✅ | |
| 10 | Six EDUP6023 components explicit + navigation | ✅ | 📚 Learning Path (top bar + objectives screen). |
| 11 | Offline, relative paths, no external runtime dependency, localStorage kept | ✅ except CP4 video | Offline copies play local MP3s only. The online site may also call the site's own `/api/tts` function, which calls ElevenLabs server-side; this is optional and on the teacher's request. | Saved progress from version 1 still loads (same storage key; old fields kept). |
| 12 | Quality assurance | ✅ automated / ⬜ real devices | See section 5. |

## 3. Asset register

| Asset | Source / creator | Educational purpose | Copyright / permission | AI-generated? | Status |
|---|---|---|---|---|---|
| `assets/images/coach-source/coach-poses-sheet.jpg`, `coach-expressions-sheet.jpg` | Teacher (original cartoon hijab coach, uploaded) | Source artwork for the Virtual Sports Coach | Teacher to confirm | Teacher to declare | ✅ Supplied |
| `assets/images/coach-*.jpg` (10 expressions) | Cropped from the teacher's sheets (no redrawing or generation) | Coach expressions | As above | As above | ✅ In use |
| `assets/audio/coach/coach-welcome.mp3` (one-file test) | Teacher upload (ElevenLabs), 11.4 s, 128 kbps mono | Welcome screen "Play Coach Voice" | Teacher to confirm | Yes (AI-generated voice) | ✅ Supplied; playback verified locally (4 Nov 2026); published URL not yet checkable (site returns 401) |
| `assets/audio/coach/coach-team.mp3` (second file) | Teacher upload (ElevenLabs), 7.5 s, 128 kbps mono | Team Selection "Play Coach Voice" | Teacher to confirm | Yes (AI-generated voice) | ✅ Supplied; playback verified locally (4 Nov 2026); published URL returns 401 (site protection) |
| `assets/audio/coach/coach-checkpoint-1.mp3` … `coach-checkpoint-6.mp3`, `coach-correct-1.mp3` | Teacher uploads (ElevenLabs), 2.9–8.4 s, 128 kbps mono | Checkpoint 1–6 introductions; correct-answer feedback | Teacher to confirm | Yes (AI-generated voice) | ✅ Supplied; each verified locally to load and play at its event (4 Nov 2026) |
| `assets/audio/coach/*.mp3` (17 coach lines) | To be generated with the teacher's ElevenLabs voice (Teacher Panel export or `scripts/generate-narration.mjs`) | Instructions and feedback narration | Teacher to confirm | Teacher to declare | ❌ Not supplied |
| `assets/audio/clue-*.mp3` (6 Mystery Card clues) | — | — | — | — | **NOT REQUIRED** (removed at the teacher's request, 4 Nov 2026; written clues kept) |
| `assets/audio/reporter-model.mp3` | — | — | — | — | **NOT REQUIRED** (Checkpoint 5 model report audio removed at the teacher's request, 4 Nov 2026) |
| `assets/audio/learning-objectives.mp3`, `fact-*.mp3` (6), `grammar-explanation.mp3` | To be recorded | Listening activity, notes | Teacher to confirm | Teacher to declare | ❌ Not supplied |
| `assets/audio/reference/coach-voice-reference.mp3` | Teacher upload (ElevenLabs sample, voice "Zara") | Style reference for the narration recordings; shown in the Teacher Panel only, never played to pupils. The teacher states it says: "Hello, young champions! … I'm Coach Afifah … Let's get started!" (kept as a reference at the teacher's request, 4 Nov 2026) | Teacher to confirm the ElevenLabs licence/voice rights | Yes (AI-generated voice sample) | ✅ Supplied (reference only) |
| CP4 lesson video: YouTube video “Sports I – Vocabulary for Kids” (Smile and Learn – English), https://youtu.be/11e9IzV2cCQ (embed URL `https://www.youtube.com/embed/11e9IzV2cCQ`) | Smile and Learn – English (YouTube channel), chosen by the teacher | CP4 video lesson | YouTube embed under YouTube's Terms of Service; the owner allows embedding (checked 4 Nov 2026) | Not known | ✅ **PROVIDED VIA YOUTUBE EMBED** |
| `assets/video/sports-lesson.mp4`, `sports-lesson.vtt` | — | — | — | — | **NOT REQUIRED** (replaced by the YouTube embed) |
| `assets/images/sports-quest-board.png` | Teacher (original) | Interactive checkpoint map | Teacher to confirm | Teacher to declare | ❌ Not supplied (illustrated CSS board used, labelled) |
| `assets/images/checkpoint-1-cover.png` … `checkpoint-6-cover.png` | — | — | — | — | **NOT REQUIRED** (removed at the teacher's request, 4 Nov 2026; checkpoints open directly into their activities) |
| `assets/images/equipment-*.png` (6, optional) | Teacher | Optional photos replacing the drawings | Teacher to confirm | Teacher to declare | ➖ Optional |
| Equipment + Fact File illustrations (`EQUIP_SVG` in `script.js`), Decoder Wheel, stadium, trophy, padlock, referee, microphone, studio | Drawn in code for this project | Visual learning content and design | Original to this project | Generated with AI coding assistance | ⬜ Teacher to review |
| Sound effects + fallback music loop (Web Audio) | Created in code | Feedback sounds | Original | Generated with AI coding assistance | ⬜ Teacher to review |
| `assets/audio/background-music.mp3` (optional) | Royalty-free source | Atmosphere | Must be licensed | Teacher to declare | ➖ Optional |
| ElevenLabs Text-to-Speech (one Voice ID, via `netlify/functions/tts.mts`) | ElevenLabs, the teacher's account | Generates the coach narration | Teacher to confirm their ElevenLabs plan allows this use | **Yes — AI-generated speech** | ⬜ Not configured yet |
| Emoji icons | Device emoji font | Icons | System font | No | ⬜ Teacher to review |

## 4. Incomplete or unverified elements

1. **Narration:** 16 of the 25 required MP3s are still missing (Welcome, Team Selection, the six checkpoint intros and "Excellent work!" are done). The ElevenLabs integration is built but not configured. The old device-voice fallback was removed. Scripts, filenames and a voice brief: `assets/audio/NARRATION_SCRIPTS.txt` and `narration-manifest.csv`. The teacher's voice sample is a style reference only; no voice was cloned and no lines were generated, because no speech-generation service was available to the builder.
2. **Lesson video:** provided via YouTube embed. It needs internet and so does not work in a fully offline copy; the game shows a clear message and link instead. Actual playback could not be confirmed in testing (see section 5), and the teacher should check that the CP4 questions match the video.
3. **Sports Quest Board:** not supplied; a labelled illustrated placeholder board is in use. (Checkpoint cover images are not required.)
4. **DSKP learning standards:** pending verification; none are stated.
5. **Learning objectives and 30-minute duration:** provisional.
6. **Speaking:** practice only (self-ticked). No speech recognition or pronunciation assessment exists.
7. **Real-device testing:** not done (see below).

## 5. Testing record

**What was actually checked (4 November 2026, automated, headless Chromium via Playwright):** a full play-through script at 1366×768, 1280×800, 1180×820, 1024×768 and 768×1024, run against two local copies of the site: one exactly as shipped (no media) and one with **temporary test media** (two short test-tone files saved as `coach/coach-team.mp3` and `fact-badminton.mp3`, a 3-second test video saved as `sports-lesson.mp4` and a one-line `sports-lesson.vtt`; these test files were **not shipped**). Every run completed all six checkpoints with **0 failures and no JavaScript errors** (41 checks without media, 47 with test media). It verified:
- no audio before the first interaction; MP3 narration plays through the HTML5 controller; mute, pause and replay work; with no MP3, "AUDIO NOT YET AVAILABLE" and the transcript show; the device voice was not used (it has since been removed);
- the six EDUP6023 components appear in the Learning Path;
- all six Fact Files open with the exact text and an illustration, Listen works, the quick checks score, and the Fact Files reopen while a Mystery Card is open;
- the equipment pictures are inside the app; drag-and-drop and tap-to-match both work;
- the Decoder Wheel stops with the chosen segment exactly under the pointer for all 7 adjectives, shows all 7 correct superlatives, and random Spin lands on a segment; the 7 Sentence Cards open and complete;
- the test video loads, plays and pauses, and the captions track shows and the CC button toggles it; without the MP4, "VIDEO NOT YET AVAILABLE" shows;
- the Reporter Card is present, the report feedback checklist works, and CP5 completes without a teacher or physical materials;
- the Champion Zone shows the trophy, reflection, certificate and final coach celebration; progress (6/6) is saved;
- a text scan of every screen found no instructions to use physical/printed materials or to ask the teacher;
- no visible control on any screen or tested pop-up is covered by the coach.

**Voice reference check (4 November 2026, headless Chromium):** the teacher's sample loads and plays (17.9 s) from the Teacher Panel and is listed as found. In a test-only copy, the sample was temporarily saved as `coach/coach-team.mp3` to confirm that a real MP3 plays through the narration player and the coach shows her talking animation and sound-wave while it plays, and stops on a screen change. That copy was not shipped; the game does not use the sample as narration.

**ElevenLabs integration check (4 November 2026):** no real ElevenLabs key was used; ElevenLabs was simulated.
- *Server function* (`netlify/functions/tts.mts`), unit-tested with a mocked ElevenLabs API. Status reports configured/not configured without revealing secrets. A missing key gives 503 with a clear message. Unknown lines (404), changed text (409) and extra query parameters (400, so the cache can't be bypassed) are rejected. Every line uses the same Voice ID and exact text, with the key only in the request header. Durable CDN cache headers are set. An ElevenLabs 401 becomes "the API key was rejected". POST is refused. The function also loaded and answered correctly under `netlify dev`.
- *Game* (headless Chromium, `/api/tts` answered by a test stub returning the teacher's reference MP3). Nothing is requested before the first tap. A "getting ready" state shows while generating. The talking animation runs only during playback and stops on pause. Mute and resume work. Replaying the same line is served from cache (no second request). Previous audio stops on screen change. Objectives, CP1 instructions, a Fact File, wrong and correct feedback are all spoken. A generation failure shows the reason and keeps the subtitle. When not configured, "AUDIO NOT YET AVAILABLE" shows and nothing is requested. The browser's manifest matches the server line list exactly.
- *Offline pack.* The Teacher Panel exported a valid 32-file ZIP. With it unzipped and the browser offline, lines played from local MP3s and no API calls were made.
- *Regression.* All six checkpoints were completed at 1366×768 and 768×1024 with no errors.

**YouTube embed check (4 November 2026, headless Chromium with internet):** YouTube's embed check confirmed the video exists and allows embedding. In Checkpoint 4 the YouTube player loaded inside the game, with no redirect to YouTube and no fallback. The game's controls connected to it and showed the real duration (4:01). No MP4 or VTT file was requested. The quiz still completes. The video is removed when leaving the checkpoint. When offline, the clear "VIDEO NEEDS AN INTERNET CONNECTION" message and a YouTube link show. **Actual playback was NOT verified:** YouTube showed "Sign in to confirm you're not a bot" to the test server (a data-centre computer), so Play, Pause and Replay could not be confirmed to move the video. Teachers should test playback on a classroom device.

**One-file audio test (4 November 2026, headless Chromium, local server):** the uploaded `coach-welcome.mp3` is served at `assets/audio/coach/coach-welcome.mp3` (200, audio/mpeg, 199,167 bytes). Pressing **Play Coach Voice** played the real file (time advancing, no media error, 11.4 s). The coach's talking animation ran and stopped when the audio ended. **Replay** restarted it, and leaving the screen stopped it. No 404s. Not checked: the published site (every request returns 401 because the site is access-protected, and the file is only live after this change is deployed), and real speakers.

**Welcome audio fault check (4 November 2026):** the saved `coach-welcome.mp3` is byte-identical to the teacher's upload and structurally valid (436 MP3 frames, 11.39 s). The dialogue update changed only the subtitle text, not the file, path or player. In Chromium, Play Coach Voice, auto-play after the first tap, pause/resume, Replay and returning to the Welcome screen all played the real file. In Firefox, the test machine has no sound device, which raised `OnMediaSinkAudioError` (the same happens with any MP3). This revealed a player bug: any playback error permanently marked the file as missing and showed "AUDIO NOT YET AVAILABLE" until reload. Fixed: only a real 404 now counts as missing; other errors show a "could not play on this device" message, and the next press retries the real MP3. Verified in Chromium and Firefox, and all six checkpoints still complete. WebKit/Safari could not be tested here, and the published URL returns 401 (site protection).

**Seven-file batch (4 November 2026, headless Chromium, local server):** every file returned 200 audio/mpeg and is a valid MP3 with no damaged frames. Opening each of checkpoints 1–6 played its own recording with the matching subtitle and the coach animation. A correct answer played `coach-correct-1.mp3` ("Excellent work!"), and the animation stopped when it ended. Leaving a checkpoint stopped its audio. Welcome and Team still play. All six checkpoints still complete with no JavaScript errors. The Teacher Panel shows 9 / 26. Not checked: the published site (401) and real speakers.

**Limits:** headless Chromium is not a real tablet. Touch dragging, iPad Safari audio, real speakers, and the real recordings and video were **not** tested. Teachers should fill in the table below on their own devices.

| Test | Laptop (Chrome/Edge) | Tablet (Safari/Chrome) | Notes |
|---|---|---|---|
| Every button responds | ⬜ | ⬜ | |
| Team selection + HUD shows team | ⬜ | ⬜ | |
| Only CP1 unlocked at start; unlocks in order | ⬜ | ⬜ | |
| CP1 Fact Files + quick checks + Mystery Cards | ⬜ | ⬜ | |
| CP2 mouse drag | ⬜ | n/a | |
| CP2 touch drag | n/a | ⬜ | |
| CP2 tap-to-match fallback | ⬜ | ⬜ | |
| CP3 Decoder Wheel tap + spin, Sentence Cards, typed answers | ⬜ | ⬜ | |
| CP4 timer, whistle, scoreboard | ⬜ | ⬜ | |
| CP4 YouTube video plays, pauses, replays; CC captions | ⬜ | ⬜ | |
| CP5 Reporter Card, builder, feedback, practice tick | ⬜ | ⬜ | |
| CP5 optional recording (permission flow) | ⬜ | ⬜ | |
| CP6 questions, badges, confetti, certificate print | ⬜ | ⬜ | |
| Audio play/pause (after MP3s added) | ⬜ | ⬜ | |
| "AUDIO/VIDEO NOT YET AVAILABLE" shown when missing | ⬜ | ⬜ | |
| Scoring 10/5, no repeat points on replay | ⬜ | ⬜ | |
| Progress saved after page reload | ⬜ | ⬜ | |
| Reset clears everything | ⬜ | ⬜ | |
| Layout fits without awkward scrolling | ⬜ | ⬜ | |
| Works offline (local files) | ⬜ | ⬜ | |

---
## GitHub Pages repair — test log (automated browser test, Chromium via Playwright, served from a /repo/ sub-folder)
Tested and passing: no JavaScript errors on any screen; all 10 coach JPGs load; autoplay respected
(nothing plays before the first click); team, checkpoint-1 and correct-answer MP3s actually play; only one narration
at a time; a screen change stops narration; wrong answers play no audio and show subtitles; completion line
waits for the previous line to finish; missing audio is labelled honestly; music and sound toggles; layout screenshots at
1280, 820 and 390 px wide.
NOT tested: listening to the MP3s to confirm the spoken words match their scripts (only file length/format checked);
real phones/tablets and Safari/iOS; the YouTube video in Checkpoint 4 (no internet in the test sandbox);
printing the certificate; microphone recording in Checkpoint 5; screen readers.
Missing audio files: see MISSING_FILES.txt.
